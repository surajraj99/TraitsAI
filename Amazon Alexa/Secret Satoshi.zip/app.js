'use strict';

// ------------------------------------------------------------------
// APP INITIALIZATION
// ------------------------------------------------------------------

const { App } = require('jovo-framework');
const { Alexa } = require('jovo-platform-alexa');
const { GoogleAssistant } = require('jovo-platform-googleassistant');
const { JovoDebugger } = require('jovo-plugin-debugger');
const { FileDb } = require('jovo-db-filedb');

const app = new App();

app.use(
    new Alexa(),
    new GoogleAssistant(),
    new JovoDebugger(),
    new FileDb()
);


// ------------------------------------------------------------------
// APP LOGIC
// ------------------------------------------------------------------

app.setHandler({
    LAUNCH() {
        this.toIntent('FirstLaunchIntent');
    },

    FirstLaunchIntent() {
        let speech = this.speechBuilder().addText(['Can you keep the secret?', 'Are you capable of keeping a secret?', 'Can you keep secrets?']);
        let reprompt = "Simple: Can you keep a secret?";
        this.ask(speech, reprompt);
    },

    yesIntent() {
        this.tell("Alright, my name is Satoshi Nakamoto and I'm the creator of bitcoin.");
    },

    noIntent() {
        this.tell("As I thought, you can't be trusted.")
    },

    'AMAZON.CancelIntent': function() {
        this.tell("Alright, I'll stop talking.");
    },

    'AMAZON.HelpIntent': function() {
        this.ask("What do you need help with?");
    },

    'AMAZON.StopIntent': function() {
        this.tell("Alright, go ahead and leave.");
    }
});

module.exports.app = app;
