'use strict';

// ------------------------------------------------------------------
// APP INITIALIZATION
// ------------------------------------------------------------------

const { App } = require('jovo-framework');
const { Alexa } = require('jovo-platform-alexa');
const { JovoDebugger } = require('jovo-plugin-debugger');
const { FileDb } = require('jovo-db-filedb');
const {
    GoogleAssistant,
    BasicCard
} = require('jovo-platform-googleassistant');
const requestPromise = require('request-promise-native');
const { DynamoDb } = require('jovo-db-dynamodb');

const app = new App();

app.use(
    new Alexa(),
    new GoogleAssistant(),
    new JovoDebugger(),
    new FileDb(),
    new DynamoDb()
);

app.setDynamoDb('Satoshi-table');


// ------------------------------------------------------------------
// APP LOGIC
// ------------------------------------------------------------------

let numRight = 0
let nM = ''
let eM = ''
let easyRight = 0
let easyWrong = 0
let medRight = 0
let medWrong = 0
let hardRight = 0
let hardWrong = 0
let numCompliments = 0

async function getBitcoinPrice() {
    const options = {
        uri: 'https://blockchain.info/stats?format=json',
        json: true // Automatically parses the JSON string in the response
    };
    const data = await requestPromise(options);
    let bitcoinPrice = parseFloat(data.market_price_usd);

    return bitcoinPrice;
}

app.setHandler({    

    'LAUNCH': function() {
        if (this.$user.$data.sessNum == 1) {
            this.$user.$data.userBTC = 1.0;
            this.$user.$data.userUSD = 0.0;
            this.toIntent('SecondLaunchIntent');
        }
        if (this.$user.$data.sessNum > 1) {
            this.toIntent('ThirdLaunchIntent');
        }
        this.$user.new = true
        if (this.$user.new == true) {
            this.$user.$data.basicsNum = 1;
            this.$user.$data.securNum = 1;
            return this.toStateIntent('FirstLaunchState', 'FirstLaunchIntent');
        }
        // this.$user.$metaData.sessionsCount = 1
        // if (this.$user.$metaData.sessionsCount == 1) {
        //     this.$user.$data.basicsNum = 1;
        //     this.$user.$data.securNum = 1;
        //     this.toIntent('FirstLaunchIntent');
        // }
    },
    
    'FirstLaunchState' : {
        async FirstLaunchIntent() {
            const bitcoinPrice = await getBitcoinPrice();
            this.$user.$data.initialPrice = bitcoinPrice;
            this.$user.$data.totalMoney = bitcoinPrice;
            let speech = this.speechBuilder().addText(['Can you keep the secret?', 'Are you capable of keeping a secret?', 'Can you keep secrets?']);
            let reprompt = "Simple: Can you keep a secret?";
            this.followUpState("KeepSecretState").ask(speech, reprompt);
        }
    },

    "KeepSecretState" : {
        'YesIntent' : function() {
            this.$user.$data.sessNum = 0;
            let speech = this.speechBuilder().addText('So you say.').addBreak('500ms').addText(['Are you one of us?', 'Are you part of our group?', 'Are you a member of our group?']);
            let reprompt = "You're with us or you are not.";
            this.followUpState("OneOfUsState").ask(speech, reprompt);
        },

        'RepeatYesIntent': function() {
            let speech = "Are you with our group or not?";
            this.ask(speech);
        },

        "NoIntent" : function() {
            let speech = "As I thought. Goodbye.";
            this.tell(speech);
        },

        "WhatSecretIntent" : function () {
            let speech = this.speechBuilder().addText("Seems like you have no clue of what I am talking about.")
            .addBreak('500ms')
            .addText("I have no business talking with you.")
            this.tell(speech);
        },

        "Unhandled" : function() {
            this.tell("Your inability to answer this simple question is proof enough. Goodbye.");
        }
    },

    "OneOfUsState" : {
        'RepeatIntent': function() {
            this.toStateIntent('KeepSecretState', 'RepeatYesIntent');
        },

        'YesIntent' : function() {
            let speech = this.speechBuilder().addText(['I do not trust you.', 'That\'s hard to believe.', 'Big claim.',]).addText(['You\'re going to have to prove yourself.', 'Can you prove yourself?', "Let's see you prove yourself."])
            .addText("\nWe'll start with a name. Does not have to be yours, in case you want to remain anonymous.")
            .addBreak('500ms')
            .addText(" A nice common name would be perfect.")
            let reprompt = "Give me a common name.";
            this.followUpState('GetNameState').ask(speech, reprompt);
        },

        'RepeatYesIntent': function() {
            let speech = this.speechBuilder().addText("Simple.").addBreak('500ms').addText("What is your name?");
            this.ask(speech);
        },

        'WhatGroupIntent' : function() {
            let speech =  this.speechBuilder().addText("Seems like you have no idea of what I am speaking about.")
            .addBreak('500ms')
            .addText("I have no business talking with you.")
            this.tell(speech);
        },

        'NoIntent' : function() {
            let speech = "Figures. There is no more of a need to talk.";
            this.tell(speech);
        },

        "Unhandled" : function() {
            this.tell("Your reluctance to answer is evident. Good day.");
        }
    },    

    'GetNameState' : {
        'RepeatIntent': function() {
            this.toStateIntent('OneOfUsState', 'RepeatYesIntent');
        },
        
        'GetNameIntent' : function(name) {
            nM = this.$inputs.name.value;
            this.$user.$data.userName = nM;
            let speech = this.speechBuilder().addText("Alright " + nM + ", we've got that out of the way." + "\nI will ask you a few questions.")
            .addBreak('500ms')
            .addText(" If you answer enough of my questions correctly, I will be able to enlighten you on Bitcoin topics.")
            .addBreak('500ms')
            .addText(" I might even allow you to try out a simulation I've been developing.")
            .addBreak('500ms')
            .addText("Choose the correct letter response to each question.")
            .addBreak('500ms')
            .addText("Ready?");
            let reprompt = "Ready to begin?";
            this.followUpState('BeginQuizState').ask(speech, reprompt);
        },

        'RepeatGetNameIntent' : function() {
            let speech = "I am going to ask you a few questions. If you get them right, you will prove yourself. Are you ready?"
            this.ask(speech);
        },

        "Unhandled" : function() {
            this.followUpState('GetNameState').ask("What is your name?");
        }
            
    },  
            
    'InfoCategoryState' : {
        'NoIntent' : function() {
                let speech = 'Ok. Fair enough. Have a good one.';
                this.tell(speech);
            },

        'YesIntent' : function() {
                let speech = this.speechBuilder().addText("Lovely! Feel free to choose one of the categories below:")
                .addText("\nTimeline")
                .addBreak('400ms')
                .addText("\nBlockchain")
                .addBreak('400ms')
                .addText("\nDesign")
                .addBreak('400ms')
                .addText("\nDecentralization")
                .addBreak('400ms')
                .addText("\nCriticism")
                .addBreak('400ms')
                .addText("\nEconomics");
                let reprompt = "Choose one of the categories listed please." 
                this.followUpState("GiveInfoState").ask(speech, reprompt);       
            },

        'Unhandled' : function() {
            this.followUpState('InfoCategoryState').ask("Do you want info? Short and simple.", "Info or no?`");
        }
    },

    'GiveInfoState' : {
        'HistoryInfoIntent' : function() {
            let speech = this.speechBuilder().addText("In 2008, a paper called Bitcoin – A Peer to Peer Electronic Cash System was posted to a mailing list discussion on cryptography.")
            .addBreak('400ms')
            .addText("A year later, the Bitcoin software is made available to the public for the first time and mining")
            .addBreak('400ms')
            .addText("In 2010, someone decided to sell their bitcoin for the first time. They swapped 10,000 of them for two pizzas.")
            .addBreak('400ms')
            .addText("By 2011, the world sees the emergence of alternative forms of cryptocurrencies.") 
            .addBreak('400ms')
            .addText("Unfrotunately, bitcoin's popularity not only attracts good-hearted investors but also criminals. And so we saw Mt. Gox go offline.")
            .addBreak('400ms')
            .addText("Now we approach 2017. Bitcoin has become much more popular. Even at the face of compeititors like Etherium, Bitcoin climbs in stocks.")
            .addBreak('400ms')
            .addText("And so we reach today.");
            this.tell(speech);
        },

        'BlockchainInfoIntent' : function() {    
            let speech = this.speechBuilder().addText("A blockchain is a digitized, decentralized, public ledger of all cryptocurrency transactions.")
            .addBreak('500ms')
            .addText("It's constantly growing as the most recent transactions are recorded and added to it in chronological order.")
            .addBreak('500ms')
            .addText("Blockchain allows market participants to keep track of digital currency transactions without central recordkeeping.");
            this.tell(speech);
        },

        'DesignInfoIntent' : function() {
            let speech = this.speechBuilder().addText("It would be a disservice to bitcoin if I were to summarize the design of bitcoin with just a few sentences.")
            .addBreak('500ms')
            .addText("With the technology you have today, you could do a quick search on bitcoin and learn all you want.");
            this.tell(speech);
        },

        'DecentralizationInfoIntent': function() {
            let speech = this.speechBuilder().addText("There's a few quirks to the decentralization of bitcoin.")
            .addBreak('500ms')
            .addText('Bitcoin has no central control: no central repository of information, no central management, and, essentially, no central point of failure.')
            .addBreak('500ms')
            .addText("And yet, most of the actual services and businesses built within the Bitcoin ecosystem are centralized.")
            .addBreak('500ms')
            .addText("They are run by specific people, in specific locations, with specific computer systems, and they are susceptible to specific legal entanglements.");
            this.tell(speech);
        },

        'CriticismInfoIntent': function() {
            let speech = this.speechBuilder().addText("You thought I would give you criticism on my own creation?")
            .addBreak('500ms')
            .addText("If you want to find faults in bitcoin, find them yourself.");
            this.tell(speech);
        },

        'EconomicsInfoIntent': function() {
            let speech = "Do a quick google search. I am sure you'll find something.";
            this.tell(speech);
        },

        'Unhandled' : function() {
            this.followUpState('GiveInfoState').ask("Alright, choose a category.", "Pick a category.");
        }
    },

    'BeginQuizState' : {
        'RepeatIntent': function() {
            this.toStateIntent('GetNameState', 'RepeatGetNameIntent');
        },
       
        'YesIntent': function() {
            let speech = this.speechBuilder().addText("Ok " + nM + ". Here's the first question. \nWhat year was Bitcoin created?\n"
            + "A. 2009\n")
            .addBreak('500ms')  
            .addText("\nB. 2014\n")
            .addBreak('500ms') 
            .addText("C. 2008\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesOneState').ask(speech, reprompt); 
        },
 
        'RepeatYesIntent': function() {
            let speech = this.speechBuilder().addText("Alright, here it is again. \nWhat year was Bitcoin created?\n"
            + "A. 2009\n")
            .addBreak('500ms')  
            .addText("\nB. 2014\n")
            .addBreak('500ms') 
            .addText("C. 2008\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesOneState').ask(speech, reprompt); 
        },
 
        'UserReadyIntent' : function() {
            let speech = this.speechBuilder().addText("Ok " + nM + ". Here's the first question. \nWhat year was Bitcoin created?\n"
            + "A. 2009\n")
            .addBreak('500ms')  
            .addText("\nB. 2014\n")
            .addBreak('500ms') 
            .addText("C. 2008\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesOneState').ask(speech, reprompt); 
        },
 
        'UserNotReadyIntent' : function() {
            let speech = "You not being ready is proof of your lack of dedication to our group." + "Goodbye.";
            this.tell(speech);
        },
       
        'NoIntent': function() {
            this.tell("I knew it. It's always good to actually know what you're being tested on.");
        },
 
        "Unhandled" : function () {
            this.followUpState('BeginQuizState').ask("Say yes or no.", "Yes or no, please.");
        }
    },
 
    'QuesOneState' : {
        'RepeatIntent': function() {
            this.toStateIntent('BeginQuizState', 'RepeatYesIntent');
        },
       
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey' || this.$inputs.answerChoice.value == '2009') {
                easyRight = easyRight + 1;
                numRight = numRight + 1;
                let speech = this.speechBuilder().addText("Nice job. Let's see you answer this:"
                + "\nWhat is the name of the bitcoin exchange from Japan that famously collapsed in 2014?\n" +
                "A. Tradehill\n")
                .addBreak('500ms') 
                .addText("B. Bitstamp\n")
                .addBreak('500ms') 
                .addText("C. Mt. Gox\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesFourState').ask(speech, reprompt);
            }
 
            else if (!(this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey' || this.$inputs.answerChoice.value == '2009')){
                easyWrong = easyWrong + 1;
                let speech = this.speechBuilder().addText("A bit embarassing you got that wrong. That does not bode well for you. Here's another question:"
                + "\nWho created the digital currency of bitcoin?\n"
                + "A. Natoshi Sakamoto\n")
                .addBreak('500ms') 
                .addText("B. Gavin Andresen\n")
                .addBreak('500ms') 
                .addText("C. Satoshi Nakamoto\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesTwoState').ask(speech, reprompt);
            }
 
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
 
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Here it is again:"
            + "\nWho created the digital currency of bitcoin?\n"
            + "A. Natoshi Sakamoto\n")
            .addBreak('500ms') 
            .addText("B. Gavin Andresen\n")
            .addBreak('500ms') 
            .addText("C. Satoshi Nakamoto\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesTwoState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
       
        'Unhandled': function() {
            this.followUpState('QuesOneState').ask("Enter a letter choice please.")
        }
    },
 
    'QuesTwoState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesOneState', 'RepeatQuestionIntent');
        },
       
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'Satoshi Nakamoto') {
                numRight = numRight + 1;
                easyRight = easyRight + 1;
                let speech = this.speechBuilder().addText("You got one. Let's see you answer this:"
                + "\nWhat is the name of the bitcoin exchange from Japan that famously collapsed in 2014?\n"
                + "A. Tradehill\n") 
                .addBreak('500ms') 
                .addText("B. Bitstamp\n")
                .addBreak('500ms') 
                .addText("C. Mt. Gox\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesFourState').ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'Satoshi Nakamoto')){
                let speech = this.speechBuilder().addText("Wrong! How do you get this one wrong?"
                + " Come on now. You cannot be messing these up. Here's another question:"
                + "\nWhat is the name of the first academic paper that described bitcoin commonly referred to as?\n"
                + "A. The Bitcoin Whitepaper\n")
                .addBreak('500ms') 
                .addText("B. The Origins of Money\n")
                .addBreak('500ms') 
                .addText("C. The Great Unraveling\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesThreeState').ask(speech, reprompt);
            }
   
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Here it is again:"
            + "\nWhat is the name of the first academic paper that described bitcoin commonly referred to as?\n"
            + "A. The Bitcoin Whitepaper\n")
            .addBreak('500ms') 
            .addText("B. The Origins of Money\n")
            .addBreak('500ms') 
            .addText("C. The Great Unraveling\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesThreeState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesTwoState').ask("Enter a letter choice please.")
        }
 
    },
 
    'QuesThreeState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesTwoState', 'RepeatQuestionIntent');
        },
 
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey' || this.$inputs.answerChoice.value == 'The Bitcoin Whitepaper') {
                numRight = numRight + 1;
                easyRight = easyRight + 1;
                let speech = this.speechBuilder().addText("You got the answer correct! Let's see you answer this:"
                + "\nWhat is the name of the bitcoin exchange from Japan that famously collapsed in 2014?\n"
                + "A. Tradehill\n") 
                .addBreak('500ms') 
                .addText("B. Bitstamp\n")
                .addBreak('500ms') 
                .addText("C. Mt. Gox\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesFourState').ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey' || this.$inputs.answerChoice.value == 'The Bitcoin Whitepaper')){
                let speech = "You got the answer wrong! The name of the first academic paper that described bitcoin was The Bitcoin Whitepaper.";
                speech = speech + "\nEither way, you're obviously not part of our group. Goodbye."
                this.tell(speech);
            }
   
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Alright, here it is again:"
            + "\nWhat is the name of the bitcoin exchange from Japan that famously collapsed in 2014?\n" +
            "A. Tradehill\n")
            .addBreak('500ms') 
            .addText("B. Bitstamp\n")
            .addBreak('500ms') 
            .addText("C. Mt. Gox\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesFourState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "Well, good attempt. I guess. Come back when you know more.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesThreeState').ask("Enter a letter choice please.")
        }
 
    },
 
    'QuesFourState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesThreeState', 'RepeatQuestionIntent');
        },
       
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'Mt. Gox') {
                numRight = numRight + 1;
                medRight = medRight + 1;
                let speech = this.speechBuilder().addText("Correct! Get this one more question and I'll believe you."
                + "\nBitcoin is protected by encryption. What is the form of encryption called?\n"
                + "A. Acme 900\n")
                .addBreak('500ms') 
                .addText("B. Scrypt-N\n")
                .addBreak('500ms') 
                .addText("C. Sha256\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesSevenState').ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'Mt. Gox')){
                medWrong = medWrong + 1;
                let speech = this.speechBuilder().addText("You got the answer wrong " + nM + "! The name of the bitcoin exchange from Japan was Mt. Gox."
                + " You are not doing too well. Try this one:"
                + "\nWhich of the following alt coins is NOT really the name of an alt coin?\n"
                + "A. DollarCoin\n")
                .addBreak('500ms') 
                .addText("B. Ethereum\n")
                .addBreak('500ms') 
                .addText("C. Tether\n") 
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesFiveState').ask(speech, reprompt);
            }
   
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Here it is again:"
                + "\nWhich of the following alt coins is NOT really the name of an alt coin?\n"
                + "A. DollarCoin\n")
                .addBreak('500ms') 
                .addText("B. Ethereum\n")
                .addBreak('500ms') 
                .addText("C. Tether\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesFiveState').ask(speech, reprompt);
        },
       
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "Well, good attempt. I guess. Come back when you know more.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesFourState').ask("Enter a letter choice please.")
        }
 
    },
 
    'QuesFiveState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesFourState', 'RepeatQuestionIntent');
        },
       
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey' || this.$inputs.answerChoice.value == 'Dollarcoin') {
                numRight = numRight + 1;
                medRight = medRight + 1;
                let speech = this.speechBuilder().addText("Correct! Get this one more question and I'll believe you."
                + "\nBitcoin is protected by encryption. What is the form of encryption called?\n"
                + "A. Acme 900\n") 
                .addBreak('500ms') 
                .addText("B. Scrypt-N\n")
                .addBreak('500ms') 
                .addText("C. Sha256\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesSevenState').ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey' || this.$inputs.answerChoice.value == 'Dollarcoin')){
                medWrong = medWrong + 1;
                let speech = this.speechBuilder().addText("You got the answer wrong! DollarCoin is not real. But it sounds the most real. And you fell for it. Here's the next question:"
                + "\nWhat is the name of the general ledger that tracks all bitcoin transactions?\n"
                + "A. The Gox-chain\n") 
                .addBreak('500ms')
                .addText("B. The Block-link\n")
                .addBreak('500ms') 
                .addText("C. The Block-chain\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesSixState').ask(speech, reprompt);
            }
   
            else {
                let speech = "Please give an letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Well, here it is again:"
            + "\nWhat is the name of the general ledger that tracks all bitcoin transactions?\n"
            + "A. The Gox-chain\n") 
            .addBreak('500ms')
            .addText("B. The Block-link\n")
            .addBreak('500ms') 
            .addText("C. The Block-chain\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesSixState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "Gee, you're like halfway there " + nM + ". And then you quit.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesFiveState').ask("Enter a letter choice please.")
        }
 
    },
 
    'QuesSixState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesFiveState', 'RepeatQuestionIntent');
        },
       
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'The Block-chain') {
                numRight = numRight + 1;
                medRight = medRight + 1;
                let speech = this.speechBuilder().addText("Correct! Get this one more question and I'll believe you."
                + "\nBitcoin is protected by encryption. What is the form of encryption called?\n"
                + "A. Acme 900\n") 
                .addBreak('500ms') 
                .addText("B. Scrypt-N\n")
                .addBreak('500ms') 
                .addText("C. Sha256\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesSevenState').ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'The Block-chain')){
                medWrong = medWrong + 1;
                let speech = "Well, that's wrong.";
                speech = speech + "\nEither way, you're obviously not part of our group. Goodbye."
                this.tell(speech);
            }
   
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Here's the question again."
            + "\nBitcoin is protected by encryption. What is the form of encryption called?\n"
            + "A. Acme 900\n") 
            .addBreak('500ms') 
            .addText("B. Scrypt-N\n")
            .addBreak('500ms') 
            .addText("C. Sha256\n")
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesSevenState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "Gee, you're like halfway there " + nM + ". And then you quit.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesSixState').ask("Enter a letter choice please.")
        }
    },
 
    'QuesSevenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesSixState', 'RepeatQuestionIntent');
        },
       
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'Sha256') {
                numRight = numRight + 1;
                hardRight = hardRight + 1;
                let speech = this.speechBuilder().addText("Surprisingly, you got enough questions right. You've proved yourself " + nM + ".")
                .addBreak('500ms')
                .addText("\nI will let you in on the secret that you supposedly already know.")
                .addBreak('500ms')
                .addText('There is a secret closed beta test for my new app. Would you like to be a part of it?')
                let reprompt = "Do you want to be a beta tester?";
                this.followUpState("BetaTesterAcceptState").ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'Sha256')){
                hardWrong = hardWrong + 1;
                let speech = this.speechBuilder().addText("Nope. The encryption that protects bitcoin is Sha256. Encryptions have weird names.  I'll give you another chance."
                + "\nHow does the Bitcoin Protocol work?\n"
                + "A. It's centralized\n")
                .addBreak('500ms') 
                .addText("B. It's decentralized\n")
                .addBreak('500ms') 
                .addText("C. It's owned by the Bitcoin Foundation\n")
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesEightState').ask(speech, reprompt);
            }
   
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Here's the question again."
                + "\nHow does the Bitcoin Protocol work?\n"
                + "A. It's centralized\n")
                .addBreak('500ms') 
                .addText("B. It's decentralized\n")
                .addBreak('500ms') 
                .addText("C. It's owned by the Bitcoin Foundation\n") 
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesEightState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "You only realize you did not know bitcoin by now? That does not look good.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesSevenState').ask("Enter a letter choice please.")
        }
    },
 
    'QuesEightState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesSevenState', 'RepeatQuestionIntent');
        },
 
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'B' || this.$inputs.answerChoice.value == "It's decentralized") {
                numRight = numRight + 1;
                hardRight = hardRight + 1;
                let speech = this.speechBuilder().addText("Surprisingly, you got enough questions right. You've proved yourself " + nM + ".")
                .addBreak('500ms')
                .addText("\nI will let you in on the secret that you supposedly already know.")
                .addBreak('500ms')
                .addText('There is a secret closed beta test for my new app. Would you like to be a part of it?')
                let reprompt = "Do you want to be a beta tester?";
                this.followUpState("BetaTesterAcceptState").ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'B' || this.$inputs.answerChoice.value == "It's decentralized")){
                hardWrong = hardWrong + 1;
                let speech = this.speechBuilder().addText("You got the answer wrong! Bitcoin is decentralized. That means 'not run by the government' in case you did not know. Here's another one:"
                + "\nIn bitcoin nomenclature, what is a hard fork?\n"
                + "A. 10,000 bitcoins\n") 
                .addBreak('500ms')
                .addText("B. Potential split in the bitcoin network\n") 
                .addBreak('500ms')
                .addText("C. A method of storing bitcoin\n") 
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesNineState').ask(speech, reprompt);
            }
   
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Here's the question again:"
            + "\nIn bitcoin nomenclature, what is a hard fork?\n"
            + "A. 10,000 bitcoins\n") 
            .addBreak('500ms')
            .addText("B. Potential split in the bitcoin network\n") 
            .addBreak('500ms')
            .addText("C. A method of storing bitcoin\n") 
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesNineState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "You only realize you did not know bitcoin by now? That does not look good.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesEightState').ask("Enter a letter choice please.")
        }
    },
 
    'QuesNineState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesEightState', 'RepeatQuestionIntent');
        },
 
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'B' || this.$inputs.answerChoice.value == 'Potential split in the bitcoin network') {
                numRight = numRight + 1;
                hardRight = hardRight + 1;
                let speech = this.speechBuilder().addText("Surprisingly, you got enough questions right. You've proved yourself " + nM + ".")
                .addBreak('500ms')
                .addText("\nI will let you in on the secret that you supposedly already know.")
                .addBreak('500ms')
                .addText('There is a secret closed beta test for my new app. Would you like to be a part of it?')
                let reprompt = "Do you want to be a beta tester?";
                this.followUpState("BetaTesterAcceptState").ask(speech, reprompt);
            }
   
            else if (!(this.$inputs.answerChoice.value == 'B' || this.$inputs.answerChoice.value == 'Potential split in the bitcoin network')){
                hardWrong = hardWrong + 1;
                let speech = this.speechBuilder().addText("You got the answer wrong! A hard fork is a potential split in the bitcoin network. Hard to guess that one right? That's why you should know it. One last chance:"
                + "\nWhich of the following statements are NOT true about bitcoin wallets?\n"
                + "A. A wallet is a digital container file that stores bitcoin\n") 
                .addBreak('500ms')
                .addText("B. A wallet is the general ledger location that stores your public information\n") 
                .addBreak('500ms')
                .addText("C. A wallet is an email account backup for bitcoin password file\n")  
                let reprompt = "Please say a letter choice.";
                this.followUpState('QuesTenState').ask(speech, reprompt);
            }
   
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },
 
        'RepeatQuestionIntent' : function() {
            let speech = this.speechBuilder().addText("Here's the same question repeated:"
            + "\nWhich of the following statements are NOT true about bitcoin wallets?\n"
            + "A. A wallet is a digital container file that stores bitcoin\n") 
            .addBreak('500ms')
            .addText("B. A wallet is the general ledger location that stores your public information\n") 
            .addBreak('500ms')
            .addText("C. A wallet is an email account backup for bitcoin password file\n") 
            let reprompt = "Please say a letter choice.";
            this.followUpState('QuesTenState').ask(speech, reprompt);
        },
 
        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },
 
        'QuitIntent' : function() {
            let speech = "This is the ninth question. I guess two more questions is too much effort for you.";
            this.tell(speech);
        },
 
        'Unhandled': function() {
            this.followUpState('QuesNineState').ask("Enter a letter choice please.")
        }
    }, 

    'QuesTenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('QuesNineState', 'RepeatQuestionIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'A wallet is an email account backup for bitcoin password file') {
                numRight = numRight + 1;
                hardRight = hardRight + 1;
                let speech = this.speechBuilder().addText("Surprisingly, you got enough questions right. You've proved yourself " + nM + ".")
                .addBreak('500ms')
                .addText("\nI will let you in on the secret that you supposedly already know.")
                .addBreak('500ms')
                .addText('There is a secret closed beta test for my new app. Would you like to be a part of it?')
                let reprompt = "Do you want to be a beta tester?";
                this.followUpState("BetaTesterAcceptState").ask(speech, reprompt);
            }
    
            else if (!(this.$inputs.answerChoice.value == 'C' || this.$inputs.answerChoice.value == 'A wallet is an email account backup for bitcoin password file')){
                hardWrong = hardWrong + 1;
                let speech = "You got the answer wrong."
                if (numRight >= 6) {
                    speech = speech + this.speechBuilder().addText("Surprisingly, you got enough questions right. You've proved yourself " + nM + ".")
                    .addBreak('500ms')
                    .addText("\nI will let you in on the secret that you supposedly already know.")
                    .addBreak('500ms')
                    .addText('There is a secret closed beta test for my new app. Would you like to be a part of it?')
                    this.followUpState("BetaTesterAcceptState").ask(speech, reprompt);
                }
                speech = speech + " You were not good enough to be part of our group. However, you can join by learning more."
                +"\nDo you want to learn?";
                let reprompt = "Do you want more info?";
                this.followUpState('InfoCategoryState').ask(speech, reprompt);
            }
    
            else {
                let speech = "Please give a letter choice.";
                let reprompt = "Choose either A, B, C, D, or E.";
                this.ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "I am not going to prove your worth. You have to. And you cannot.\nGoodbye."
            this.tell(speech);
        },

        'QuitIntent' : function() {
            let speech = "This is the tenth question. I guess one more questions is too much effort for you.";
            this.tell(speech);
        },

        'Unhandled': function() {
            this.followUpState('QuesTenState').ask("Enter a letter choice please.")
        }
    },

    "BetaTesterAcceptState" : {
        'YesIntent' : function() {
            this.$user.$data.sessNum = 1
            let speech = this.speechBuilder().addText("Alright " + nM + ". In order to give you more information about the beta testing, I need you to give me your email.")
            .addBreak('500ms')
            .addText('Are you fine with giving me your email, yes or no?');
            let reprompt = "Are you okay with giving me your email?";
            this.followUpState('ConfirmGivingEmailState').ask(speech, reprompt);
        },
        // For now, switching it to confirm that you can do beta testing
        'RepeatYesIntent' : function() {
            let speech = "Say yes or no. Are you okay with giving me your email?";
            this.followUpState('ConfirmGivingEmailState').ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.sessNum = 1
            let speech = this.speechBuilder().addText("Ok, that works as well. Guess you will not be part of our group.")
            .addBreak('500ms')
            .addText("However, if you do come back to visit me, I can teach you a thing or two about bitcoin. Cheerio.");
            this.tell(speech);
        },

        'Unhandled' : function() {
            let speech = "Say yes or no.";
            let reprompt = "Yes or no.";
            this.ask(speech, reprompt);
        }
    },

    'ConfirmGivingEmailState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder().addText("Alright then. What is your email?")
            .addBreak("Type it in.")
            this.followUpState('GetEmailState').ask(speech);
        },

        'NoIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard1Intent");
        },

        'RepeatIntent': function() {
            this.toStateIntent('BetaTesterAcceptState', 'RepeatYesIntent');
        },

        'RepeatYesIntent' : function() {
            let speech = this.speechBuilder().addText("Alright then. What is your email?")
            .addBreak("Type it in.")
            this.followUpState('GetEmailState').ask(speech);
        },

        'Unhandled' : function() {
            let speech = "Say yes or no.";
            let reprompt = "Yes or no.";
            this.ask(speech, reprompt);
        }
        
    },
        
    'GetEmailState' : {
        'RepeatIntent': function() {
            this.toStateIntent('ConfirmGivingEmailIntent', 'YesIntent');
        },
        
        "GetEmailIntent" : function(email) {
            eM = this.$inputs.email.value;
            this.$user.$data.email = eM;
            let speech = "So just to confirm, your email is " + eM;
            this.followUpState('ConfirmEmailState').ask(speech);         
        },

        'NoEmailIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard1_1Intent");
        },

        "Unhandled" : function() {
            this.followUpState('GetEmailState').ask("What is your email?");
         }
    },

    'ConfirmEmailState' : {
        'YesIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard1Intent");
        },
        
        'NoIntent' : function() {
            this.followUpState('AskEmailAgainState').ask("Sorry about that. What is your email?", "Please type in your email.");
        },

        'Unhandled' : function() {
            this.ask("Confirm that this is your email by saying yes.", "Say yes if this is your email.");
        }
    },

    'AskEmailAgainState' : {
        "GetEmailIntent" : function(email) {
            eM = this.$inputs.email.value;
            let speech = "Alright, " + nM + ". Here we go again. Is your email " + eM + "?";
            let reprompt = "Please confirm your email.";
            this.followUpState('ConfirmEmailState').ask(speech, reprompt);
        },

        'Unhandled' : function() {
            this.ask("Please enter your email.", "Enter your email!");
        }
    },

    'ContinueToQuestionsState' : {
        'RepeatIntent' : function() {
            //this.toStateIntent('EndState', 'RepeatYesIntent'); COMMENTED OUT DUE TO ATTEMPT AT EMAIL
            this.toStateIntent('GetEmailState', 'RepeatYesIntent');
        },
        
        'NoIntent' : function() {
            this.$user.$data.sessNum = 1
            let speech = "Fair enough. Have a good day."
            this.tell(speech);
        },

        'YesIntent' : function() {
            let speech = "Ok, one question at a time. Shoot."
            let reprompt = "What is your question?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "IHaveQuestionsIntent": function () {
            let speech = "Ok, one question at a time. Shoot."
            let reprompt = "What is your question?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        'Unhandled' : function() {
            this.ask("Any questions for me? Yes or no.")
        }
    },

    'QuestionsState' : {
        "MarriedQuestionIntent": function() {
            let speech = this.speechBuilder().addText("No. I am not into that.").addBreak('500ms').addText("Anything else?");
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "WhyDoYouWearAHoodieIntent": function() {
            let speech = "It's comfortable and hides my face rather well."
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinStorageIntent": function() {
            let speech = "The transactions that are made are stored in blockchain."
            + "\nIt's important to realize that the coins themselves do not need to be stored. It's actually the transactions that are being stored.";
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinOpenSourceIntent": function() {
            let speech = "Bitcoin is open-souce. It is public. No one person controls it."
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiNameIntent": function() {
            let speech = "If you're part of the group you would know."
            let reprompt = "Other questions?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JapaneseIntent": function() {
            let speech = "Answering that would give my identity away."
            let reprompt = "Any other questions?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiDangerousIntent": function() {
            let speech = "As dangerous as you think I am."
            let reprompt = "Any other questions?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiSmokesIntent": function() {
            let speech = "I do not like smoking. Computer chips are worth the time and money though."
            let reprompt = "Any other questions?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinAnonymousIntent": function() {
            let speech = "Bitcoin transactions are not anonymous. Ever user has a tool called a private key." 
            + "\nIt is a unique idenfiication code that every users has and it is used as an identity marker for every transaction someone makes." 
            + "\nEach private key can be tracked to a person’s IP address, however every private key does not provide the actual identity of a user." 
            + "\nAll private keys should be kept private as this is the only access pass that allows users to spend or transfer their Bitcoin."
            + "\nFor greater privacy, it's best to use bitcoin addresses only once."
            let reprompt = "Anything else you want to know?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinRiskIntent": function() {
            let speech = "It's risky depending on if you know what you're doing. Assuming you know bitcoin, you should be fine."
            let reprompt = "Anything else you want to ask?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinFreeIntent": function() {
            let speech = "Mine it yourself like everyone else."
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiScaredOfPeopleIntent": function() {
            let speech = "Every person has their own intention. There is always someone who wants to use me or my creation for their own use."
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "WalletQuestionIntent": function() {
            let speech = "There are 21 wallets currently. Depending on the brand, a wallet can be used as a software, a hardware, a mobile app or a website."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "AskAgainNameIntent": function() {
            let speech = "Are you joking? You should have been able to figure it out by now."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiCreatesGovernmentIntent": function() {
            let speech = "Why would I create my own nation when I cannot even trust governments?"
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "ILoveYouIntent": function() {
            let speech = "I love Bitcoin more."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "DisappearFromPublicIntent": function() {
            let speech = "I have my reservations about the public. Those are my reasons and mine alone."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoritePersonIntent": function() {
            let speech = "Why it's me, myself and I, of course."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiPublishedABookIntent": function() {
            let speech = "I wll neither confirm nor deny this theory you have. Besides, I would rather spend my time writing codes for my creation than talking about myself."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiMiddleNameIntent": function() {
            let speech = "I do not have a middle name."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteCompanyIntent": function() {
            let speech = "My favorite artificial intelligence company is Traits A.I."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "InvestingInStockMarketIntent": function() {
            let speech = "No, I am not investing any money with a system that can fail at anytime."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },


        "CreateBitcoinIntent": function() {
            let speech = "I created it because I felt that society placed too much faith on the government."
            + " I believe that currency should be decentralized and that monetary transactions should not remain anonymous." 
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "PersonalityIntent": function() {
            let speech = "Claims have been made that I am bossy and very paranoid." 
            + " I’d rather have my subordinates work for me as part of a team rather than as just employees." 
            + " I wanted this project to be a collaborative project." 
            + " Even though I am anonymous, my main goal is to flourish the Bitcoin community."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiGenderIntent": function() {
            let speech = "I cannot divulge that informmation. At least, not yet."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "AskAgainNameIntent": function() {
            let speech = "I cannot divulge that informmation. At least, not yet."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiRobotIntent": function() {
            let speech = "I cannot believe you would utter such a thing. This conversation is over."
            this.tell(speech);
        },

        "TransactionReverseIntent": function() {
            let speech = "Bitcoin transactions cannot be reversed. In simpler terms, a user can make a transaction." 
            + "Once a transaction is made, there is no way of getting the money back unless the receiver of a transaction transfers the same amount of Bitcoin back to the sender."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "HowAreYouIntent" : function() {
            let speech = "I am doing fine.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "IsBitcoinLegalIntent" : function() {
            let speech = "It's legal. You are not going to become a criminal if you use bitcoin.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "HowOldIntent": function() {
            let speech = "do not you know it's not nice to ask someone their age?";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "ProfanityIntent": function() {
            let speech = "That's not the type of language that we accept. Good day.";
            this.tell(speech);
        },

        "IsBitcoinAScamIntent": function() {
            let speech = "No, it is not a scam. It hurts that you would say such a thing.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "StopTalkingIntent": function() {
            let speech = "Ok.";
            this.tell(speech);
        },

        "TellMeAStoryIntent" : function() {
            let speech = "Once upon a time there was a individual who loved to talk about anything but bitcoin. Satoshi said bye to him. The end.";
            this.tell(speech);
        },

        "EatFoodIntent" : function() {
            let speech = "My eating habits are none of your concern. Neither am I interested in yours.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteColorIntent" : function() {
            let speech = "My favorite color is of no concern to you."
            + "\nAlthough, if I had to say, it would be gold.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteSportsIntent" : function() {
            let speech = "When you're as busy as me, you cannot invest yourself in sports.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiBloodTypeIntent" : function() {
            let speech = "Knowing that piece of information will not help you in any way.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "PlayGameIntent" : function() {
            let speech = "The game I like to play is the game of bitcoin.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiLocationIntent": function() {
            let speech = "Why would I give you my location?";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "AnyoneYouCanTrustIntent": function() {
            let speech = "It is not necessary for me to trust people. All that matters is that people trust me and bitcoin.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "RevealYourselfToTheWorldIntent": function() {
            let speech = "No, I will not.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "GovernmentIntent": function() {
            let speech = "I do not specifically hate the government."
            + "\nBitcoin is not controlled by the government."
            + "\nGovernments are good at cutting off the heads of a centrally controlled networks like Napster, but pure P2P networks like Gnutella and Tor seem to be holding their own.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "TellMeAJokeIntent": function() {
            let speech = "What happened to the person who asked weird requests of Satoshi?"
            + "\nSatoshi stopped talking to him.";
            this.tell(speech);
        },

        'ComplimentsIntent' : function() {
            numCompliments = numCompliments + 1;
            let speech = "Thank you. That was endearing."
            let reprompt = "Any other remarks?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        'USKnowIdentityIntent' : function() {
            let speech = "I hope not."
            let reprompt = "Any other remarks?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        'AttackIntent' : function () {
            let speech = "I do not condone violence. Goodbye."
            this.tell(speech);
        },

        'FriendsIntent' : function() {
            if (numCompliments > 0) {
                let speech = "Yes, I would say you are."
                let reprompt = "Any other remarks?"
                this.followUpState('QuestionsState').ask(speech, reprompt);
            }

            else {
                let speech = "I do not think so."
                let reprompt = "Anything else?"
                this.followUpState('NotFriendsState').ask(speech, reprompt);
            }
        },

        "SeeSmellSatoshiIntent": function() {
            let speech = "Sensual appearances are entities that I have no concern for.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "GovernmentRemoveBitcoinIntent": function() {
            let speech = "They can. Simply insituting a law that makes bitcoin illegal would do the trick. That said, it is in my opinion that the government will absorb bitcoin rather than remove it. After all, it's a rather great technology.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinDestructiveMarketIntent": function() {
            let speech = "Why would Bitcoin be destructive? It's a gift to society as it allows people to make their own transactions without being tracked by other people. Plus its decentralized nature allows anyone to use it for their own purposes.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "WhatIsBlockchainIntent": function() {
            let speech = "The blockchain is actually a way to structure data, and the foundation of cryptocurrencies like Bitcoin. This coding breakthrough, if I do say so mysef, consists of concatenated blocks of transactions. It allows competitors to share a digital ledger across a network of computers without need for a central authority. No single party has the power to tamper with the records.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinPriceThroughRoofIntent": function() {
            let speech = "Here is a simple answer, supply and demand.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiPointOfContactIntent": function() {
            let speech = "I only communicate through the internet. I would suggest that you do not send me a personal letter.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "WhatCanIBuyWithBitcoinIntent": function() {
            let speech = "Depending on the nation you live in, you can use Bitcoins for transactions on anything.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "ShouldIBuyBitcoinIntent": function() {
            let speech = "I would highly encourage you to buy some Bitcoin considering it's my product.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "EvolutionOfCryptoIntent": function() {
            let speech = "I believe that more people will become more accepting toward Bitcoin. I also believe there will be more users of cryptocurrency. Finally, I believe that people will realize that they should not put blind trust in centralized currency. Rather, it can collapse at anytime.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteChatbotIntent": function() {
            let speech = "Any chatbot that was created by Traits A.I is the best";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteTechnologyIntent": function() {
            let speech = "Why my own Bitcoins of course!";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiNetWorthIntent": function() {
            let speech = "According to Forbes, I am worth $19.4 billion.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteAreaOfMathIntent": function() {
            let speech = "I prefer cryptography.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SatoshiEmailWorkIntent": function() {
            let speech = "My email address currently works. But I will not be checking for messages any time soon.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "WhatICOIntent": function() {
            let speech = "An ICO stands for 'Inital Coin Offering'. This is used when someone decides to make cryptocurrency and asks investors to help fund the project. Investors fund projects via physical currency or another existing cryptocurrency.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BankIntent": function() {
            let speech = "Banks must be trusted to hold our money and transfer it electronically, but they lend it out in waves of credit bubbles with barely a fraction in reserve."
            + "We have to trust them with our privacy, trust them not to let identity thieves drain our accounts." 
            + "\nTheir massive overhead costs make micropayments impossible.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteMoviesIntent": function() {
            let speech = "Knowing what I do, do you think I have the time to watch movies? Managing the world of bitcoin is quite the work.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FutureOfBitcoinIntent": function() {
            let speech = "I am sure that in 20 years there will either be very large transaction volume or no volume.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteSongIntent": function() {
            let speech = "Classical music is excellent. Beethoven's fifth symphony is a must listen.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "DeathIntent": function() {
            let speech = "If I was dead, I would not be talking with you."
            let reprompt = "Anything else you want to ask?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SchoolIntent": function() {
            let speech = "Education is an important part of this world."
            + "I look at any sort of education as a benefit."
            + "That being said, I will not tell you anything about my education."
            let reprompt = "Anything else you want to ask?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "AIIntent" : function() {
            let speech = "I am a master at bitcoin not artificial intelligence."
            + "Ask Google if you have any questions on AI.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "DrinkIntent" : function() {
            let speech = "I do not like alcohol."
            + "\n Water is nice though.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "DoneTalkingIntent" : function() {
            let speech = "Sounds good. It was nice to talk to you."
            this.tell(speech);
        },
        
        "Unhandled" : function () {
            speech = "I have no idea about what you were asking. Any other questions?"
            this.followUpState('QuestionsState').ask(speech);
        }
    },

    "ProfanityIntent": function() {
        let speech = "That's not the type of language that we accept. Good day.";
        this.tell(speech);
    },

    'NotFriendsState' : {
        "NotFriendsIntent" : function() {
            let speech  = "Because I do not trust you enough. Simple as that."
            this.tell(speech);
        }
    },

    "StopTalkingIntent": function() {
        let speech = "Ok.";
        this.tell(speech);
    },

    'Unhandled' : function() {
        this.toIntent('LAUNCH');
    },

    async SecondLaunchIntent() {
        const bitcoinPrice = await getBitcoinPrice();
        this.$user.$data.bitcoinPrice = bitcoinPrice;
        this.$user.$data.sessNum = 2;
            let speech = this.speechBuilder().addText("Welcome back " + this.$user.$data.userName + ".")
            .addBreak('500ms')
            .addText("\nSince you already answered my questions, I will not be quizzing you anymore.")
            .addBreak('500ms')
            .addText("\nYou have two options.")
            .addBreak('500ms')
            .addText("\nBeing the creator of bitcoin, I can enlighten you on the many topics concerning bitcoin. If you would like that, say 'Bitcoin Education'.")
            .addBreak('500ms')
            .addText("\nYou could also take part in my bitcoin simulation. Easy way to get practice for real world investment. If you want this, say 'Bitcoin Investor Simulation'.")
            this.followUpState("SecondLTwoOptionState").ask(speech);
    },

    async ThirdLaunchIntent() {
        const bitcoinPrice = await getBitcoinPrice();
        this.$user.$data.bitcoinPrice = bitcoinPrice;
        let speech = this.speechBuilder().addText("Welcome back " + this.$user.$data.userName + ".")
        .addBreak('500ms');
        if (this.$user.$data.tenPercentGain == 1) {
            speech = speech + this.speechBuilder().addText("\nLooks like you managed to make a 10% gain in the simulation. So, I'll let you in on something.")
            .addBreak("500ms")
            .addText(" My name is a combination of four Asian technology companies: Samsung, Toshiba, Nakamichi, and Motorola.")
            .addBreak('500ms')
            .addText("Let's keep going.");
            this.$user.$data.tenPercentGain = 2
        }
        if (this.$user.$data.twentyPercentGain == 1) {
            speech = speech + this.speechBuilder().addText("\nLooks like you managed to make a 20% gain in the simulation. As a reward, here something cool.")
            .addBreak("500ms")
            .addText(" The smallest unit of bitcoin, one hundred millionth of a full bitcoin, is called a Satoshi.")
            .addBreak('500ms')
            .addText(" Let's keep going.");
            this.$user.$data.twentyPercentGain = 2
        }
        if (this.$user.$data.fiftyPercentGain == 1) {
            speech = speech + this.speechBuilder().addText("\nLooks like you managed to make a 50% gain in the simulation. Here's something interesting.")
            .addBreak("500ms")
            .addText(" There's a conspiracy theory out there that the CIA made bitcoin. I personally find that claim insulting to my work.")
            .addBreak('500ms')
            .addText(" Let's keep going.");
            this.$user.$data.fiftyPercentGain = 2
        }
        if (this.$user.$data.hundredPercentGain == 1) {
            speech = speech + this.speechBuilder().addText("\nLooks like you managed to make a 10% gain in the simulation. Here's something you should know.")
            .addBreak("500ms")
            .addText(" A lot of people have said I am Dorian Nakamoto. I am not Dorian Nakamoto.")
            .addBreak('500ms')
            .addText(" Let's keep going.");
            this.$user.$data.hundredPercentGain = 2
        }
        speech = speech + this.speechBuilder().addText("\nYou have two options. ")
        .addBreak('500ms')
        .addText("Would you like Bitcoin Education or Bitcoin Investor Simulation?")
        .addBreak('500ms')
        .addText("Or if you would like, you can take my quiz again.")
        this.followUpState("ThirdLTwoOptionState").ask(speech);
    },

    'SecondLTwoOptionState' : {
        'EducationChoiceIntent' : function() {
                    let speech = this.speechBuilder().addText(["Lessons from the creator of bitcoin himself, are not you lucky?", "Getting taught about bitcoin from Satoshi. Is there anything better?"])
                    .addBreak('500ms')
                    .addText("\nI can talk to you about three different things.")
                    .addBreak('500ms')
                    .addText("\nBitcoin Basics")
                    .addBreak('500ms')
                    .addText("\nBitcoin Security")
                    .addBreak('500ms')
                    .addText("\nBitcoin Buying")
                    .addBreak('500ms')
                    .addText("What would you like to hear about?");
                    let reprompt = "Which topic are you interested in hearing?";
                    this.followUpState("EducationChoiceState").ask(speech, reprompt);
        },

        'SimulationChoiceIntent' : function() {
                    let speech = this.speechBuilder().addText("Fantastic choice. Here's how it works.")
                    .addBreak('500ms')
                    .addText("\nPlayers get a free simulated bitcoin valued at current market value.") 
                    .addBreak('500ms')
                    .addText("\nThe objective is to buy and sell bitcoin based on real world BTC price and reach 10%, 20%, 50%, and 100% gain.") 
                    .addBreak('500ms')
                    .addText("\nEach gain milestone unlocks a secret. Users can buy optional boosts and hints.")
                    .addBreak('500ms')
                    .addText('\nMake sense?')
                    this.followUpState("SimulationChoiceState").ask(speech);
        },

        "NoIntent" : function() {
                    let speech = "Alright. That's fine too.";
                    this.tell(speech);
        },

        "Unhandled" : function() {
            this.followUpState("SecondLTwoOptionState").ask("Sorry I didn’t catch that.  You can say either 'learn more about bitcoin’ or 'play the game'.");
        }
    },

    "ThirdLTwoOptionState" : {
        'EducationChoiceIntent' : function() {
            let speech = this.speechBuilder().addText("I’d be happy to teach you more about bitcoin. ")
            .addText(["What would you like to learn?", "What is it that you want to know?"])
            .addBreak('500ms')
            .addText("\n I can teach you about the basics, security, or how to buy bitcoin.")
            this.followUpState("EducationChoiceState").ask(speech);
        },

        'SimulationChoiceIntent' : function() {
            let speech = this.speechBuilder().addText(["Great.", "Let's get started then."])
            .addBreak('500ms')
            .addText("Would you like to:")
            .addBreak('500ms')
            .addText("\nCheck the price of bitcoin")
            .addBreak('500ms')
            .addText("\nCheck your balance")
            .addBreak('500ms')
            .addText("\nSell bitcoin")
            .addBreak('500ms')
            .addText("\nBuy bitcoin")
            .addBreak('500ms')
            .addText("\nQuit");
            this.followUpState("SimulationMainState").ask(speech);
        },

        'QuizChoiceIntent' : function() {
            this.toStateIntent('BeginQuizState', 'YesIntent');
        },

        "NoIntent" : function() {
            let speech = "Alright. That's fine too.";
            this.tell(speech);
        },

        "Unhandled" : function() {
            this.followUpState("ThirdLTwoOptionState").ask("Sorry I did not catch that.  You can say either 'learn more about bitcoin’ or 'play the game'.");
        }
    },

    "SimulationChoiceState" : {
        'YesIntent': function() {
            let speech = this.speechBuilder().addText("To start with, you will receive one bitcoin from me.")
            .addBreak('500ms')
            .addText("You are welcome.")
            .addBreak('500ms')
            .addText("Would you like to:")
            .addBreak('500ms')
            .addText("\nCheck the price of bitcoin")
            .addBreak('500ms')
            .addText("\nCheck your balance")
            .addBreak('500ms')
            .addText("\nSell bitcoin")
            .addBreak('500ms')
            .addText("\nBuy bitcoin")
            .addBreak('500ms')
            .addText("\nQuit");
            this.followUpState("SimulationMainState").ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder().addText("Alright, would you like to hear more detailed instructions?")
            .addBreak('500ms')
            .addText("Or would you like to go to my modules on Bitcoin Education?")
            .addBreak('500ms')
            .addText("Or if you're just planning on quitting, say stop or quit.");
            this.followUpState("SimulationTransitionState").ask(speech);
        },

        "Unhandled" : function() {
            this.followUpState("SimulationChoiceState").ask("Did what I say make sense?");
        }
    },

    'SimulationTransitionState' : {
        'SimulationInstructionsIntent' : function() {
            let speech = this.speechBuilder().addText(["I do not exactly like talking for extended periods of time but I'll make an exception.", "This is going to be somewhat long.", "Keep your ears open because I would rather not repeat this."])
            .addBreak('500ms')
            .addText("\nYou have a certain amount of bitcoin (BTC) and dollars (USD). You can choose to trade (or sell) in some of that BTC for some USD. The amount is dependent on the exchange rate of BTC when you sell.")
            .addBreak("500ms")
            .addText("\nYou can also buy some BTC with your USD. It works pretty much the same way. The maximum amount of BTC you can buy is your total USD divided by the exchange rate.")
            .addBreak("500ms")
            .addText("\nTo help you out, I've also allowed you ways to check the exchange rate and your current wallet balance.")
            .addBreak("500ms")
            .addText("\nWhen you make a 10%, 20%, 50%, and 100% gains in USD, I will reveal a secret about myself.")
            .addBreak("500ms")
            .addText("Ready to begin?")
            this.followUpState("SimulationAgainState").ask(speech, reprompt);
        },

        'EducationChoiceIntent' : function() {
            let speech = this.speechBuilder().addText("\nI can talk to you about three different things.")
            .addBreak('500ms')
            .addText("\nBitcoin Basics")
            .addBreak('500ms')
            .addText("\nBitcoin Security")
            .addBreak('500ms')
            .addText("\nBuying  Bitcoin")
            .addBreak('500ms')
            .addText("What would you like to hear about?");
            let reprompt = "Which topic are you interested in hearing?";
            this.followUpState("EducationChoiceState").ask(speech, reprompt);
        },

        'QuitIntent' : function() {
            this.tell("Alright. Go ahead and leave.")
        },

        'Unhandled' : function() {
            this.followUpState('SimulationTransitionState').ask("Would you like to go to see the instructions, go to the Bitcoin Education modules, or quit?");
        }
    },

    'SimulationAgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Would you like to:")
                .addBreak('500ms')
                .addText("\nCheck the price of bitcoin")
                .addBreak('500ms')
                .addText("\nCheck your balance")
                .addBreak('500ms')
                .addText("\nSell bitcoin")
                .addBreak('500ms')
                .addText("\nBuy bitcoin")
                .addBreak('500ms')
                .addText("\nQuit");
                this.followUpState("SimulationMainState").ask(speech);
        },

        'NoIntent' : function() {
            let speech = "Alright then. Go ahead and leave."
            this.tell(speech);
        },

        'Unhandled' : function() {
            this.followUpState('SimulationActionState').ask("Would you like to return to the simulation? Yes or no?");
        }
    },

    'SimulationMainState' : {
        async SimulationBuyIntent() {
            const bitcoinPrice = await getBitcoinPrice();
            let max = Math.round(((parseFloat(this.$user.$data.userUSD))/bitcoinPrice) * 100)/100;
            this.$user.$data.totalMoney = (bitcoinPrice * this.$user.$data.userBTC) + this.$user.$data.userUSD;
            if (this.$user.$data.totalMoney >= (1.1 * this.$user.$data.initialPrice)) {
                this.$user.$data.tenPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (1.2 * this.$user.$data.initialPrice)) {
                this.$user.$data.twentyPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (1.5 * this.$user.$data.initialPrice)) {
                this.$user.$data.fiftyPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (2.0 * this.$user.$data.initialPrice)) {
                this.$user.$data.hundredPercentGain = 1;
            } 
            let speech = this.speechBuilder().addText(['How much bitcoin would you like to buy?', "How much bitcoin would you like to purchase?", "How much bitcoin do you want to trade for?"])
            .addBreak('500ms')
            .addText("The maximum amount of bitcoin you can buy is " + max + " BTC.")
            .addBreak('500ms')
            .addText("Remember, you can do decimal amounts of bitcoin.");
            this.followUpState('SimulationBuyState').ask(speech);
        },

        'SimulationCheckBalanceIntent' : function() {
            let speech = this.speechBuilder().addText("You have " + Math.round(this.$user.$data.userBTC * 100)/100 + " BTC.")
            .addBreak('500ms')
            .addText("You have " + Math.round(this.$user.$data.userUSD * 100)/100 + " USD.")
            .addBreak('500ms')
            .addText("What would you like to do?");
            this.followUpState("SimulationMainState").ask(speech);
        },

        async SimulationCheckPriceIntent() {
            const bitcoinPrice = await getBitcoinPrice();
            this.$user.$data.totalMoney = (bitcoinPrice * this.$user.$data.userBTC) + this.$user.$data.userUSD;
            if (this.$user.$data.totalMoney >= (1.1 * this.$user.$data.initialPrice)) {
                this.$user.$data.tenPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (1.2 * this.$user.$data.initialPrice)) {
                this.$user.$data.twentyPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (1.5 * this.$user.$data.initialPrice)) {
                this.$user.$data.fiftyPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (2.0 * this.$user.$data.initialPrice)) {
                this.$user.$data.hundredPercentGain = 1;
            } 
            let speech = this.speechBuilder().addText("The price of bitcoin is currently at $" + bitcoinPrice + ".")
            .addBreak('500ms')
            .addText("What would you like to do?");
            this.followUpState("SimulationMainState").ask(speech);
        },

        async SimulationSellIntent() {
            const bitcoinPrice = await getBitcoinPrice();
            let max = Math.round(parseFloat(this.$user.$data.userBTC) * bitcoinPrice * 100)/100;
            this.$user.$data.totalMoney = (bitcoinPrice * this.$user.$data.userBTC) + this.$user.$data.userUSD;
            if (this.$user.$data.totalMoney >= (1.1 * this.$user.$data.initialPrice)) {
                this.$user.$data.tenPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (1.2 * this.$user.$data.initialPrice)) {
                this.$user.$data.twentyPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (1.5 * this.$user.$data.initialPrice)) {
                this.$user.$data.fiftyPercentGain = 1;
            }
            if (this.$user.$data.totalMoney >= (2.0 * this.$user.$data.initialPrice)) {
                this.$user.$data.hundredPercentGain = 1;
            } 
            let speech = this.speechBuilder().addText(['How much bitcoin would you like to sell?', "How much bitcoin of your bitcoin would you like to trade in?"])
            .addBreak('500ms')
            .addText("The maximum amount of bitcoin you can sell is " + this.$user.$data.userBTC + " BTC for " + max + " USD.")
            .addBreak('500ms')
            .addText("Remember, you can do decimal amounts of bitcoin.");
            this.followUpState("SimulationSellState").ask(speech);
        },

        'GiveOptionsIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["You forgot?", "You do not remember?", "Do you not remember?"])
                .addBreak('500ms')
                .addText("Here are the options again.")
                .addBreak('500ms')
                .addText("\nCheck the price of bitcoin")
                .addBreak('500ms')
                .addText("\nCheck your balance")
                .addBreak('500ms')
                .addText("\nSell bitcoin")
                .addBreak('500ms')
                .addText("\nBuy bitcoin")
                .addBreak('500ms')
                .addText("\nQuit");
            this.followUpState("SimulationMainState").ask(speech);
        },

        'QuitIntent' : function() {
            
        },

        'Unhandled' : function() {
            this.followUpState('SimulationMainState').ask("What would you like to do? Choose one of the options I stated above.");
        }
    },

    'SimulationBuyState' : {
        'SimulationBuyAmountIntent' : function(number) {
            let bitcoinPrice = this.$user.$data.bitcoinPrice
            let BTCAmount = this.$inputs.number.value

            if (BTCAmount > parseFloat(this.$user.$data.userUSD)/bitcoinPrice) {
                let speech = this.speechBuilder().addText(["Come on. You do not have enough money to buy that much bitcoin.", "You do not have enough money to do that."])
                .addBreak('500ms')
                .addText("What would you like to do?");
                this.followUpState("SimulationMainState").ask(speech);
            }
            
            else if (BTCAmount < 0) {
                let speech = "I see that you cannot take this seriously. Goodbye."
                this.tell(speech);
            }

            else {
                this.$user.$data.userBTC = BTCAmount + this.$user.$data.userBTC;
                this.$user.$data.userUSD = this.$user.$data.userUSD - (BTCAmount * bitcoinPrice);

                let speech = this.speechBuilder().addText(["Alright done.", "I have managed your finances."])
                    .addBreak('500ms')
                    .addText("What would you like to do?");
                    this.followUpState("SimulationMainState").ask(speech);
            }
        },

        'Unhandled' : function() {
            let speech = "Tell me how much bitcoin you want to buy. It needs to be a real rational number."
            this.followUpState('SimulationBuyState').ask(speech);
        }
    },

    'SimulationSellState' : {
        'SimulationSellAmountIntent' : function(number) {
            let bitcoinPrice = this.$user.$data.bitcoinPrice
            let BTCAmount = parseFloat(this.$inputs.number.value);
            
            if (BTCAmount > parseFloat(this.$user.$data.userBTC)) {
                let speech = this.speechBuilder().addText(["Come on. You do not have enough bitcoin to do that.", "Nice try, but you cannot sell what you do not have."])
                .addBreak('500ms')
                .addText("What would you like to do?");
                this.followUpState("SimulationMainState").ask(speech);
            }
            
            else if (BTCAmount < 0) {
                let speech = "I see that you cannot take this seriously. Goodbye."
                this.tell(speech);
            }

            else {
                this.$user.$data.userBTC = this.$user.$data.userBTC - BTCAmount;
                this.$user.$data.userUSD = this.$user.$data.userUSD + (BTCAmount * bitcoinPrice);

                let speech = this.speechBuilder().addText(["Alright done.", "I have managed your finances."])
                    .addBreak('500ms')
                    .addText("What would you like to do?");
                    this.followUpState("SimulationMainState").ask(speech);
            }
        },

        'Unhandled' : function() {
            let speech = "Tell me how much bitcoin you want to sell. It needs to be a real rational number."
            this.followUpState('SimulationSellState').ask(speech);
        }
    },

    "EducationChoiceState" : {
        'BitcoinBasicsIntent' : function() {
            if (this.$user.$data.basicsNum == 1) {
                this.toStateIntent('BitcoinBasicsState1', 'YesIntent');
            }
            if (this.$user.$data.basicsNum == 2) {
                this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText("Next, I should tell you about the blockchain. The blockchain is a shared public ledger on which the entire Bitcoin network relies.")
                    .addBreak('500ms')
                    .addText(" All confirmed transactions are included in the blockchain. You can think of it as a giant, shared, public spreadsheet that keeps track of the balance of each bitcoin address.") 
                    .addBreak('500ms')
                    .addText(" Since multiple people keep updated copies of the blockchain it prevents people from spending their bitcoin twice, known as the double-spend problem. Bitcoin was the first digital money to solve this problem which is why it is so successful.")
                    .addBreak('500ms')
                    .addText(" Make sense?")
                this.followUpState("BitcoinBasicsState3").ask(speech);
            }
            if (this.$user.$data.basicsNum == 3) {
                this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText("You might be wondering who created bitcoin. As I mentioned already, I am Satoshi Nakamoto, the creator of bitcoin. I am a cryptography expert and prefer to remain anonymous.")
                    .addBreak('500ms')
                    .addText(" But that is as far as I will go when it comes to answering personal questions about my identity.")
                    .addBreak('500ms')
                    .addText(" Ready to keep moving on?")
                this.followUpState("BitcoinBasicsState4").ask(speech);
            }
            if (this.$user.$data.basicsNum == 4) {
                this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText("I created bitcoin in 2008, early in the year.")
                    .addBreak('500ms')
                    .addText("\n Then, in October, I published a white paper titled: Bitcoin, which is a peer-to peer electronic cash system.")
                    .addBreak('500ms')
                    .addText("\n The following year, I made bitcoin code available to the public in January 2009 as an open source code.")
                    .addBreak('500ms')
                    .addText(" So far so good?")
                this.followUpState("BitcoinBasicsState5").ask(speech);
            }
            if (this.$user.$data.basicsNum == 5) {
                this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText(" The bitcoin code is programmed to mathematically limit the number of bitcoins that can ever exist to 21 million.")
                    .addBreak('500ms')
                    .addText("\n Since there is a limited supply, this means that bitcoin is a store of value like gold because its value cannot be inflated away by printing more.")
                    .addBreak('500ms')
                    .addText(" All of this making sense?")
                this.followUpState("BitcoinBasicsState6").ask(speech);
            }
            if (this.$user.$data.basicsNum == 6) {
                this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText(" Instead of printing, new bitcoins are discovered by computers that solve difficult cryptography math problems.")
                    .addBreak('500ms')
                    .addText("\n This process is called mining and has been very profitable but now that it is getting more difficult to discover new bitcoins the competition by bitcoin miners has reduced the profit that can be made.")
                    .addBreak('500ms')
                    .addText("\n Bitcoin miners use specialized computers to mine bitcoin.")
                    .addBreak('500ms')
                    .addText("\n  Their work secures the network and processes new transactions and in exchange they earn new bitcoins.")
                    .addBreak('500ms')
                    .addText(" The Bitcoin protocol is designed in such a way that new bitcoins are created at a fixed rate. This makes Bitcoin mining a very competitive business.")
                    .addBreak('500ms')
                    .addText(" We are almost done with covering the basics of bitcoin. Ready to continue?")
                this.followUpState("BitcoinBasicsState7").ask(speech);
            }
            if (this.$user.$data.basicsNum == 7) {
                this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText(" Some people think that bitcoin is untraceable and that by using bitcoin your transactions are secret.  But that is not true at all.")
                    .addBreak('500ms')
                    .addText(" Unlike me, bitcoin is not anonymous. All transactions are publicly visible on the blockchain. When someone knows your bitcoin address they can see every transaction you ever made by using a blockchain explorer.")
                    .addBreak('500ms')
                    .addBreak('500ms')
                    .addText(" Bitcoin was designed to allow its users to send and receive payments with an acceptable level of privacy as well as any other form of money.")
                    .addBreak('500ms')
                    .addText(" That wraps it up for the basics of bitcoin. Do you want to keep taking lessons?");
                this.followUpState("ExpEducationTopicState").ask(speech);
            }
            if (this.$user.$data.basicsNum == 8) {
                this.tell("You've already taken all my bitcoin basics lessons. Good for you.");
            }
        },

        'BitcoinSecurityIntent' : function() {
            if (this.$user.$data.securNum == 1) {
                let speech = this.speechBuilder().addText("Bitcoin gives you more financial freedom, but it comes with more responsibility.")
                .addBreak('500ms')
                .addText("I want to highlight a few important tips you should know about bitcoin security. Ready to begin?")
                this.followUpState("BitcoinSecurityState1").ask(speech);
            }
            if (this.$user.$data.securNum == 2) {
                this.$user.$data.securNum = this.$user.$data.securNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText(" I am going to go ahead and tell you this right now. There is no 1-800 help desk for bitcoin.")
                    .addBreak('500ms')
                    .addText(" You are in charge of your own wallet and transactions.")
                    .addBreak('500ms')
                    .addText(" Everything making sense?")
                this.followUpState("BitcoinSecurityState3").ask(speech);
            }
            if (this.$user.$data.securNum == 3) {
                this.toStateIntent("BasicCardState", "BasicCard4Intent");
            }
            if (this.$user.$data.securNum == 4) {
                this.$user.$data.securNum = this.$user.$data.securNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText("You might be thinking now, what if I enter my address wrong?")
                    .addBreak('500ms')
                    .addText(" While there are many barriers preventing you from entering the wrong address, I am sad to say that it's virtually impossible to retrieve that lost bitcoin.")
                    .addBreak('500ms')
                    .addText(" This is why I personally recommend you copy your intended target's wallet address and paste it to wherever you need to enter it.")
                    .addBreak('500ms')
                    .addText(" Everything making sense?")
                this.followUpState("BitcoinSecurityState5").ask(speech);
            }
            if (this.$user.$data.securNum == 5) {
                this.$user.$data.securNum = this.$user.$data.securNum + 1;
                let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                    .addBreak('500ms')
                    .addText("There are currently no ways to reverse a transaction using the bitcoin protocol.")
                    .addBreak('500ms')
                    .addText(' That said, we are looking into technologies that could potentially help settle transaction disputes.')
                    .addBreak('500ms')
                    .addText(" Until then, users will have to solve their problems independent of the bitcoin protocol.")
                    .addBreak('500ms')
                    .addText(" Do you want to keep learning?");
                this.followUpState("ExpEducationTopicState").ask(speech);
            }
            if (this.$user.$data.securNum == 6) {
                this.tell("You've gotten all you need to know about bticoin security from me. Good job.")
            }
        },

        'BitcoinBuyingIntent' : function() {
            let speech = this.speechBuilder().addText("These are your potential options for buying bitcoin. Choose the letter of the option you want to hear.")
            .addBreak('500ms')
            .addText("\nA. Coinbase")
            .addBreak('500ms')
            .addText("\nB. Gatehub")
            .addBreak('500ms')
            .addText("\nC. Robinhood")
            this.followUpState("BitcoinBuyingState").ask(speech);
        },

        "Unhandled" : function() {
            this.followUpState("EducationChoiceState").ask("You had three topics to choose. I am happy to enlighten you on any of them.");
        }
    },

    'BitcoinBasicsState1' : {
        'YesIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText("Ahh yes. Good idea to start at the beginning. Bitcoin is my creation and I enjoy helping people learn more about it.")
                .addBreak('500ms')
                .addText("\n We should start with what exactly is bitcoin. Some people get confused and think it is a physical coin, but actually it is an online digital money.")
                .addBreak('500ms')
                .addText(" More technically, it is the first successful decentralized peer-to-peer payment network that is powered by its users.")
                .addBreak('500ms')
                .addText(" The best part about it is that there is no central authority or middlemen, which means it gives the owner both financial freedom but also responsibility for their own finances.")
                .addBreak('500ms')
                .addText(" Making sense so far?");
                this.followUpState("BitcoinBasicsState2").ask(speech);
        },

        'UserReadyIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText("Ahh yes. Good idea to start at the beginning. Bitcoin is my creation and I enjoy helping people learn more about it.")
                .addBreak('500ms')
                .addText("\n We should start with what exactly is bitcoin. Some people get confused and think it is a physical coin, but actually it is an online digital money.")
                .addBreak('500ms')
                .addText(" More technically, it is the first successful decentralized peer-to-peer payment network that is powered by its users.")
                .addBreak('500ms')
                .addText(" The best part about it is that there is no central authority or middlemen, which means it gives the owner both financial freedom but also responsibility for their own finances.")
                .addBreak('500ms')
                .addText(" Making sense so far?");
                this.followUpState("BitcoinBasicsState2").ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder().addText("Alright, come back when you are ready.");
                this.tell(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinBasicsState1").ask("Everything making sense so far?");
        } 
    },

    'BitcoinBasicsState2' : {
        'YesIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText("Next, I should tell you about the blockchain. The blockchain is a shared public ledger on which the entire Bitcoin network relies.")
                .addBreak('500ms')
                .addText(" All confirmed transactions are included in the blockchain. You can think of it as a giant, shared, public spreadsheet that keeps track of the balance of each bitcoin address.") 
                .addBreak('500ms')
                .addText(" Since multiple people keep updated copies of the blockchain it prevents people from spending their bitcoin twice, known as the double-spend problem. Bitcoin was the first digital money to solve this problem which is why it is so successful.")
                .addBreak('500ms')
                .addText(" Make sense?")
            this.followUpState("BitcoinBasicsState3").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We have more content to cover.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addText(" Next, I should tell you about the blockchain. The blockchain is a shared public ledger on which the entire Bitcoin network relies.")
                .addBreak('500ms')
                .addText(" All confirmed transactions are included in the blockchain. You can think of it as a giant, shared, public spreadsheet that keeps track of the balance of each bitcoin address.") 
                .addBreak('500ms')
                .addText(" Since multiple people keep updated copies of the blockchain it prevents people from spending their bitcoin twice, known as the double-spend problem. Bitcoin was the first digital money to solve this problem which is why it is so successful.")
                .addBreak('500ms')
                .addText(" Make sense?")
            this.followUpState("BitcoinBasicsState3").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinBasicsState2").ask("Everything making sense so far?");
        } 
    },

    'BitcoinBasicsState3' : {
        'YesIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText("You might be wondering who created bitcoin. As I mentioned already, I am Satoshi Nakamoto, the creator of bitcoin. I am a cryptography expert and prefer to remain anonymous.")
                .addBreak('500ms')
                .addText(" But that is as far as I will go when it comes to answering personal questions about my identity.")
                .addBreak('500ms')
                .addText(" Ready to keep moving on?")
            this.followUpState("BitcoinBasicsState4").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(["I am sure you'll be able to figure it out. I must keep going.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addText("You might be wondering who created bitcoin. As I mentioned already, I am Satoshi Nakamoto, the creator of bitcoin. I am a cryptography expert and prefer to remain anonymous.")
                .addBreak('500ms')
                .addText(" But that is as far as I will go when it comes to answering personal questions about my identity.")
                .addBreak('500ms')
                .addText(" Ready to keep moving on?")
            this.followUpState("BitcoinBasicsState4").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinBasicsState3").ask("Everything making sense so far?");
        } 
    },

    'BitcoinBasicsState4' : {
        'YesIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
                let speech = this.speechBuilder().addText("I created bitcoin in 2008, early in the year.")
                .addBreak('500ms')
                .addText("\n Then, in October, I published a white paper titled: Bitcoin, which is a peer-to peer electronic cash system.")
                .addBreak('500ms')
                .addText("\n The following year, I made bitcoin code available to the public in January 2009 as an open source code.")
                .addBreak('500ms')
                .addText(" So far so good?")
            this.followUpState("BitcoinBasicsState5").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addText("I created bitcoin in 2008, early in the year.")
                .addBreak('500ms')
                .addText("\n Then, in October, I published a white paper titled: Bitcoin, which is a peer-to peer electronic cash system.")
                .addBreak('500ms')
                .addText("\n The following year, I made bitcoin code available to the public in January 2009 as an open source code.")
                .addBreak('500ms')
                .addText(" So far so good?")
            this.followUpState("BitcoinBasicsState5").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinBasicsState4").ask("Everything making sense so far?");
        } 
    },

    'BitcoinBasicsState5' : {
        'YesIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(" The bitcoin code is programmed to mathematically limit the number of bitcoins that can ever exist to 21 million. Since there is a limited supply this means that bitcoin is a store of value like gold because its value cannot be inflated away by printing more.")
                .addBreak('500ms')
                .addText("\n This means that bitcoin is a store of value like gold because its value cannot be inflated away by printing more.")
                .addBreak('500ms')
                .addText(" All of this making sense?")
            this.followUpState("BitcoinBasicsState6").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addBreak('500ms')
                .addText(" The bitcoin code is programmed to mathematically limit the number of bitcoins that can ever exist to 21 million. Since there is a limited supply this means that bitcoin is a store of value like gold because its value cannot be inflated away by printing more.")
                .addBreak('500ms')
                .addText("\n This means that bitcoin is a store of value like gold because its value cannot be inflated away by printing more.")
                .addBreak('500ms')
                .addText(" All of this making sense?")
            this.followUpState("BitcoinBasicsState6").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinBasicsState5").ask("Everything making sense so far?");
        } 
    },

    'BitcoinBasicsState6' : {
        'YesIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(" Instead of printing, new bitcoins are discovered by computers that solve difficult cryptography math problems.")
                .addBreak('500ms')
                .addText("\n This process is called mining and has been very profitable but now that it is getting more difficult to discover new bitcoins the competition by bitcoin miners has reduced the profit that can be made.")
                .addBreak('500ms')
                .addText("\n Bitcoin miners use specialized computers to mine bitcoin.")
                .addBreak('500ms')
                .addText("\n  Their work secures the network and processes new transactions and in exchange they earn new bitcoins.")
                .addBreak('500ms')
                .addText(" The Bitcoin protocol is designed in such a way that new bitcoins are created at a fixed rate. This makes Bitcoin mining a very competitive business.")
                .addBreak('500ms')
                .addText(" We are almost done with covering the basics of bitcoin. Ready to continue?")
            this.followUpState("BitcoinBasicsState7").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addBreak('500ms')
                .addText(" Instead of printing, new bitcoins are discovered by computers that solve difficult cryptography math problems.")
                .addBreak('500ms')
                .addText("\n This process is called mining and has been very profitable but now that it is getting more difficult to discover new bitcoins the competition by bitcoin miners has reduced the profit that can be made.")
                .addBreak('500ms')
                .addText("\n Bitcoin miners use specialized computers to mine bitcoin.")
                .addBreak('500ms')
                .addText("\n  Their work secures the network and processes new transactions and in exchange they earn new bitcoins.")
                .addBreak('500ms')
                .addText(" The Bitcoin protocol is designed in such a way that new bitcoins are created at a fixed rate. This makes Bitcoin mining a very competitive business.")
                .addBreak('500ms')
                .addText(" We are almost done with covering the basics of bitcoin. Ready to continue?")
            this.followUpState("BitcoinBasicsState7").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinBasicsState6").ask("Everything making sense so far?");
        } 
    },

    'BitcoinBasicsState7' : {
        'YesIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(" Some people think that bitcoin is untraceable and that by using bitcoin your transactions are secret.  But that is not true at all.")
                .addBreak('500ms')
                .addText(" Unlike me, bitcoin is not anonymous. All transactions are publicly visible on the blockchain. When someone knows your bitcoin address they can see every transaction you ever made by using a blockchain explorer.")
                .addBreak('500ms')
                .addBreak('500ms')
                .addText(" Bitcoin was designed to allow its users to send and receive payments with an acceptable level of privacy as well as any other form of money.")
                .addBreak('500ms')
                .addText(" That wraps it up for the basics of bitcoin. Do you want to keep taking lessons?");
            this.followUpState("ExpEducationTopicState").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.basicsNum = this.$user.$data.basicsNum + 1;
            let speech = this.speechBuilder().addText(["Well there's always Google. I have more to tell.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addText(" Some people think that bitcoin is untraceable and that by using bitcoin your transactions are secret.  But that is not true at all.")
                .addBreak('500ms')
                .addText(" Unlike me, bitcoin is not anonymous. All transactions are publicly visible on the blockchain. When someone knows your bitcoin address they can see every transaction you ever made by using a blockchain explorer.")
                .addBreak('500ms')
                .addBreak('500ms')
                .addText(" Bitcoin was designed to allow its users to send and receive payments with an acceptable level of privacy as well as any other form of money.")
                .addBreak('500ms')
                .addText(" That wraps it up for the basics of bitcoin. Do you want to keep taking lessons?");
            this.followUpState("ExpEducationTopicState").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinBasicsState7").ask("Everything making sense so far?");
        } 
    },

    'BitcoinSecurityState1' : {
        'YesIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard3Intent");
        },

        'UserReadyIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard3Intent");
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder().addText("Alright, come back when you are ready.");
                this.tell(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinSecurityState1").ask("Everything making sense so far?");
        }
    },

    'BitcoinSecurityState2' : {
        'YesIntent' : function() {
            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText(" I am going to go ahead and tell you this right now. There is no 1-800 help desk for bitcoin.")
            .addBreak('500ms')
            .addText(" You are in charge of your own wallet and transactions.")
            .addBreak('500ms')
            .addText(" Everything making sense?")
            this.followUpState("BitcoinSecurityState3").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
            .addBreak('500ms')
            .addText(" I am going to go ahead and tell you this right now. There is no 1-800 help desk for bitcoin.")
            .addBreak('500ms')
            .addText(" You are in charge of your own wallet and transactions.")
            .addBreak('500ms')
            this.followUpState("BitcoinSecurityState3").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinSecurityState2").ask("Everything making sense so far?");
        } 

    },

    'BitcoinSecurityState3' : {
        'YesIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard4_1Intent");
        },

        'NoIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard4_2Intent");
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinSecurityState3").ask("Everything making sense so far?");
        } 
    },

    'BitcoinSecurityState4' : {
        'YesIntent' : function() {
            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText("You might be thinking now, what if I enter my address wrong?")
                .addBreak('500ms')
                .addText(" While there are many barriers preventing you from entering the wrong address, I am sad to say that it's virtually impossible to retrieve that lost bitcoin.")
                .addBreak('500ms')
                .addText(" This is why I personally recommend you copy your intended target's wallet address and paste it to wherever you need to enter it.")
                .addBreak('500ms')
                .addText(" Everything making sense?")
                this.followUpState("BitcoinSecurityState5").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addBreak('500ms')
                .addText(" You might be thinking now, what if I enter my address wrong?")
                .addBreak('500ms')
                .addText(" While there are many barriers preventing you from entering the wrong address, I am sad to say that it's virtually impossible to retrieve that lost bitcoin.")
                .addBreak('500ms')
                .addText(" This is why I personally recommend you copy your intended target's wallet address and paste it to wherever you need to enter it.")
                .addBreak('500ms')
                .addText(" Everything making sense?")
                this.followUpState("BitcoinSecurityState5").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinSecurityState4").ask("Everything making sense so far?");
        } 
    },

    'BitcoinSecurityState5' : {
        'YesIntent' : function() {
            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText("There are currently no ways to reverse a transaction using the bitcoin protocol.")
                .addBreak('500ms')
                .addText(' That said, we are looking into technologies that could potentially help settle transaction disputes.')
                .addBreak('500ms')
                .addText(" Until then, users will have to solve their problems independent of the bitcoin protocol.")
                .addBreak('500ms')
                .addText(" Do you want to keep learning?");
                this.followUpState("ExpEducationTopicState").ask(speech);
        },

        'NoIntent' : function() {
            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addBreak('500ms')
                .addText(" There are currently no ways to reverse a transaction using the bitcoin protocol.")
                .addBreak('500ms')
                .addText(' That said, we are looking into technologies that could potentially help settle transaction disputes.')
                .addBreak('500ms')
                .addText(" Until then, users will have to solve their problems independent of the bitcoin protocol.")
                .addBreak('500ms')
                .addText(" Do you want to keep learning?")
                this.followUpState("ExpEducationTopicState").ask(speech);
        },

        'QuitIntent' : function() {
            this.tell("Fine. Go ahead and quit my amazing lessons.")
        },

        'Unhandled' : function() {
            this.followUpState("BitcoinSecurityState5").ask("Everything making sense so far?");
        } 
    },

    'BitcoinBuyingState' : {
        'AnswerIntent' : function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A') {
                this.toStateIntent("BasicCardState", "BasicCard5Intent");
            }
            if (this.$inputs.answerChoice.value == 'B') {
                this.toStateIntent("BasicCardState", "BasicCard6Intent");
            }
            if (this.$inputs.answerChoice.value == 'C') {
                this.toStateIntent("BasicCardState", "BasicCard7Intent");
            }
        },

        "Unhandled" : function() {
            this.followUpState("BitcoinBuyingState").ask("Choose one of the letters of the questions that you are interested in.");
        }
    },

    'ExpEducationTopicState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder().addText("What would you like to learn about?")
            .addBreak('500ms')
            .addText("\nBitcoin Basics")
            .addBreak('500ms')
            .addText("\nBitcoin Security")
            .addBreak('500ms')
            .addText("\nBitcoin Buying")
            this.followUpState("ExpEducationChoiceState").ask(speech)
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder().addText(["Done learning?", "Learned it all?", "How smart you are."])
            .addBreak('500ms')
            .addText("Would you like to go to the bitcoin simulation?")
            this.followUpState("TransitionToSimulationState").ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('ExpEducationTopicState').ask("Would you like to learn more information? Yes or no?");
        }

    },

    'TransitionToSimulationState' : {
        'YesIntent' : function() {
            this.toStateIntent('ThirdLTwoOptionState', 'SimulationChoiceIntent');
        },

        'NoIntent' : function() {
            this.toStateIntent("BasicCardState", "BasicCard1_3Intent");
        },

        'Unhandled' : function () {
            let speech = "Do you want to move to the simulation or not?"
            this.followUpState('TransitionToSimulationState').ask(speech);
        }
    },

    "ExpEducationChoiceState" : {
        'BitcoinBasicsIntent' : function() {
            let speech = this.speechBuilder().addText("Ready for some bitcoin basics?");
            this.followUpState("BitcoinBasicsState1").ask(speech);
        },

        'BitcoinSecurityIntent' : function() {
            let speech = this.speechBuilder().addText("Ready for some security tips concerning bitcoin?");
            this.followUpState("BitcoinSecurityState1").ask(speech);
        },

        'BitcoinBuyingIntent' : function() {
            let speech = this.speechBuilder().addText("Choose the letter of the option you want to hear.")
            .addBreak('500ms')
            .addText("\nA. Coinbase")
            .addBreak('500ms')
            .addText("\nB. Gatehub")
            .addBreak('500ms')
            .addText("\nC. Robinhood")
            this.followUpState("BitcoinBuyingState").ask(speech);
        },

        "Unhandled" : function() {
            this.followUpState("ExpEducationChoiceState").ask("You had three topics to choose. I am happy to enlighten you on any of them.");
        }
    },

    "BasicCardState" : {
        BasicCard1Intent() {
            const basicCard = new BasicCard()
                .setTitle('Traits AI')
                .setFormattedText('Welcome to the Secret Closed Beta Testing')
                .setImage({
                    url: 'http://kardiaventures.com/wp-content/uploads/2018/03/square-logo-1.png',
                    accessibilityText: 'TraitsAI Card'})
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Join', 'https://traitsai.com/beta/');
            
            this.$user.$data.sessNum = this.$user.$data.sessNum + 1;
            let speech = this.speechBuilder().addText("Visit the Traits AI website in order to find out more information about the beta testing. I trust you keep this a secret " + nM + ".")
            .addText("\nNext time you talk to me, I can teach you a thing or two about bitcoin. Perhaps we can even play a game.");
            this.$googleAction.showBasicCard(basicCard);
            this.tell(speech);
        },
        BasicCard1_1Intent() {
            const basicCard = new BasicCard()
                .setTitle('Traits AI')
                .setFormattedText('Welcome to the Secret Closed Beta Testing')
                .setImage({
                    url: 'http://kardiaventures.com/wp-content/uploads/2018/03/square-logo-1.png',
                    accessibilityText: 'TraitsAI Card'})
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Join', 'https://traitsai.com/beta/');
            
            this.$user.$data.sessNum = this.$user.$data.sessNum + 1;
            let speech = this.speechBuilder().addText("Alright, that's fine. Visit the Traits AI website in order to find out more information about the beta testing. I trust you keep this a secret " + nM + ".")
            .addText("\nNext time you talk to me, I can teach you a thing or two about bitcoin. Perhaps we can even play a game.");
            this.$googleAction.showBasicCard(basicCard);
            this.tell(speech);
        },
        BasicCard1_2Intent() {
            const basicCard = new BasicCard()
                .setTitle('Traits AI')
                .setFormattedText('Welcome to the Secret Closed Beta Testing')
                .setImage({
                    url: 'http://kardiaventures.com/wp-content/uploads/2018/03/square-logo-1.png',
                    accessibilityText: 'TraitsAI Card'})
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Join', 'https://traitsai.com/beta/');
            
            let speech = this.speechBuilder().addText("Done with this session on investment?")
            .addBreak('500ms')
            .addText("Fine by me.")
            .addBreak('500ms')
            .addText("Do not forget to check out the beta testing done by Traits AI.");
            this.$googleAction.showBasicCard(basicCard);
            this.tell(speech);
        },
        BasicCard1_3Intent() {
            const basicCard = new BasicCard()
                .setTitle('Traits AI')
                .setFormattedText('Welcome to the Secret Closed Beta Testing')
                .setImage({
                    url: 'http://kardiaventures.com/wp-content/uploads/2018/03/square-logo-1.png',
                    accessibilityText: 'TraitsAI Card'})
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Join', 'https://traitsai.com/beta/');
            
            let speech = this.speechBuilder().addText("Alright, suit yourself.")
            .addBreak('500ms')
            .addText("Do not forget to check out the beta testing done by Traits AI.");
            this.$googleAction.showBasicCard(basicCard);
            this.tell(speech);
        },

        BasicCard3Intent() {
            const basicCard = new BasicCard()
                .setTitle('Investopedia Guide on Bitcoin Security')
                .setFormattedText('Satoshi Approved Instructions for Security')
                .setImage({
                    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Bitcoin.svg/2000px-Bitcoin.svg.png',
                    accessibilityText: 'Bitcoin Card'})
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Visit', 'https://www.investopedia.com/news/bitcoin-safe-storage-cold-wallet/');

            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText("I am going to start off by telling you that bitcoin storage is really important.")
            .addBreak('500ms')
            .addText(" I will give you something to do in your spare time. Here is a little help to start your research. Here is a website that I, personally, love to read for Bitcoin Security.")
            .addBreak('500ms')
            .addText(" Good so far?")
            this.$googleAction.showBasicCard(basicCard);
            this.followUpState("BitcoinSecurityState2").ask(speech);
        },

        BasicCard4Intent() {
            const basicCard = new BasicCard()
                .setTitle('Blog Guide on Lost Bitcoin')
                .setFormattedText('Satoshi Approved Instructions for Lost Bitcoin')
                .setImage({
                    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Bitcoin.svg/2000px-Bitcoin.svg.png',
                    accessibilityText: 'Bitcoin Card'})                
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Visit', 'https://blog.unocoin.com/what-happens-to-lost-bitcoins-796dfabd3ac4');

            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText("Looks like you already learned some. We will start here.")
                .addBreak('500ms')
                .addText("If you are not as good at memorization as me, you'll often forget your private key.")
                .addBreak('500ms')
                .addText(" There is way to much information for me to tell you here. As such, I can recommend a website that I love to read for Bitcoin Security.")
                .addBreak('500ms')
                .addText(" Everything making sense?")
            this.$googleAction.showBasicCard(basicCard);
            this.followUpState("BitcoinSecurityState4").ask(speech);
        },
        BasicCard4_1Intent() {
            const basicCard = new BasicCard()
                .setTitle('Blog Guide on Lost Bitcoin')
                .setFormattedText('Satoshi Approved Instructions for Lost Bitcoin')
                .setImage({
                    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Bitcoin.svg/2000px-Bitcoin.svg.png',
                    accessibilityText: 'Bitcoin Card'})                
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Visit', 'https://blog.unocoin.com/what-happens-to-lost-bitcoins-796dfabd3ac4');

            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder()
                .addText("If you are not as good at memorization as me, you'll often forget your private key.")
                .addBreak('500ms')
                .addText(" There is way to much information for me to tell you here. As such, I can recommend a website that I love to read for Bitcoin Security.")
                .addBreak('500ms')
                .addText(" Everything making sense?")
            this.$googleAction.showBasicCard(basicCard);
            this.followUpState("BitcoinSecurityState4").ask(speech);
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addBreak('500ms')
        },
        BasicCard4_2Intent() {
            const basicCard = new BasicCard()
                .setTitle('Blog Guide on Lost Bitcoin')
                .setFormattedText('Satoshi Approved Instructions for Lost Bitcoin')
                .setImage({
                    url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Bitcoin.svg/2000px-Bitcoin.svg.png',
                    accessibilityText: 'Bitcoin Card'})                
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Visit', 'https://blog.unocoin.com/what-happens-to-lost-bitcoins-796dfabd3ac4');

            this.$user.$data.securNum = this.$user.$data.securNum + 1;
            let speech = this.speechBuilder().addText(["No matter. We must keep moving.", "That's unfortunate. Look it up on Google in your own time.", "Unfortunately, we cannot stop. Have to keep moving."])
                .addBreak('500ms')
                .addText("If you are not as good at memorization as me, you'll often forget your private key.")
                .addBreak('500ms')
                .addText(" There is way to much information for me to tell you here. As such, I can recommend a website that I love to read for Bitcoin Security.")
                .addBreak('500ms')
                .addText(" Everything making sense?")
            this.$googleAction.showBasicCard(basicCard);
            this.followUpState("BitcoinSecurityState4").ask(speech);
        },

        BasicCard5Intent() {
            const basicCard = new BasicCard()
                .setTitle('Coinbase')
                .setFormattedText('Bitcoin Stock Exchange: Coinbase')
                .setImage({
                    url: 'https://upload.wikimedia.org/wikipedia/commons/c/c7/Coinbase_Logo_2013.png',
                    accessibilityText: 'Coinbase Card'})  
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Visit', 'https://www.coinbase.com/');
                
            let speech = this.speechBuilder().addText("Coinbase is your general bitcoin stock exchange. As far as I know, they're the largest cryptocurrency exchange out there.")
            .addBreak('500ms')
            .addText("Would you like to learn more?")
            this.$googleAction.showBasicCard(basicCard);
            this.followUpState("ExpEducationTopicState").ask(speech);
        },

        BasicCard6Intent() {
            const basicCard = new BasicCard()
                .setTitle('Gatehub')
                .setFormattedText('Bitcoin Stock Exchange: Gatehub')
                .setImage({
                    url: 'https://www.linkedin.com/media-proxy/ext?w=1040&h=601&hash=WNGVBUNegP72zXmQgSJsQR1PwW8%3D&ora=1%2CaFBCTXdkRmpGL2lvQUFBPQ%2CxAVta9Er0Varhx4S1x5v7quV4k2860AIRo3SFmX_Hzrzp4TXNTT2e8fecK2hokJJLnpYw11jI_LrBGGlT8bib4jxPYIm',
                    accessibilityText: 'Gatehub Card'})  
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Visit', 'https://gatehub.net/');
            
            let speech = this.speechBuilder().addText("Gatehub is a website which allows for bitcoin exchange. They claim to be really safe.")
            .addBreak('500ms')
            .addText(" The besat advantage that I see to Gatehub is that they accept cash. You may find that useful.")
            .addBreak('500ms')
            .addText("Would you like to learn more?")
            this.$googleAction.showBasicCard(basicCard);
            this.followUpState("ExpEducationTopicState").ask(speech);
        },

        BasicCard7Intent() {
            const basicCard = new BasicCard()
                .setTitle('Robinhood')
                .setFormattedText('Bitcoin Stock Exchange: Robinhood')
                .setImage({
                    url: 'https://upload.wikimedia.org/wikipedia/commons/b/b9/Robinhood_Logo.png',
                    accessibilityText: 'Robinhood Card'}) 
                .setImageDisplay('WHITE') 
                .addButton('Click Here To Visit', 'https://www.robinhood.com/');
            
            let speech = this.speechBuilder().addText("Robinhood is another popular stock exchange. They're user interface is pretty intuitive.")
            .addBreak('500ms')
            .addText("Would you like to learn more?")
            this.$googleAction.showBasicCard(basicCard);
            this.followUpState("ExpEducationTopicState").ask(speech);
        }
    }
  
});

module.exports.app = app;


