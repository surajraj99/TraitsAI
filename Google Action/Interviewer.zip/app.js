'use strict';

// ------------------------------------------------------------------
// APP INITIALIZATION
// ------------------------------------------------------------------

const { App } = require('jovo-framework');
const { Alexa } = require('jovo-platform-alexa');
const { GoogleAssistant } = require('jovo-platform-googleassistant');
const { JovoDebugger } = require('jovo-plugin-debugger');
const { FileDb } = require('jovo-db-filedb');
const { DynamoDb } = require('jovo-db-dynamodb');

const app = new App();

app.use(
    new Alexa(),
    new GoogleAssistant(),
    new JovoDebugger(),
    new FileDb(),
    new DynamoDb()
);

app.setDynamoDb('Interview-table');


// ------------------------------------------------------------------
// APP LOGIC
// ------------------------------------------------------------------

app.setHandler({
    LAUNCH() {
        this.toIntent('LaunchIntent');
    },

    'LaunchIntent' : function() {
        if (this.$user.$data.sessNum == 1) {
            this.toIntent('SecondLaunchIntent');
        }
        else {
            this.$user.$data.totalQuesNum = 1;
            
            this.$user.$data.ques1Ans = " ";
            this.$user.$data.ques2Ans = " ";
            this.$user.$data.ques3Ans = " ";
            this.$user.$data.ques4Ans = " ";
            this.$user.$data.ques5Ans = " ";
            this.$user.$data.ques6Ans = " ";
            this.$user.$data.ques7Ans = " ";
            this.$user.$data.ques8Ans = " ";
            this.$user.$data.ques9Ans = " ";
            this.$user.$data.ques10Ans = " ";
            this.$user.$data.ques11Ans = " ";
            this.$user.$data.ques12Ans = " ";
            this.$user.$data.ques13Ans = " ";
            this.$user.$data.ques14Ans = " ";
            this.$user.$data.ques15Ans = " ";
            this.$user.$data.ques16Ans = " ";
            this.$user.$data.ques17Ans = " ";
            this.$user.$data.ques18Ans = " ";
            this.$user.$data.ques19Ans = " ";
            this.$user.$data.ques20Ans = " ";
            this.$user.$data.ques21Ans = " ";
            this.$user.$data.ques22Ans = " ";
            
            this.toIntent('FirstLaunchIntent');
        }
    },

    'FirstLaunchIntent' : function() {
        this.$user.$data.sessNum = 1;
            let speech = this.speechBuilder()
                .addText("Nice to meet you.")
                .addBreak('500ms')
                .addText(" My name is Ingrid.")
                .addBreak('500ms')
                .addText(" I specialize in asking questions that job recruiters ask in the interview process.")
                .addBreak('500ms')
                .addText(" Would you like to practice your interviewing skills with me?")
            this.followUpState('PracticeSkillsState').ask(speech);
    },

    'SecondLaunchIntent' : function() {
        let speech = this.speechBuilder()
            .addText("Looks like you've already started some things here.")
            .addBreak('500ms')
            .addText(" Ready to start again?");
        this.followUpState("ExpReadyState").ask(speech);
    },

    'ExpReadyState' : {
        'UserReadyIntent' : function() {
            let tempNum = this.$user.$data.totalQuesNum
            let quesNum = tempNum % 22;
            if (quesNum == 0) {
                quesNum = 22;
            }
            let strQuesNum = (String)(quesNum);
            let stateString = 'Question' + strQuesNum + "State";
            this.toStateIntent(stateString, 'DirectIntent');
        },

        'YesIntent' : function() {
            let tempNum = this.$user.$data.totalQuesNum
            let quesNum = tempNum % 22;
            if (quesNum == 0) {
                quesNum = 22;
            }
            let strQuesNum = (String)(quesNum);
            let stateString = 'Question' + strQuesNum + "State";
            this.toStateIntent(stateString, 'DirectIntent');
        },

        'UserNotReadyIntent' : function() {
            this.tell("Well, that's unfortunate. A waste of both of our times.");;
        },

        'NotIntent' : function() {
            this.tell("Well, that's unfortunate. A waste of both of our times.");
        },

        'QuitIntent' : function() {
            this.tell("Ok, go ahead and quit.");
        },

        'Unhandled' : function() {
            this.followUpState("ExpReadyState").ask("Are you ready to begin again?");
        }
    },

    'PracticeSkillsState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Perfect. I will ask you a series of questions.")
                .addBreak('500ms')
                .addText(" Give me your best response to each.")
                .addBreak('500ms')
                .addText(" I will offer you tips and tricks along the way.")
                .addBreak('500ms')
                .addText("Feel free to say 'Quit' at any time to stop.")
                .addBreak('500ms')
                .addText(" Ready to begin?");
            this.followUpState('Question1State').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright, don't take advatnage of what I'm giving you for free.")
            this.tell(speech);
        },

        'QuitIntent' : function() {
            this.tell("Ok, go ahead and quit before we've even started.");
        },

        'Unhandled' : function() {
            this.followUpState("PracticeSkillsState").ask("Want to practice?");
        }
    },

    'Question1State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Let's begin.")
                .addBreak('500ms')
                .addText(" Here's one. Tell me a bit about yourself.")
            this.followUpState('Question1TransState').ask(speech);
        },

        'UserReadyIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Let's begin.")
                .addBreak('500ms')
                .addText(" Here's one. Tell me a bit about yourself.")
            this.followUpState('Question1TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = "All this way just to say no? Suit yourself."
            this.tell(speech);
        },

        'UserNotReadyIntent' : function() {
            let speech = "All this way just to say no? Suit yourself."
            this.tell(speech);
        },

        'QuitIntent' : function() {
            this.tell("Ok, go ahead and quit before we've even began.");
        },

        'DirectIntent' : function() {
            var s = this.$user.$data.ques1Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: Tell me a bit about yourself.")
                .addBreak('500ms')
                .addText("Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question1AgainState").ask(speech);
            } else {
                let speech = this.speechBuilder()
                    .addText("Let's get straight to the questions: Tell me a bit about yourself.");
                this.followUpState('Question1TransState').ask(speech);
            }
        },

        'Unhandled' : function() {
            this.followUpState('Question1State').ask("Ready to begin?");
        }
    },

    'Question1AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" If I remember correctly, the question was: Tell me a bit about yourself.")
            this.followUpState('Question1TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question2State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question1AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question1TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques1Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("An intriguing response.")
                .addBreak('500ms')
                .addText(" Want to hear some tips I have on this question?")
            this.followUpState('Question2State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question2State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
                .addText(" This question is simple but needs some preparation. Try thinking about this in terms of your elevator pitch.")
                .addBreak('500ms')
                .addText(" A few sentences that describe yourself and then 2-3 accomplishments that you really want the interviewer to know.") 
                .addBreak('500ms')
                .addText(" Wrap up by talking about experience that pertains to the job you're applying for.")
                .addBreak('500ms');
            let s = this.$user.$data.ques2Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What are your greatest professional strengths?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question2AgainState").ask(speech);
            }
            else { 
                speech = speech + this.speechBuilder().addText(" Next question: What are your greatest professional strengths?")
                this.followUpState('Question2TransState').ask(speech);
            }
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("That's alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques2Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What are your greatest professional strengths?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question2AgainState").ask(speech);
            }
            else {   
                speech = speech + this.speechBuilder().addText(" Next question: What are your greatest professional strengths?")
                this.followUpState('Question2TransState').ask(speech);
            }
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques2Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What are your greatest professional strengths?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question2AgainState").ask(speech);
            } else {
                let speech = this.speechBuilder()
                    .addText("Let's get straight to the questions: What are your greatest professional strengths?");
                this.followUpState('Question2TransState').ask(speech);
            }
        },

        'Unhandled' : function() {
            this.followUpState('Question2State').ask("Do you want my tips or not?");
        }
    },

    'Question2AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What are your greatest professional strengths?")
            this.followUpState('Question2TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question3State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question2AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question2TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques2Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("A unique response.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question3State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question3State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Okay.")
                .addBreak('500ms')
                .addText(" Three things to do here. Be accurate to your real strengths. Be relevant and choose what strengths matter to the job. And be specific.")
                .addBreak('500ms')
                .addText(" Instead of saying people skills, say something like 'persuasive communication'. Follow up with an example of how you demonstrated these traits in a professional setting.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques3Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What do you consider to be your weaknesses?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question3AgainState").ask(speech);
            }
            else {
                speech = speech + this.speechBuilder().addText(" On to the next question: What do you consider to be your weaknesses?")
                this.followUpState('Question3TransState').ask(speech);
            }
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Okay.")
                .addBreak('500ms')
            let s = this.$user.$data.ques3Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What do you consider to be your weaknesses?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question3AgainState").ask(speech);
            }
            else {
                speech = speech + this.speechBuilder().addText(" On to the next question: What do you consider to be your weaknesses?")
                this.followUpState('Question3TransState').ask(speech);
            }
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques3Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What do you consider to be your weaknesses?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question3AgainState").ask(speech);
            }
            else {
                let speech = this.speechBuilder()
                    .addText("Let's get straight to the questions: What do you consider to be your weaknesses?");
                this.followUpState('Question3TransState').ask(speech);
            }
        },

        'Unhandled' : function() {
            this.followUpState('Question3State').ask("Do you want my tips or not?");
        }
    },

    'Question3AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" The question was: What do you consider to be your weaknesses?")
            this.followUpState('Question3TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question4State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question3AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question3TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques3Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Well said.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question4State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question4State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Key to answering this question is finding a balance.")
                .addBreak('500ms')
                .addText(" Think of something you struggle with but that you want to improve on. Also, just be honest and don't come up with fake weaknesses.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques4Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What is your greatest professional achievement?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question4AgainState").ask(speech);
            }
            else {  
                speech = speech + this.speechBuilder().addText(" On to the next question: What is your greatest professional achievement?")
                this.followUpState('Question4TransState').ask(speech);
            }
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Fair.")
                .addBreak('500ms')
            let s = this.$user.$data.ques4Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What is your greatest professional achievement?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question4AgainState").ask(speech);
            }
            else {
                speech = speech + this.speechBuilder().addText(" On to the next question: What do you consider to be your weaknesses?")
                this.followUpState('Question3TransState').ask(speech);
            }
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques4Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What is your greatest professional achievement?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question4AgainState").ask(speech);
            } else {
                let speech = this.speechBuilder()
                    .addText("Let's get straight to the questions: What is your greatest professional achievement?");
                this.followUpState('Question4TransState').ask(speech);
            }
        },

        'Unhandled' : function() {
            this.followUpState('Question4State').ask("Do you want my tips or not?");
        }
    },

    'Question4AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was:  What is your greatest professional achievement?")
            this.followUpState('Question4TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question5State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question4AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question4TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques4Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("I've never heard that answer before.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question5State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question5State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Be proud of what you say. A good way to do so is by using the S-T-A-R method.")
                .addBreak('500ms')
                .addText(" Set up the situation and the task that you were required to complete to provide the interviewer with background context.")
                .addBreak('500ms')
                .addText(" Spend the bulk of your time describing what you actually did and what you achieved. Be quantitative in your results.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques5Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: Tell me about a challenge or conflict you've faced at work, and how you dealt with it.")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question5AgainState").ask(speech);
            }
            if (this.$user.$data.totalQuesNum < 22) {
                speech = speech + " A quarter of the way to end!";
            }
            speech = speech + this.speechBuilder().addText(" On to the next one: Tell me about a challenge or conflict you've faced at work, and how you dealt with it.")
            this.followUpState('Question5TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques5Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: Tell me about a challenge or conflict you've faced at work, and how you dealt with it.")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question5AgainState").ask(speech);
            }
            if (this.$user.$data.totalQuesNum < 22) {
                speech = speech + " A quarter of the way to end!";
            }
            speech = speech + this.speechBuilder().addText(" Tell me about a challenge or conflict you've faced at work, and how you dealt with it.")
            this.followUpState('Question5TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques5Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: Tell me about a challenge or conflict you've faced at work, and how you dealt with it.")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question5AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: Tell me about a challenge or conflict you've faced at work, and how you dealt with it.");
            this.followUpState('Question5TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question5State').ask("Do you want my tips or not?");
        }
    },

    'Question5AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: Tell me about a challenge or conflict you've faced at work, and how you dealt with it.")
            this.followUpState('Question5TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question6State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question5AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question5TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques5Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("A notable response.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question6State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question6State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("In asking this question, your interviewer wants to see how you respond to conflict.")
                .addBreak('500ms')
                .addText(" Again, you'll want to use the S-T-A-R method.")
                .addBreak('500ms')
                .addText(" Focus on how you handled the situation professionally and productively, and ideally closing with a happy ending.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques6Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: Where do you see yourself in five years?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question6AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: Where do you see yourself in five years?")
            this.followUpState('Question6TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques6Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: Where do you see yourself in five years?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question6AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: Where do you see yourself in five years?")
            this.followUpState('Question6TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques6Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: Where do you see yourself in five years?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question6AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: Where do you see yourself in five years?");
            this.followUpState('Question6TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question6State').ask("Do you want my tips or not?");
        }
    },

    'Question6AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: Where do you see yourself in five years?")
            this.followUpState('Question6TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question7State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question6AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question6TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques6Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Great response.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question7State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question7State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Be honest and specific. The recruiter wants to know that you have realistic expectations, you have ambition, and that your aspirations align with your goals.")
                .addBreak('500ms')
                .addText(" Your best bet is to think realistically about where this position could take you and answer along those lines.")
                .addBreak('500ms')
                .addText(" If nothing comes up, you could say you don't know what the future holds but believe this role will play an important role in forming it.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques7Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's your dream job?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question7AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What's your dream job?")
            this.followUpState('Question7TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques7Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's your dream job?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question7AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What's your dream job?")
            this.followUpState('Question7TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques7Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What's your dream job?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question7AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What's your dream job?");
            this.followUpState('Question7TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question7State').ask("Do you want my tips or not?");
        }
    },

    'Question7AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What's your dream job?")
            this.followUpState('Question7TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question8State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question7AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question7TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques7Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Interesting answer.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question8State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question8State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
                .addText(" The interviewer wants to uncover whether this position is really in line with your ultimate career goals.")
                .addBreak('500ms')
                .addText(" A good bet is to talk about your goals and ambitions — and why this job will get you closer to them.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques8Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What are you looking for in a new position?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question8AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What are you looking for in a new position?")
            this.followUpState('Question8TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques8Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What are you looking for in a new position?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question8AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What are you looking for in a new position?")
            this.followUpState('Question8TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques8Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What are you looking for in a new position?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question8AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What are you looking for in a new position?");
            this.followUpState('Question8TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question8State').ask("Do you want my tips or not?");
        }
    },

    'Question8AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What are you looking for in a new position?")
            this.followUpState('Question8TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question9State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question8AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question8TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques8Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Very intriguing.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question9State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question9State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Do research beforehand about the position you are applying for.")
                .addBreak('500ms')
                .addText(" See what they offer.")
                .addBreak('500ms')
                .addText(" You should talk a lot about what they offer.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques9Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What type of work environment do you prefer?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question9AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What type of work environment do you prefer?")
            this.followUpState('Question9TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques9Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What type of work environment do you prefer?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question9AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What type of work environment do you prefer?")
            this.followUpState('Question9TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques9Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What type of work environment do you prefer?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question9AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What type of work environment do you prefer?");
            this.followUpState('Question9TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question9State').ask("Do you want my tips or not?");
        }
    },

    'Question9AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What type of work environment do you prefer?")
            this.followUpState('Question9TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question10State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question9AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question9TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques9Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Quite a unique answer.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question10State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question10State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
                .addText(" Ideally one that's similar to the environment of the company you're applying to.")
                .addBreak('500ms')
                .addText(" Be specific.") 
                .addBreak('500ms')
            let s = this.$user.$data.ques10Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's your management style?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question10AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What's your management style?")
            this.followUpState('Question10TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques10Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's your management style?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question10AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What's your management style?")
            this.followUpState('Question10TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques10Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What's a time you exercised leadership?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question10AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What's your management style?");
            this.followUpState('Question10TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question10State').ask("Do you want my tips or not?");
        }
    },

    'Question10AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What's your management style?")
            this.followUpState('Question10TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question11State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question10AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question10TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques10Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Solid answer.")
                .addBreak('500ms')
                .addText(" Would you like to hear some tips I have on this question?")
            this.followUpState('Question11State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question11State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("The best managers are strong but flexible, and that's exactly what you want to show off in your answer.")
                .addBreak('500ms')
                .addText(" Share a couple of your best managerial moments. Be quantitative in your answers.")
                .addBreak('500ms')
            let s = this.$user.$data.ques11Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's a time you exercised leadership?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question11AgainState").ask(speech);
            }
            if (this.$user.$data.totalQuesNum < 22) {
                speech = speech + " Halfway there.";
            } 
            speech = speech + this.speechBuilder().addText(" On to the next question: What's a time you exercised leadership?")
            this.followUpState('Question11TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques11Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's a time you exercised leadership?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question11AgainState").ask(speech);
            }
            if (this.$user.$data.totalQuesNum < 22) {
                speech = speech + " Halfway there.";
            }     
            speech = speech + this.speechBuilder().addText(" On to the next question: What's a time you exercised leadership?")
            this.followUpState('Question11TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques11Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What's a time you exercised leadership?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question11AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What's a time you exercised leadership?");
            this.followUpState('Question11TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question11State').ask("Do you want my tips or not?");
        }
    },

    'Question11AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What's a time you exercised leadership?")
            this.followUpState('Question11TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question12State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question11AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question11TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques11Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("A good answer.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question12State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question12State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Depending on what's more important for the the role, you'll want to choose an example that showcases your project management skills.")
                .addBreak('500ms')
                .addText(" Maybe one that shows your ability to confidently and effectively rally a team.")
                .addBreak('500ms')
                .addText(" Include enough detail that makes it believable.")
                .addBreak('500ms')
            let s = this.$user.$data.ques12Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's a time you disagreed with a decision that was made at work?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question12AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What's a time you disagreed with a decision that was made at work?")
            this.followUpState('Question12TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques12Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What's a time you disagreed with a decision that was made at work?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question12AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What's a time you disagreed with a decision that was made at work?")
            this.followUpState('Question12TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques12Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What's a time you disagreed with a decision that was made at work?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question12AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What's a time you disagreed with a decision that was made at work?");
            this.followUpState('Question12TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question12State').ask("Do you want my tips or not?");
        }
    },

    'Question12AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What's a time you disagreed with a decision that was made at work?")
            this.followUpState('Question12TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question13State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question12AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question12TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques12Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Nice.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question13State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question13State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Hiring managers want to know that you can do so in a productive, professional way.")
                .addBreak('500ms')
                .addText(" Tell the one where your actions made a positive difference on the outcome of the situation, whether it was a work-related outcome or a more effective and productive working relationship.")
                .addBreak('500ms')
            let s = this.$user.$data.ques13Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: How would your boss and co-workers describe you?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question13AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: How would your boss and co-workers describe you?")
            this.followUpState('Question13TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques13ans
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: How would your boss and co-workers describe you?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question13AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What's a time you disagreed with a decision that was made at work?")
            this.followUpState('Question12TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques13Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: How would your boss and co-workers describe you?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question13AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: How would your boss and co-workers describe you?");
            this.followUpState('Question13TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question13State').ask("Do you want my tips or not?");
        }
    },

    'Question13AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: How would your boss and co-workers describe you?")
            this.followUpState('Question13TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question14State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question13AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question13TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques13Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Cool.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question14State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question14State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("First and foremost, be honest.")
                .addBreak('500ms')
                .addText(" Try to pull out strengths and traits you haven't discussed in other aspects of the interview.")
                .addBreak('500ms')
                .addText(" Maybe your strong work ethic or your willingness to pitch in on other projects when needed.")
                .addBreak('500ms')
            let s = this.$user.$data.ques14Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: Have you had any changes in career paths and if so, why?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question14AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" Have you had any changes in career paths and if so, why?")
            this.followUpState('Question14TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques14Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: Have you had any changes in career paths and if so, why?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question14AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: Have you had any changes in career paths and if so, why?")
            this.followUpState('Question14TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques14Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: Have you had any changes in career paths and if so, why?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question14AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: Have you had any changes in career paths and if so, why?");
            this.followUpState('Question14TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question14State').ask("Do you want my tips or not?");
        }
    },

    'Question14AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: Have you had any changes in career paths and if so, why?")
            this.followUpState('Question14TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question15State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question14AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question14TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques14Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Well done.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question15State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question15State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("These are tips for if you did have changes.")
                .addBreak('500ms')
                .addText(" Explain to the hiring manager why you've made the career decisions you have.")
                .addBreak('500ms')
                .addText(" Give a few examples of how your past experience is transferrable to the new role.")
                .addBreak('500ms')
            let s = this.$user.$data.ques15Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: How do you deal with pressure or stressful situations?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question15AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: How do you deal with pressure or stressful situations?")
            this.followUpState('Question15TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques15Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: How do you deal with pressure or stressful situations?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question15AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: How do you deal with pressure or stressful situations?")
            this.followUpState('Question15TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques15Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: How do you deal with pressure or stressful situations?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question15AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: How do you deal with pressure or stressful situations?");
            this.followUpState('Question15TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question15State').ask("Do you want my tips or not?");
        }
    },

    'Question15AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: How do you deal with pressure or stressful situations?")
            this.followUpState('Question15TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question16State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question15AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question15TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques15Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Good.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question16State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question16State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("A great approach is to talk through your go-to stress-reduction tactics.")
                .addBreak('500ms')
                .addText(" Then share an example of a stressful situation you navigated with ease.")
                .addBreak('500ms')
            let s = this.$user.$data.ques16Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What do you like to do outside of work?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question16AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What do you like to do outside of work?")
            this.followUpState('Question16TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques16Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What do you like to do outside of work?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question16AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What do you like to do outside of work?")
            this.followUpState('Question16TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques16Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What do you like to do outside of work?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question16AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What do you like to do outside of work?");
            this.followUpState('Question16TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question16State').ask("Do you want my tips or not?");
        }
    },

    'Question16AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What do you like to do outside of work?")
            this.followUpState('Question16TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question17State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question16AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question16TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques16Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Interesting.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question17State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question17State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("If someone asks about your hobbies outside of work, it’s fine to open up and share what really makes you tick.")
                .addBreak('500ms')
                .addText(" They want to know what you are like, your social abilities and your general personality.")
                .addBreak('500ms')
                .addText(" Do try to keep it semi-professional though.")
                .addBreak('500ms')
            let s = this.$user.$data.ques17Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: If you were an animal, which one would you want to be?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question17AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: If you were an animal, which one would you want to be?")
            this.followUpState('Question17TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques17Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: If you were an animal, which one would you want to be?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question17AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: If you were an animal, which one would you want to be?")
            this.followUpState('Question17TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques17Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: If you were an animal, which one would you want to be?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question17AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: If you were an animal, which one would you want to be?");
            this.followUpState('Question17TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question17State').ask("Do you want my tips or not?");
        }
    },

    'Question17AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: If you were an animal, which one would you want to be?")
            this.followUpState('Question17TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question18State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question17AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question17TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques17Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Intriguing.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question18State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },

    'Question18State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Seemingly random personality-test type questions like these come up in interviews generally because hiring managers want to see how you can think on your feet.")
                .addBreak('500ms')
                .addText(" There's no wrong answer here, but you'll immediately gain bonus points if your answer helps you share your strengths or personality or connect with the hiring manager.")
                .addBreak('500ms')
                .addText(" Come up with a stalling tactic to buy yourself some thinking time.")
                .addBreak('500ms')
            let s = this.$user.$data.ques18Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What was your biggest failure?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question18AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What was your biggest failure?")
            this.followUpState('Question18TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques18Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What was your biggest failure?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question18AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What was your biggest failure?")
            this.followUpState('Question18TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques18Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What was your biggest failure?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question18AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What was your biggest failure?");
            this.followUpState('Question18TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question18State').ask("Do you want my tips or not?");
        }
    },

    'Question18AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What was your biggest failure?")
            this.followUpState('Question18TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question19State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question18AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question18TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques18Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Solid.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question19State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },
    
    'Question19State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Recruiters want to know if you can fail smart and learn from your mistakes.")
                .addBreak('500ms')
                .addText(" Three things to remember here.")
                .addBreak('500ms')
                .addText(" Choose a real failure. Don't raise red flags. Lastly, focus on the learning portion of the story.")
                .addBreak('500ms')
            let s = this.$user.$data.ques19Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What motivates you?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question19AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What motivates you?")
            this.followUpState('Question19TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques19Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What motivates you?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question19AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" What motivates you?")
            this.followUpState('Question19TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques19Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was:  What motivates you?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question19AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What motivates you?");
            this.followUpState('Question19TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question19State').ask("Do you want my tips or not?");
        }
    },

    'Question19AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What motivates you?")
            this.followUpState('Question19TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question20State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question19AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },
    
    'Question19TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques19Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Never heard that one before.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question20State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },
    
    'Question20State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("A good answer to any interview question is succinct and makes use of telling detail.")
                .addBreak('500ms')
                .addText(" Whatever you say about your motivation, you need to back it up with examples from your studies, work experience and extracurricular activities.")
                .addBreak('500ms')
                .addText(" It should relate to the skills and aptitudes required for the job you’re going for.")
                .addBreak('500ms')
            let s = this.$user.$data.ques20Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: If you could choose a superhero power, what would you choose?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question20AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question:If you could choose a superhero power, what would you choose?")
            this.followUpState('Question20TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques20Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: If you could choose a superhero power, what would you choose?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question20AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: If you could choose a superhero power, what would you choose?")
            this.followUpState('Question20TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques20Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: If you could choose a superhero power, what would you choose?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question20AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: If you could choose a superhero power, what would you choose?");
            this.followUpState('Question20TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question20State').ask("Do you want my tips or not?");
        }
    },

    'Question20AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: If you could choose a superhero power, what would you choose?")
            this.followUpState('Question20TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question21State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question20AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },

    'Question20TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques20Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Very unique.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question21State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },
    
    'Question21State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Be clever when responding.")
                .addBreak('500ms')
                .addText(" You should always make a connection to your professional contributions.")
                .addBreak('500ms')
                .addText(" The superpower you choose need to relate back to an organization or how your skills would benefit others.")
                .addBreak('500ms')
            let s = this.$user.$data.ques21Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: If I was your supervisor and I asked you to do something you disagreed with, what would you do?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question21AgainState").ask(speech);
            }
            if (this.$user.$data.totalQuesNum < 22) {
                speech = speech + " Only a couple more questions.";
            } 
            speech = speech + this.speechBuilder().addText(" On to the next: If I was your supervisor and I asked you to do something you disagreed with, what would you do?")
            this.followUpState('Question21TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques21Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: If I was your supervisor and I asked you to do something you disagreed with, what would you do?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question21AgainState").ask(speech);
            }
            if (this.$user.$data.totalQuesNum < 22) {
                speech = speech + " Only a couple more questions.";
            }     
            speech = speech + this.speechBuilder().addText(" On to the next: If I was your supervisor and I asked you to do something you disagreed with, what would you do?")
            this.followUpState('Question21TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques21Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: If I was your supervisor and I asked you to do something you disagreed with, what would you do?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question21AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: If I was your supervisor and I asked you to do something you disagreed with, what would you do?");
            this.followUpState('Question21TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question21State').ask("Do you want my tips or not?");
        }
    },

    'Question21AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: If I was your supervisor and I asked you to do something you disagreed with, what would you do?")
            this.followUpState('Question21TransState').ask(speech);
        },

        'NoIntent' : function() {
           this.toStateIntent("Question22State", "NoIntent");
        },

        'Unhandled' : function() {
            this.followUpState('Question21AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },


    'Question21TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques21Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("An interesting response.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('Question22State').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },
    
    'Question22State' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("When asked this question, break down the steps you would take, to show how you try to resolve misunderstandings and disputes.")
                .addBreak('500ms')
                .addText(" Highlight communication strategies over the disagreement itself.")
                .addBreak('500ms')
                .addText(" The interviewer wants to know how you ould respond to conflict.")
                .addBreak('500ms')
            let s = this.$user.$data.ques22Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What was the most difficult period in your life and how did you deal with it?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question22AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What was the most difficult period in your life and how did you deal with it?")
            this.followUpState('Question22TransState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Alright.")
                .addBreak('500ms')
            let s = this.$user.$data.ques22Ans;
            if (s.length > 1) {
                speech = speech + this.speechBuilder().addText(" Looks like you've already answered this next question. It was: What was the most difficult period in your life and how did you deal with it?")
                .addBreak('500ms')
                .addText(" Here's what you said. ")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText(" Would you like to change your response?")
                this.followUpState("Question22AgainState").ask(speech);
            }
                
            speech = speech + this.speechBuilder().addText(" On to the next question: What was the most difficult period in your life and how did you deal with it?")
            this.followUpState('Question22TransState').ask(speech);
        },

        'DirectIntent' : function() {
            let s = this.$user.$data.ques22Ans;
            if (s.length > 1) {
                let speech = this.speechBuilder().addText("Looks like you've already answered this first one. The question was: What was the most difficult period in your life and how did you deal with it?")
                .addBreak('500ms')
                .addText("Here's what you said.")
                .addBreak('500ms')
                .addText(s)
                .addBreak('500ms')
                .addText("Would you like to change your response?")
                this.followUpState("Question22AgainState").ask(speech);
            }
            let speech = this.speechBuilder()
                .addText("Let's get straight to the questions: What was the most difficult period in your life and how did you deal with it?");
            this.followUpState('Question22TransState').ask(speech);
        },

        'Unhandled' : function() {
            this.followUpState('Question22State').ask("Do you want my tips or not?");
        }
    },

    'Question22AgainState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText(["Great, let's hear it.", "Well, let's hear the new response.", "Good stuff.", "Excellent choice, let's hear that new response."])
                .addBreak('500ms')
                .addText(" Remember, the question was: What was the most difficult period in your life and how did you deal with it?")
            this.followUpState('Question22TransState').ask(speech);
        },

        'NoIntent' : function() {
           // this.toStateIntent("Question23State", "NoIntent");
           this.toStateIntent("EndState", 'NoIntent');
        },

        'Unhandled' : function() {
            this.followUpState('Question22AgainState').ask("Would you like to improve your response? Yes or no?");
        }
    },


    'Question22TransState' : {
        'Unhandled' : function() {
            this.$user.$data.ques22Ans = this.$googleAction.getRawText();
            this.$user.$data.totalQuesNum = this.$user.$data.totalQuesNum + 1;
            let speech = this.speechBuilder()
                .addText("Good response.")
                .addBreak('500ms')
                .addText("Would you like to hear some tips I have on this question?")
            this.followUpState('EndState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "So soon? So be it then."
            this.tell(speech);
        }
    },
    
    'EndState' : {
        'YesIntent' : function() {
            let speech = this.speechBuilder()
                .addText("Briefly discuss the difficult period in your life.")
                .addBreak('500ms')
                .addText(" Talk about what you learned from that difficulty and how it helped you. Be sure to express tools you used to make it through the difficult time.")
                .addBreak('500ms')
                .addText(" Also talk about anyone who helped you during the difficult time.")
                .addBreak('500ms')
                .addText(" Well, that's all I have for now. Come back and talk to me later to improve your answers and get more tips.")
            this.tell(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder()
                .addText(" Well, that's all I have for now. Come back and talk to me later to improve your answers and get more tips.")
            this.tell(speech);
        },

        // 'DirectIntent' : function() {
        //     let speech = this.speechBuilder()
        //         .addText("Let's get straight to the questions: What was your biggest failure?");
        //     this.followUpState('Question23TransState').ask(speech);
        // },

        'Unhandled' : function() {
            this.followUpState('EndState').ask("Do you want my tips or not?");
        }
    },




});

module.exports.app = app;
