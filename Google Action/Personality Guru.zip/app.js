'use strict';

// ------------------------------------------------------------------
// APP INITIALIZATION
// ------------------------------------------------------------------

const { App } = require('jovo-framework');
const { Alexa } = require('jovo-platform-alexa');
const { GoogleAssistant } = require('jovo-platform-googleassistant');
const { JovoDebugger } = require('jovo-plugin-debugger');
const { FileDb } = require('jovo-db-filedb');
const { DynamoDb } = require('jovo-db-dynamodb');

const app = new App();

app.use(
    new Alexa(),
    new GoogleAssistant(),
    new JovoDebugger(),
    new FileDb(),
    new DynamoDb()
);

app.setDynamoDb('personality-table');


// =================================================================================
// App Logic
// =================================================================================

let test1NumQ = ''
let test2NumQ = ''
let AE_I = 0
let BE_I = 0
let AN_S = 0
let BN_S = 0
let AT_F = 0
let BT_F = 0
let AJ_P = 0
let BJ_P = 0
let totalQ = 0
let firstCat = ''
let secondCat = ''
let thirdCat = ''
let fourthCat = ''
let Eperc = 0
let Iperc = 0
let Nperc = 0
let Sperc = 0
let Tperc = 0
let Fperc = 0
let Jperc = 0
let Pperc = 0
let prevPersonality = ''
let personality = ''


app.setHandler({
    'LAUNCH': function() {
        this.toIntent('LaunchIntent');
    },

    'LaunchIntent' : function() {
        let speech = this.speechBuilder().addText("Hello there, my name is Dr. Jung.")
        .addBreak('500ms')
        .addText(" I’m a Swiss psychiatrist that created analytical psychology, including the concept of archetypes.")
        .addBreak('500ms')
        .addText(" If you like I can help you determine your personality by asking a few questions.")
        speech = speech + this.speechBuilder().addText([" Would you like to figure out your personality type?", ' Do you want to know what your personality type is?'])
        let reprompt = "Want to know your personality?"
        this.followUpState("KnowPersonalityState").ask(speech, reprompt);
    },

    'KnowPersonalityState' : {
        'RepeatIntent': function() {
            this.toStateIntent('UserPersonalityState', 'RepeatYesIntent');
        },

        'YesIntent' : function () {
            let speech = this.speechBuilder().addText("Great let us get your Myers Briggs personality. Are you ready to get started?")
            let reprompt = "Are you prepared to get started?"
            this.followUpState('ReadyForTestState').ask(speech, reprompt);
        },

        'PrevUserPersonality' : function(personalities) {
            prevPersonality = this.$inputs.personalities.value;
            let speech = this.speechBuilder().addText(["Good stuff.", "Interesting.", "Wow."])
            .addBreak('500ms')
            .addText(["I love " + prevPersonality + "s.", prevPersonality + "s are extremely cool.",])
            .addBreak('500ms')
            .addText("That being said, your personality may have changed.")
            .addBreak('500ms')
            .addText("Do you want to see if it has?")
            this.followUpState('ReadyForTestState').ask(speech);

        },

        'NoIntent' : function() {
            let speech = this.speechBuilder().addText("Well okay. I'm here any time you want to talk about personalities or psychology.");
            let reprompt = "Do you want to know what Myers Briggs Personality you are?"
            this.tell(speech);
        },

        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("I asked if you knew your Myers Brigg Personality.")
            .addBreak('500ms')
            .addText("Do you?")
            this.followUpState('KnowPersonalityState').ask(speech);
        },

        "RepeatYesIntent" : function() {
            let speech = this.speechBuilder().addText("Do you want to take the MBTI test?")
            .addBreak('500ms')
            .addText("So say yes or no.");
            this.followUpState('ReadyForTestState').ask(speech);
        },

        "RepeatMyersBriggsInfoIntent" : function() {
            let speech = this.speechBuilder().addText("Do you want to learn more about the personality categories?")
            .addBreak('500ms')
            .addText("So say yes or no.");
            this.followUpState('LearnFourCategoriesState').ask(speech);
        },

        'DoNotCareIntent' : function() {
            let speech = this.speechBuilder().addText("Alright. Suit yourself.")
            this.tell(speech);
        },

        'UnhandledIntent' : function() {
            this.followUpState('KnowPersonalityState').ask("Do you want to figure out if you have a personality?");
        }
    },

    'LearnFourCategoriesState' : {
        'RepeatIntent': function() {
            this.toStateIntent('KnowPersonalityState', 'RepeatMyersBriggsInfoIntent');
        },
        
        'YesIntent' : function() {
            let speech = this.speechBuilder().addText("This is going to be a lot of information, but here it is.")
            .addBreak("500ms")
            .addText("The first category looks at wheter you are extroverted or introverted.")
            .addBreak("500ms")
            .addText("The second focuses on the way you take in information.")
            .addBreak("500ms")
            .addText("The third category is a dive into how you make decisions.")
            .addBreak("500ms")
            .addText("The last, which isn't part of my theory, is how you live you external life.")
            .addBreak('500ms')
            .addText("With that, are you ready to take the MBTI test? I can entertain you with more knowledge after that if you'd like.")
            this.followUpState('ReadyForTestState').ask(speech);
        },

        'NoIntent' : function() {
            let speech = this.speechBuilder().addText("Alright. Do you want to take the MBTI test now?");
            this.followUpState('ReadyForTestState').ask(speech);
        },

        'DoNotCareIntent' : function() {
            let speech = this.speechBuilder().addText("Fine. Would you like to go straight to the MBTI test?")
            this.followUpState('ReadyForTestState').ask(speech);
        },

        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("I asked you if you wanted to learn a bit more on the personality categories.")
            .addBreak('500ms')
            .addText("So say yes or no.")
            this.followUpState('LearnFourCategoriesState').ask(speech);
        },

        'UnhandledIntent' : function() {
            this.followUpState('LearnFourCategoriesState').ask("Want to know more about the four categories that dictate your personality?");
        }
    },

    'ReadyForTestState' : {
        'RepeatIntent': function() {
            this.toStateIntent('NoPersonalityState', 'RepeatYesIntent');
        },
        
        'YesIntent' : function () {
            let speech = this.speechBuilder().addText("Alright, I know you people are pretty busy these days.")
            .addBreak("500ms")
            .addText("So, I have three tests with differing question lengths.")
            .addBreak('500ms')
            .addText("The first is eight.")
            .addBreak('500ms')
            .addText("The second is sixteen.")
            .addBreak('500ms')
            .addText("The third is twenty-four.")
            .addBreak('500ms')
            .addText("With that, how many questions would you like to have on the test?")
            let reprompt = "How many questions do you want on your test?"
            this.followUpState('NumberOfQuestionsState').ask(speech, reprompt);
        },

        'NoIntent' : function() {
            let speech = "Ok. Be that way.";
            this.tell(speech);
        },

        'DoNotCareIntent' : function() {
            let speech = "Ok. Be that way.";
            this.tell(speech);
        },

        'PrevUserPersonality' : function(personalities) {
            prevPersonality = this.$inputs.personalities.value;
            let speech = this.speechBuilder().addText(["Good stuff.", "Interesting.", "Wow."])
            .addBreak('500ms')
            .addText(["I love " + prevPersonality + "s.", prevPersonality + "s are extremely cool.",])
            .addBreak('500ms')
            .addText("That being said, your personality may have changed.")
            .addBreak('500ms')
            .addText("Do you want to see if it has?")
            this.followUpState('ReadyForTestState').ask(speech);
        },

        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("I asked if you had a personality.")
            .addBreak('500ms')
            .addText("So say yes or no.")
            this.followUpState('ReadyForTestState').ask(speech);
        },

        'WhatIsMyersBriggsIntent' : function() {
            let speech = this.speechBuilder().addText("You don't know what a Myers Briggs personality is?")
            .addBreak('500ms')
            .addText("So I believe in this idea that people's personalities were reigned by a few categories. Whatever personality you are indicates differing psychological preferences in how people perceive the world around them and make decisions.")
            .addBreak('500ms')
            .addText("Would you like to learn more about these categories?")
            this.followUpState('LearnFourCategriesState').ask(speech);
        },

        "RepeatYesIntent" : function() {
            let speech = this.speechBuilder().addText("How many questions do you want on your test?")
            .addBreak('500ms')
            .addText("8, 16, or 24?");
            this.followUpState('ReadyForTestState').ask(speech);
        },

        'UnhandledIntent' : function() {
            this.followUpState('ReadyForTestState').ask("Yes or no? Do you want to take the MBTI test to confirm your personality?");
        }
    },

    'NumberOfQuestionsState' : {
        'RepeatIntent': function() {
            this.toStateIntent('ReadyForTestState', 'RepeatYesIntent');
        },
        
        'NumberOfQuestionsIntent' : function(number) {
            let value = this.$inputs.number.value
            if (value == '8' || value == 'eight') {
                let speech = this.speechBuilder().addText("In quite the hurry, huh?")
                .addBreak('500ms')
                .addText("Here's how the test is going to work.")
                .addBreak('500ms')
                .addText("I'm going to give you a question with two answers: A and B.")
                .addBreak('500ms')
                .addText("You are going to choose one of those options.")
                .addBreak('500ms')
                .addText("Easy as pie. Are you ready?")
                this.followUpState('T1ReadyState').ask(speech);
            }

            else if (value == '16' || value == 'sixteen') {
                let speech = this.speechBuilder().addText("Smart. Taking the middle road.")
                .addBreak('500ms')
                .addText("Here's how the test is going to work.")
                .addBreak('500ms')
                .addText("I'm going to give you a question with two answers: A and B.")
                .addBreak('500ms')
                .addText("You are going to choose one of those options.")
                .addBreak('500ms')
                .addText("Easy as pie. Are you ready?")
                this.followUpState('T2ReadyState').ask(speech);
            }

            else if (value == '24' || value == 'twenty-four' || value == 'twentyfour') {
                let speech = this.speechBuilder().addText("Wise. You'll get a deep look into your personality.")
                .addBreak('500ms')
                .addText("Here's how the test is going to work.")
                .addBreak('500ms')
                .addText("I'm going to give you a question with two answers: A and B.")
                .addBreak('500ms')
                .addText("You are going to choose one of those options.")
                .addBreak('500ms')
                .addText("Easy as pie. Are you ready?")
                this.followUpState('T3ReadyState').ask(speech);
            }

            else {
                let speech = this.speechBuilder().addText("I've made this pretty simple.")
                .addBreak('500ms')
                .addText("Say either 8, 16 or 24.")
                this.followUpState('NumberOfQuestionsState').ask(speech);
            }
        },

        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("How many questions did you want on your test?")
            .addBreak('500ms')
            .addText("8, 16, or 24?")
            this.followUpState('NumberOfQuestionsState').ask(speech);
        },

        "RepeatYesIntent" : function() {
            let speech = this.speechBuilder().addText("There are two choices to each of the questions.")
            .addBreak('500ms')
            .addText("Choose the answer that most resonates with you.")
            .addBreak('500ms')
            .addText("Are you ready to start the test?");
            this.followUpState('ReadyForTestState').ask(speech);
        },

        'UnhandledIntent' : function() {
            let speech = speechBuilder().addText("I've made this pretty simple.")
            .addBreak('500ms')
            .addText("Say either 8, 16 or 24.")
            this.followUpState('NumberOfQuestionsState').ask(speech);
        }
    },
    
    
    ///
    // BEGIN Test 1 with 8 Questions
    ///

    'T1ReadyState' : {
        'RepeatIntent': function() {
            this.toStateIntent('NumberOfQuestionsState', 'RepeatYesIntent');
        },
        
        'YesIntent': function() {
            let speech = this.speechBuilder().addText("Here's the first question. \nAt the party, given the two choices what would you be more likely to do?\n")
            .addBreak('500ms')
            .addText('A. Interact with many, including strangers')
            .addBreak('500ms')   
            .addText("\nB. Interact with a few, known to you\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesOneState').ask(speech, reprompt);  
        },

        'UserReadyIntent' : function() {
            let speech = this.speechBuilder().addText("Here's the first question. \nAt the party, given the two choices what would you be more likely to do?\n")
            .addBreak('500ms')
            .addText('A. Interact with many, including strangers')
            .addBreak('500ms')   
            .addText("\nB. Interact with a few, known to you\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesOneState').ask(speech, reprompt); 
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("At the party, given the two choices what would you be more likely to do?\n")
            .addBreak('500ms')
            .addText('A. Interact with many, including strangers')
            .addBreak('500ms')   
            .addText("\nB. Interact with a few, known to you\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesOneState').ask(speech, reprompt); 
        },

        'UserNotReadyIntent' : function() {
            let speech = "Alright. Thank you for wasting my time. Feel free to talk to me again when you are ready.";
            this.tell(speech);
        },

        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("Are you ready to start the test?")
            .addBreak('500ms')
            .addText("So say yes or no.")
            this.followUpState('T1ReadyState').ask(speech);
        },
        
        'NoIntent': function() {
            this.tell("Alright. Thank you for wasting my time. Feel free to talk to me again when you are ready.");
        },

        "Unhandled" : function () {
            this.followUpState('T1ReadyState').ask("Are you ready to take the MBTI? Say yes or no.");
        }

    },

    'T1QuesOneState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1ReadyState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright. I see. Here's the next question.")
                .addBreak('500ms')
                .addText("\nAre you more\n")
                .addBreak('500ms')
                .addText("A. Realistic than speculative?\n")
                .addBreak('500ms')  
                .addText("B. Speculative than realistic?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesTwoState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright. I see. Here's the next question.")
                .addBreak('500ms')
                .addText("\nAre you more\n")
                .addBreak('500ms')
                .addText("A. Realistic than speculative?\n")
                .addBreak('500ms')  
                .addText("B. Speculative than realistic?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesTwoState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesOneState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "This question is pretty cut and dry. I think you can figure it out yourself."
            this.followUpState('T1QuesOneState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more\n")
            .addBreak('500ms')
            .addText("A. Realistic than speculative?\n")
            .addBreak('500ms')  
            .addText("B. Speculative than realistic?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesTwoState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesOneState').ask("Enter an answer choice please.")
        }

    },

    'T1QuesTwoState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesOneState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting. Next one.")
                .addBreak('500ms')
                .addText("\nIs it worse to\n")
                .addBreak('500ms')
                .addText("A. Have your 'head in the clouds'?\n")
                .addBreak('500ms')  
                .addText("B. Be 'in a rut'?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesThreeState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting. Next one.")
                .addBreak('500ms')
                .addText("\nIs it worse to\n")
                .addBreak('500ms')
                .addText("A. Have your 'head in the clouds'?\n")
                .addBreak('500ms')  
                .addText("B. Be 'in a rut'?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesThreeState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesTwoState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Is it worse to\n")
            .addBreak('500ms')
            .addText("A. Have your 'head in the clouds'?\n")
            .addBreak('500ms')  
            .addText("B. Be 'in a rut'?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesThreeState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "Alright. Realistic is easy enough to understand. To be speculative, you're going to be making a lot of assumptions. Now answer the question."
            this.followUpState('T1QuesTwoState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesTwoState').ask("Enter an answer choice please.")
        }

    },

    'T1QuesThreeState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesTwoState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Intriguing. Next one.")
                .addBreak('500ms')
                .addText("\nAre you more impressed by\n")
                .addBreak('500ms')
                .addText("A. Principles?\n")
                .addBreak('500ms')  
                .addText("B. Emotions?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesFourState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Intriguing. Next one.")
                .addBreak('500ms')
                .addText("\nAre you more impressed by\n")
                .addBreak('500ms')
                .addText("A. Principles?\n")
                .addBreak('500ms')  
                .addText("B. Emotions?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesFourState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesThreeState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more impressed by\n")
            .addBreak('500ms')
            .addText("A. Principles?\n")
            .addBreak('500ms')  
            .addText("B. Emotions?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesFourState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "This is simple. You can do it. Answer the question."
            this.followUpState('T1QuesThreeState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesThreeState').ask("Enter an answer choice please.")
        }

    },

    'T1QuesFourState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesThreeState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("I'm impressed by neither. Another one.")
                .addBreak('500ms')
                .addText("\nAre you more drawn toward things that are\n")
                .addBreak('500ms')
                .addText("A. Fact-based?\n")
                .addBreak('500ms')  
                .addText("B. Spiritual?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesFiveState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("I'm impressed by neither. Another one.")
                .addBreak('500ms')
                .addText("\nAre you more drawn toward things that are\n")
                .addBreak('500ms')
                .addText("A. Fact-based?\n")
                .addBreak('500ms')  
                .addText("B. Spiritual?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesFiveState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesFourState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("\nAre you more drawn toward the\n")
            .addBreak('500ms')
            .addText("A. Convincing?\n")
            .addBreak('500ms')  
            .addText("B. Touching?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesFiveState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "This is simple. You can do it. Answer the question."
            this.followUpState('T1QuesFourState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesFourState').ask("Enter an answer choice please.")
        }

    },

    'T1QuesFiveState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesFourState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very intriguing.").addBreak('500ms').addText("I'm drawn towards neither.").addBreak('500ms').addText("Next question!")
                .addBreak('500ms')
                .addText("\nDo you prefer to work\n")
                .addBreak('500ms')
                .addText("A. To deadlines?\n")
                .addBreak('500ms')  
                .addText("B. Just whenever?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesSixState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very intriguing.").addBreak('500ms').addText("I'm drawn towards neither.").addBreak('500ms').addText("Next question!")
                .addBreak('500ms')
                .addText("\nDo you prefer to work\n")
                .addBreak('500ms')
                .addText("A. To deadlines?\n")
                .addBreak('500ms')  
                .addText("B. Just whenever?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesSixState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesFiveState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you prefer to work\n")
            .addBreak('500ms')
            .addText("A. To deadlines?\n")
            .addBreak('500ms')  
            .addText("B. Just whenever?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesSixState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "This is simple. You can do it. Answer the question."
            this.followUpState('T1QuesFiveState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesFiveState').ask("Enter an answer choice please.")
        }

    },

    'T1QuesSixState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesFiveState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A rigid schedule kind of person, huh? Alright, next question.")
                .addBreak('500ms')
                .addText("\nDo you tend to choose\n")
                .addBreak('500ms')
                .addText("A. Rather carefully?\n")
                .addBreak('500ms')  
                .addText("B. Somewhat impulsively?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesSevenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Freelancer, huh? Alright, next question.")
                .addBreak('500ms')
                .addText("\nDo you tend to choose\n")
                .addBreak('500ms')
                .addText("A. Rather carefully?\n")
                .addBreak('500ms')  
                .addText("B. Somewhat impulsively?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesSevenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesSixState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you tend to choose\n")
            .addBreak('500ms')
            .addText("A. Rather carefully?\n")
            .addBreak('500ms')  
            .addText("B. Somewhat impulsively?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesSevenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "This is simple. You can do it. Answer the question."
            this.followUpState('T1QuesSixState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesSixState').ask("Enter an answer choice please.")
        }

    },

    'T1QuesSevenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesSixState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Last question.")
                .addBreak('500ms')
                .addText("\nAt parties, do you\n")
                .addBreak('500ms')
                .addText("A. Stay late, with increasing energy?\n")
                .addBreak('500ms')  
                .addText("B. Leave early with decreased energy?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesEightState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Last question.")
                .addBreak('500ms')
                .addText("\nAt parties, do you\n")
                .addBreak('500ms')
                .addText("A. Stay late, with increasing energy?\n")
                .addBreak('500ms')  
                .addText("B. Leave early with decreased energy?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T1QuesEightState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesSevenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("At parties, do you\n")
            .addBreak('500ms')
            .addText("A. Stay late, with increasing energy?\n")
            .addBreak('500ms')  
            .addText("B. Leave early with decreased energy?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T1QuesEightState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "Ok. Impulsive means that you act without much thought. Now answer."
            this.followUpState('T1QuesSevenState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesSevenState').ask("Enter an answer choice please.")
        }

    },

    'T1QuesEightState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesSevenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T1ResultsState').ask(speech);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T1ResultsState').ask(speech);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T1QuesEightState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Ready to hear the results?")
            let reprompt = "Say yes if you want to hear the results.";
            this.followUpState('T1ResultsState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "This is simple. You can do it. Answer the question."
            this.followUpState('T1QuesEightState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesEightState').ask("Enter an answer choice please.")
        }

    },

    'T1ResultsState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T1QuesEightState', 'QuesRepeatIntent');
        },
        
        'YesIntent': function() {
            Eperc = AE_I/(AE_I + BE_I) * 100;
            Iperc = BE_I/(AE_I + BE_I) * 100;
            Sperc = AN_S/(AN_S + BN_S) * 100;
            Nperc = BN_S/(AN_S + BN_S) * 100;
            Tperc = AT_F/(AT_F + BT_F) * 100;
            Fperc = BT_F/(AT_F + BT_F) * 100;
            Jperc = AJ_P/(AJ_P + BJ_P) * 100;
            Pperc = BJ_P/(AJ_P + BJ_P) * 100;
            firstCat = 'I';
            if (Eperc > Iperc) {
                firstCat = 'E'
            }
            if (Eperc == Iperc) {
                firstCat = 'unknown'
            }
            secondCat = 'S'
            if (Nperc > Sperc) {
                secondCat = 'N'
            }
            if (Nperc == Sperc) {
                secondCat = 'unknown'
            }
            thirdCat = 'T'
            if (Fperc > Tperc) {
                thirdCat = 'F'
            }
            if (Fperc == Tperc) {
                thirdCat = 'unknown'
            }
            fourthCat = 'J'
            if (Pperc > Jperc) {
                fourthCat = 'P'
            }
            if (Pperc == Jperc) {
                fourthCat = 'unknown'
            }

            personality = firstCat + '-' + secondCat + '-' + thirdCat + '-' + fourthCat
            this.$user.$data.personality = personality;

            let speech = ''
            if (firstCat == 'unknown' || secondCat == 'unknown' || thirdCat == 'unknown' || fourthCat == 'unknown' ) {
                speech = speech + this.speechBuilder().addText("To start, because of how short this quiz was some of your results weren't determinable. And because of that we don't know your full personality.")
                .addBreak('500ms')
                .addText(" Don't blame me.")
                .addBreak('500ms')
                .addText(" With that, drumroll please.")
                .addBreak('750ms')
            }
            else {
                speech = speech + this.speechBuilder().addText("Drumroll please.")
                .addBreak('750ms')
            }
            speech = speech + this.speechBuilder()
            .addText(" Based on your answers, your personality is " + personality + ".")
            .addBreak('500ms')
            // .addText(" You are " + Eperc + "% extroverted.")
            // .addBreak('500ms')
            // .addText(" You are " + Iperc + "% introverted.")
            // .addBreak('500ms')
            // .addText(" You are " + Nperc + "% intuitive.")
            // .addBreak('500ms')
            // .addText(" You are " + Sperc + "% sensing.")
            // .addBreak('500ms')
            // .addText(" You are " + Tperc + "% thinking.")
            // .addBreak('500ms')
            // .addText(" You are " + Fperc + "% feeling.")
            // .addBreak('500ms')
            // .addText(" You are " + Pperc + "% perceptive.")
            // .addBreak('500ms')
            // .addText(" You are " + Jperc + "% judging.")
            // .addBreak('500ms')
            .addText(" That is the barebones result. If you have more time, I can explain what those letters mean. Would you like that?")
            this.followUpState('ExpoundOnPersonalityState').ask(speech);

        },

        'NoIntent': function() {
            let speech = "Alright. You went through with the quiz but don't want your results. I'm not juding."
            this.tell(speech);
        },

        'Unhandled': function() {
            this.followUpState('T1ResultsState').ask("You have two choices: yes or no.")
        }
    },

///
//END Test 1 With 8 Questions
///

///
//BEGIN Test 2 With 16 Questions
///

    'T2ReadyState' : {
        'RepeatIntent': function() {
            this.toStateIntent('NumberOfQuestionsState', 'RepeatYesIntent');
        },
        
        'YesIntent': function() {
            let speech = this.speechBuilder().addText("Here's the first question. \nIn social groups, do you\n")
            .addBreak('500ms')
            .addText("A. Keep up of other's happenings")
            .addBreak('500ms')   
            .addText("\nB. Get behind on the news\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesOneState').ask(speech, reprompt);  
        },

        'UserReadyIntent' : function() {
            let speech = this.speechBuilder().addText("Here's the first question. \nIn social groups, do you\n")
            .addBreak('500ms')
            .addText("A. Keep up of other's happenings")
            .addBreak('500ms')   
            .addText("\nB. Get behind on the news\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesOneState').ask(speech, reprompt); 
        },

        'UserNotReadyIntent' : function() {
            let speech = "Alright. Thank you for wasting my time. Feel free to talk to me again when you are ready.";
            this.tell(speech);
        },
        
        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("In social groups, do you\n")
            .addBreak('500ms')
            .addText("A. Keep up of other's happenings")
            .addBreak('500ms')   
            .addText("\nB. Get behind on the news\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesOneState').ask(speech, reprompt); 
        },
        
        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("Are you ready to start the test?")
            .addBreak('500ms')
            .addText("So say yes or no.")
            this.followUpState('T2ReadyState').ask(speech);
        },
        
        'NoIntent': function() {
            this.tell("Alright. Thank you for wasting my time. Feel free to talk to me again when you are ready.");
        },

        "Unhandled" : function () {
            this.followUpState('T2ReadyState').ask("Are you ready to take the MBTI? Say yes or no.");
        }

    },

    'T2QuesOneState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2ReadyState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright. Here's the next question.")
                .addBreak('500ms')
                .addText("\nIn doing ordinary things are you more likely to\n")
                .addBreak('500ms')
                .addText("A. Do it the usual way?\n")
                .addBreak('500ms')  
                .addText("B. Do it your way?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesTwoState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright. I see you. Here's the next question.")
                .addBreak('500ms')
                .addText("\nIn doing ordinary things are you more likely to\n")
                .addBreak('500ms')
                .addText("A. Do it the usual way?\n")
                .addBreak('500ms')  
                .addText("B. Do it your way?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesTwoState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesOneState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("Well are you either going to get keep up with the social news or do you not care?")
            .addBreak('500ms')
            .addText('A or B.');
            this.followUpState('T2QuesOneState').ask(speech);
        },
    
        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("In doing ordinary things are you more likely to\n")
            .addBreak('500ms')
            .addText("A. Do it the usual way?\n")
            .addBreak('500ms')  
            .addText("B. Do it your way?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesTwoState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesOneState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesTwoState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesOneState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Perfect. Next question.")
                .addBreak('500ms')
                .addText("\nWriters should\n")
                .addBreak('500ms')
                .addText("A. Say what they mean and mean what they say.\n")
                .addBreak('500ms')  
                .addText("B. Express things more by use of analogy\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesThreeState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Perfect. Next question.")
                .addBreak('500ms')
                .addText("\nWriters should\n")
                .addBreak('500ms')
                .addText("A. Say what they mean and mean what they say.\n")
                .addBreak('500ms')  
                .addText("B. Express things more by use of analogy\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesThreeState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesTwoState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Writers should\n")
            .addBreak('500ms')
            .addText("A. Say what they mean and mean what they say.\n")
            .addBreak('500ms')  
            .addText("B. Express things more by use of analogy\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesThreeState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T1QuesTwoState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T1QuesTwoState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesThreeState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesTwoState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting. Next one.")
                .addBreak('500ms')
                .addText("\nWhich appeals to you more?\n")
                .addBreak('500ms')
                .addText("A. Consistency of thought\n")
                .addBreak('500ms')  
                .addText("B. Harmonious human relationships\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFourState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting. Next one.")
                .addBreak('500ms')
                .addText("\nWhich appeals to you more?\n")
                .addBreak('500ms')
                .addText("A. Consistency of thought\n")
                .addBreak('500ms')  
                .addText("B. Harmonious human relationships\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFourState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesThreeState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Which appeals to you more?\n")
            .addBreak('500ms')
            .addText("A. Consistency of thought\n")
            .addBreak('500ms')  
            .addText("B. Harmonious human relationships\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesFourState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("Alright, so basically the first option suggests that writers should have a fixed and obvious theme.")
            .addBreak('500ms')
            .addText("The second option means you think it's fines for writers to have dubious meanings and use various literary language to express those meanings.")
            .addBreak('500ms')
            .addText("So A or B?");
            this.followUpState('T2QuesThreeState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesThreeState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesFourState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesThreeState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Personally, I want both. Another one.")
                .addBreak('500ms')
                .addText("\nAre you more comfortable in making\n")
                .addBreak('500ms')
                .addText("A. Logical judgements?\n")
                .addBreak('500ms')  
                .addText("B. Value judgements?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFiveState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Personally, I want both. Another one.")
                .addBreak('500ms')
                .addText("\nAre you more comfortable in making\n")
                .addBreak('500ms')
                .addText("A. Logical judgements?\n")
                .addBreak('500ms')  
                .addText("B. Value judgements?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFiveState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesFourState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more comfortable in making\n")
            .addBreak('500ms')
            .addText("A. Logical judgements?\n")
            .addBreak('500ms')  
            .addText("B. Value judgements?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesFiveState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "Just think about it this way, which sounds better to you? A or B?"
            this.followUpState('T2QuesFourState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesFourState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesFiveState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesFourState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very intriguing.").addBreak('500ms').addText("I'm not comfortable making either.").addBreak('500ms').addText("Next question!")
                .addBreak('500ms')
                .addText("\nDo you want things\n")
                .addBreak('500ms')
                .addText("A. Settled and decided?\n")
                .addBreak('500ms')  
                .addText("B. Fluid and subject to change?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesSixState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very intriguing.").addBreak('500ms').addText("I'm not comfortable making either.").addBreak('500ms').addText("Next question!")
                .addBreak('500ms')
                .addText("\nDo you want things\n")
                .addBreak('500ms')
                .addText("A. Settled and decided?\n")
                .addBreak('500ms')  
                .addText("B. Fluid and subject to change?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesSixState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesFiveState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("Logical judgements are usually those based on evidence and analysis.")
            .addBreak('500ms')
            .addText("Value judgements are those based on morals and someone's values.")
            .addBreak('500ms')
            .addText("With that, choose either A or B.");
            this.followUpState('T2QuesFiveState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you want things\n")
            .addBreak('500ms')
            .addText("A. Settled and decided?\n")
            .addBreak('500ms')  
            .addText("B. Fluid and subject to change?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesSixState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesFiveState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesSixState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesFiveState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A rigid schedule kind of person, huh? Alright, next question.")
                .addBreak('500ms')
                .addText("\nWould you say you are more\n")
                .addBreak('500ms')
                .addText("A. Serious and determined?\n")
                .addBreak('500ms')  
                .addText("B. Easy-going and relaxed?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesSevenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A relaxed schedule kind of person, huh? Alright, next question.")
                .addBreak('500ms')
                .addText("\nWould you say you are more\n")
                .addBreak('500ms')
                .addText("A. Serious and determined?\n")
                .addBreak('500ms')  
                .addText("B. Easy-going and relaxed?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesSevenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesSixState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T2QuesSixState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Would you say you are more\n")
            .addBreak('500ms')
            .addText("A. Serious and determined?\n")
            .addBreak('500ms')  
            .addText("B. Easy-going and relaxed?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesSevenState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesSixState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesSevenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesSixState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Half way there.")
                .addBreak('500ms')
                .addText("\nWhen phoning someone, do you\n")
                .addBreak('500ms')
                .addText("A. Rarely question what you're going to say?\n")
                .addBreak('500ms')  
                .addText("B. Rehearse what you will say?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesEightState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Half way there.")
                .addBreak('500ms')
                .addText("\nWhen phoning someone, do you\n")
                .addBreak('500ms')
                .addText("A. Rarely question what you're going to say?\n")
                .addBreak('500ms')  
                .addText("B. Rehearse what you will say?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesEightState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesSevenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("When phoning someone, do you\n")
            .addBreak('500ms')
            .addText("A. Rarely question what you're going to say?\n")
            .addBreak('500ms')  
            .addText("B. Rehearse what you will say?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesEightState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T2QuesSevenState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesSevenState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesEightState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesSevenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("We're halfway done.")
                .addBreak('500ms')
                .addText("\nWhen with company, do you\n")
                .addBreak('500ms')
                .addText("A. Initiate conversation?\n")
                .addBreak('500ms')  
                .addText("B. Want to be approached?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesNineState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("We're halfway done.")
                .addBreak('500ms')
                .addText("\nWhen with company, do you\n")
                .addBreak('500ms')
                .addText("A. Initiate conversation?\n")
                .addBreak('500ms')  
                .addText("B. Want to be approached?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesNineState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesEightState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("When with company, do you\n")
            .addBreak('500ms')
            .addText("A. Initiate conversation?\n")
            .addBreak('500ms')  
            .addText("B. Want to be approached?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesNineState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T2QuesEightState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesEightState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesNineState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesEightState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Fabulous. Next one.")
                .addBreak('500ms')
                .addText("\nFacts\n")
                .addBreak('500ms')
                .addText("A. Speak for themselves\n")
                .addBreak('500ms')  
                .addText("B. Illustrate principles\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesTenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Fabulous. Next one.")
                .addBreak('500ms')
                .addText("\nFacts\n")
                .addBreak('500ms')
                .addText("A. Speak for themselves\n")
                .addBreak('500ms')  
                .addText("B. Illustrate principles\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesTenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesNineState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("This is pretty simple.")
            .addBreak('500ms')
            .addText("When you're with other people, do you go start talking to people or do you wait for people to come talk to you?")
            .addBreak('500ms')
            .addText("A or B?");
            this.followUpState('T2QuesNineState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Facts\n")
            .addBreak('500ms')
            .addText("A. Speak for themselves\n")
            .addBreak('500ms')  
            .addText("B. Illustrate principles\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesTenState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesNineState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesTenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesNineState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Truly magnificent. Here's another one.")
                .addBreak('500ms')
                .addText("\nAre visionaries\n")
                .addBreak('500ms')
                .addText("A. Somewhat annoying?\n")
                .addBreak('500ms')  
                .addText("B. Rather fascinating?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesElevenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Truly magnificent. Here's another one.")
                .addBreak('500ms')
                .addText("\nAre visionaries\n")
                .addBreak('500ms')
                .addText("A. Somewhat annoying?\n")
                .addBreak('500ms')  
                .addText("B. Rather fascinating?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesElevenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesTenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are visionaries\n")
            .addBreak('500ms')
            .addText("A. Somewhat annoying?\n")
            .addBreak('500ms')  
            .addText("B. Rather fascinating?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesElevenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T2QuesTenState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesTenState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesElevenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesTenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Next question.")
                .addBreak('500ms')
                .addText("\nAre you more often\n")
                .addBreak('500ms')
                .addText("A. A cool-headed person?\n")
                .addBreak('500ms')  
                .addText("B. A warm-headed person?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesTwelveState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Next question.")
                .addBreak('500ms')
                .addText("\nAre you more often\n")
                .addBreak('500ms')
                .addText("A. A cool-headed person?\n")
                .addBreak('500ms')  
                .addText("B. A warm-headed person?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesTwelveState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesElevenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more often\n")
            .addBreak('500ms')
            .addText("A. A cool-headed person?\n")
            .addBreak('500ms')  
            .addText("B. A warm-headed person?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesTwelveState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("The only hard part should be what a visionary is.")
            .addBreak('500ms')
            .addText("A visionary is someone who looks at the future with imagination.")
            .addBreak('500ms')
            .addText("With that information, answer the question.");
            this.followUpState('T2QuesElevenState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesElevenState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesTwelveState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesElevenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Another one.")
                .addBreak('500ms')
                .addText("\nIs it worse to be\n")
                .addBreak('500ms')
                .addText("A. Unjust?\n")
                .addBreak('500ms')  
                .addText("B. Merciless?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesThirteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Another one.")
                .addBreak('500ms')
                .addText("\nIs it worse to be\n")
                .addBreak('500ms')
                .addText("A. Unjust?\n")
                .addBreak('500ms')  
                .addText("B. Merciless?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesThirteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesTwelveState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Is it worse to be\n")
            .addBreak('500ms')
            .addText("A. Unjust?\n")
            .addBreak('500ms')  
            .addText("B. Merciless?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesThirteenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("This one's pretty simple.")
            .addBreak('500ms')
            .addText("Are you someone who is chill or do you get angry often?")
            .addBreak('500ms')
            .addText('Option A or B?')
            this.followUpState('T2QuesTwelveState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesTwelveState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesThirteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesTwelveState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A couple more questions.")
                .addBreak('500ms')
                .addText("\nShould one usually let events occur\n")
                .addBreak('500ms')
                .addText("A. By careful selection and choice?\n")
                .addBreak('500ms')  
                .addText("B. Randomly and let nature run the process?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFourteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A couple more questions.")
                .addBreak('500ms')
                .addText("\nShould one usually let events occur\n")
                .addBreak('500ms')
                .addText("A. By careful selection and choice?\n")
                .addBreak('500ms')  
                .addText("B. Randomly and let nature run the process?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFourteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesThirteenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Should one usually let events occur\n")
            .addBreak('500ms')
            .addText("A. By careful selection and choice?\n")
            .addBreak('500ms')  
            .addText("B. Randomly and let nature run the process?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesFourteenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "Which one is the worse evil?"
            this.followUpState('T2QuesThirteenState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesThirteenState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesFourteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesThirteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Almost to the end. Here's the next one.")
                .addBreak('500ms')
                .addText("\nDo you feel better about\n")
                .addBreak('500ms')
                .addText("A. having purchased something?\n")
                .addBreak('500ms')  
                .addText("B. having the option to buy something?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFifteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Almost to the end. Here's the next one.")
                .addBreak('500ms')
                .addText("\nDo you feel better about\n")
                .addBreak('500ms')
                .addText("A. having purchased something?\n")
                .addBreak('500ms')  
                .addText("B. having the option to buy something?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesFifteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesFourteenState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T2QuesFourteenState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you feel better about\n")
            .addBreak('500ms')
            .addText("A. having purchased something?\n")
            .addBreak('500ms')  
            .addText("B. having the option to buy something?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesFifteenState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesFourteenState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesFifteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesFourteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Last question.")
                .addBreak('500ms')
                .addText("\nDoes new and non-routine interaction with others\n")
                .addBreak('500ms')
                .addText("A. Stimulate and energize you?\n")
                .addBreak('500ms')  
                .addText("B. Tax your reserves?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesSixteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Last question.")
                .addBreak('500ms')
                .addText("\nDoes new and non-routine interaction with others\n")
                .addBreak('500ms')
                .addText("A. Stimulate and energize you?\n")
                .addBreak('500ms')  
                .addText("B. Tax your reserves?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T2QuesSixteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesFifteenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Does new and non-routine interaction with others\n")
            .addBreak('500ms')
            .addText("A. Stimulate and energize you?\n")
            .addBreak('500ms')  
            .addText("B. Tax your reserves?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesSixteenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T2QuesFifteenState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesFifteenState').ask("Enter an answer choice please.")
        }

    },

    'T2QuesSixteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesFifteenState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T2ResultsState').ask(speech);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T2ResultsState').ask(speech);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T2QuesSixteenState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("An easy question.")
            .addBreak('500ms')
            .addText("Does being with others lower your energy levels or increase them?")
            .addBreak('500ms')
            .addText("A or B?");
            this.followUpState('T2QuesSeventeenState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Ready to hear the results?");
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T2QuesFourteenState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T2QuesSixteenState').ask("Enter an answer choice please.")
        }

    },

    'T2ResultsState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T2QuesOneState', 'QuesRepeatIntent');
        },

        'YesIntent': function() {
            Eperc = AE_I/(AE_I + BE_I) * 100;
            Iperc = BE_I/(AE_I + BE_I) * 100;
            Sperc = AN_S/(AN_S + BN_S) * 100;
            Nperc = BN_S/(AN_S + BN_S) * 100;
            Tperc = AT_F/(AT_F + BT_F) * 100;
            Fperc = BT_F/(AT_F + BT_F) * 100;
            Jperc = AJ_P/(AJ_P + BJ_P) * 100;
            Pperc = BJ_P/(AJ_P + BJ_P) * 100;
            firstCat = 'I';
            if (Eperc > Iperc) {
                firstCat = 'E'
            }
            if (Eperc == Iperc) {
                firstCat = 'unknown'
            }
            secondCat = 'S'
            if (Nperc > Sperc) {
                secondCat = 'N'
            }
            if (Nperc == Sperc) {
                secondCat = 'unknown'
            }
            thirdCat = 'T'
            if (Fperc > Tperc) {
                thirdCat = 'F'
            }
            if (Fperc == Tperc) {
                thirdCat = 'unknown'
            }
            fourthCat = 'J'
            if (Pperc > Jperc) {
                fourthCat = 'P'
            }
            if (Pperc == Jperc) {
                fourthCat = 'unknown'
            }

            personality = firstCat + '-' + secondCat + '-' + thirdCat + '-' + fourthCat
            this.$user.$data.personality = personality;
            
            let speech = ''
            if (firstCat == 'unknown' || secondCat == 'unknown' || thirdCat == 'unknown' || fourthCat == 'unknown' ) {
                speech = speech + this.speechBuilder().addText("To start, because of how short this quiz was some of your results weren't determinable. And because of that we don't know your full personality.")
                .addBreak('500ms')
                .addText(" Don't blame me.")
                .addBreak('500ms')
                .addText(" With that, drumroll please.")
                .addBreak('750ms')
            }
            else {
                speech = speech + this.speechBuilder().addText("Drumroll please.")
                .addBreak('750ms')
            }
            speech = speech + this.speechBuilder()
            .addText(" Based on your answers, your personality is " + personality + ".")
            .addBreak('500ms')
            // .addText(" You are " + Eperc + "% extroverted.")
            // .addBreak('500ms')
            // .addText(" You are " + Iperc + "% introverted.")
            // .addBreak('500ms')
            // .addText(" You are " + Nperc + "% intuitive.")
            // .addBreak('500ms')
            // .addText(" You are " + Sperc + "% sensing.")
            // .addBreak('500ms')
            // .addText(" You are " + Tperc + "% thinking.")
            // .addBreak('500ms')
            // .addText(" You are " + Fperc + "% feeling.")
            // .addBreak('500ms')
            // .addText(" You are " + Pperc + "% perceptive.")
            // .addBreak('500ms')
            // .addText(" You are " + Jperc + "% judging.")
            // .addBreak('500ms')
            .addText(" That is the barebones result. If you have more time, I can explain what those letters mean. Would you like that?")
            this.followUpState('ExpoundOnPersonalityState').ask(speech);

        },

        'NoIntent': function() {
            let speech = "Alright. You went through with the quiz but don't want your results. I'm not juding."
            this.tell(speech);
        },

        'Unhandled': function() {
            this.followUpState('T2ResultsState').ask("You have two choices: yes or no.")
        }
    },

    ///
    //END Test 2 with 8 Questions
    ///


    ///
    //BEGIN Test 3 With 24 Questions
    ///
    //43
    'T3ReadyState' : {
        'RepeatIntent': function() {
            this.toStateIntent('NumberOfQuestionsState', 'RepeatYesIntent');
        },
        
        'YesIntent': function() {
            let speech = this.speechBuilder().addText("Here's the first question. \nDo you prefer\n")
            .addText("A. Many friends with brief contact")
            .addBreak('500ms')  
            .addText("\nB. A few friends with more lengthy contact\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesOneState').ask(speech, reprompt); 
        },

        'UserReadyIntent' : function() {
            let speech = this.speechBuilder().addText("Here's the first question. \nDo you prefer\n")
            .addText("A. Many friends with brief contact")
            .addBreak('500ms')  
            .addText("\nB. A few friends with more lengthy contact\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesOneState').ask(speech, reprompt);
        },

        'UserNotReadyIntent' : function() {
            let speech = "Alright. Thank you for wasting my time. Feel free to talk to me again when you are ready.";
            this.tell(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you prefer\n")
            .addText("A. Many friends with brief contact")
            .addBreak('500ms')  
            .addText("\nB. A few friends with more lengthy contact\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesOneState').ask(speech, reprompt); 
        },

        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("Are you ready to start the test?")
            .addBreak('500ms')
            .addText("So say yes or no.")
            this.followUpState('T1ReadyState').ask(speech);
        },
    
        'NoIntent': function() {
            this.tell("Alright. Thank you for wasting my time. Feel free to talk to me again when you are ready.");
        },

        "Unhandled" : function () {
            this.followUpState('T3ReadyState').ask("Are you ready to take the MBTI? Say yes or no.");
        }

    },
    //44
    'T3QuesOneState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3ReadyState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright. Here's the next question.")
                .addBreak('500ms')
                .addText("\nDo you go more by\n")
                .addBreak('500ms')
                .addText("A. Facts?\n")
                .addBreak('500ms') 
                .addText("B. Principles?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwoState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright. Here's the next question.")
                .addBreak('500ms')
                .addText("\nDo you go more by\n")
                .addBreak('500ms')
                .addText("A. Facts?\n")
                .addBreak('500ms') 
                .addText("B. Principles?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwoState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesOneState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesOneState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you go more by\n")
            .addBreak('500ms')
            .addText("A. Facts?\n")
            .addBreak('500ms') 
            .addText("B. Principles?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTwoState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesOneState').ask("Enter an answer choice please.")
        }

    },
    //45
    'T3QuesTwoState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesOneState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Perfect. Next question.")
                .addBreak('500ms')
                .addText("\nAre you more interested in\n")
                .addBreak('500ms')
                .addText("A. Production and distribution?\n")
                .addBreak('500ms') 
                .addText("B. Design and research?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesThreeState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Perfect. Next question.")
                .addBreak('500ms')
                .addText("\nAre you more interested in\n")
                .addBreak('500ms')
                .addText("A. Production and distribution?\n")
                .addBreak('500ms') 
                .addText("B. Design and research?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesThreeState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTwoState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("So if you go more by facts, then you are basing everything on evidence whether or not it goes against your gut.")
            .addBreak('500ms')
            .addText("Going by principles is the opposite. Going with your intuition even if the facts go against you.")
            .addBreak("500ms")
            .addText("With that said, what's your answer? A or B?")
            this.followUpState('T1QuesTwoState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more interested in\n")
            .addBreak('500ms')
            .addText("A. Production and distribution?\n")
            .addBreak('500ms') 
            .addText("B. Design and research?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesThreeState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T1QuesTwoState').ask("Enter an answer choice please.")
        }

    },
    //46
    'T3QuesThreeState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTwoState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting. Next one.")
                .addBreak('500ms')
                .addText("\nWhich is more of a compliment?\n")
                .addBreak('500ms')
                .addText("A. 'You are a very logical person'\n")
                .addBreak('500ms') 
                .addText("B. 'You are a very sentimental person'\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFourState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting. Next one.")
                .addBreak('500ms')
                .addText("\nWhich is more of a compliment?\n")
                .addBreak('500ms')
                .addText("A. 'You are a very logical person'\n")
                .addBreak('500ms') 
                .addText("B. 'You are a very sentimental person'\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFourState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesThreeState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesThreeState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Which is more of a compliment?\n")
            .addBreak('500ms')
            .addText("A. 'You are a very logical person'\n")
            .addBreak('500ms') 
            .addText("B. 'You are a very sentimental person'\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesFourState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesThreeState').ask("Enter an answer choice please.")
        }

    },
    //47
    'T3QuesFourState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesThreeState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Personally, I'll take both. Another one.")
                .addBreak('500ms')
                .addText("\nWould you say you are more\n")
                .addBreak('500ms')
                .addText("A. Unwavering?\n")
                .addBreak('500ms') 
                .addText("B. Devoted?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFiveState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Personally, I'll take both. Another one.")
                .addBreak('500ms')
                .addText("\nWould you say you are more\n")
                .addBreak('500ms')
                .addText("A. Unwavering?\n")
                .addBreak('500ms') 
                .addText("B. Devoted?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFiveState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesFourState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("Logical means you analyze facts and make decisions.")
            .addBreak('500ms')
            .addText("Being sentimental means you are willing to forsake some of the facts for your values.")
            .addBreak("500ms")
            .addText("With that said, what's your answer? A or B?")
            this.followUpState('T3QuesFourState').ask("Enter an answer choice please.")
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Would you say you are more\n")
            .addBreak('500ms')
            .addText("A. Unwavering?\n")
            .addBreak('500ms') 
            .addText("B. Devoted?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesFiveState').ask(speech, reprompt); 
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesFourState').ask("Enter an answer choice please.")
        }

    },
    //48
    'T3QuesFiveState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesFourState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting.").addBreak('500ms').addText("Next question!")
                .addBreak('500ms')
                .addText("\nDo you more often prefer the\n")
                .addBreak('500ms')
                .addText("A. Final and unalterable statement?\n")
                .addBreak('500ms') 
                .addText("B. Tentative and preliminary statement?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSixState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very interesting.").addBreak('500ms').addText("Next question!")
                .addBreak('500ms')
                .addText("\nDo you more often prefer the\n")
                .addBreak('500ms')
                .addText("A. Final and unalterable statement?\n")
                .addBreak('500ms') 
                .addText("B. Tentative and preliminary statement?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSixState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesFiveState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You can be both but choose which one you end up being more often. A or B?"
            this.followUpState('T3QuesFiveState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you more often prefer the\n")
            .addBreak('500ms')
            .addText("A. Final and unalterable statement?\n")
            .addBreak('500ms') 
            .addText("B. Tentative and preliminary statement?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesSixState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesFiveState').ask("Enter an answer choice please.")
        }

    },
    //49
    'T3QuesSixState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesFiveState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A rigid kind of person, huh? Alright, next question.")
                .addBreak('500ms')
                .addText("\nAre you more comfortable\n")
                .addBreak('500ms')
                .addText("A. After a decision?\n")
                .addBreak('500ms') 
                .addText("B. Before a decision?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSevenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A lax kind of person, huh? Alright, next question.")
                .addBreak('500ms')
                .addText("\nAre you more comfortable\n")
                .addBreak('500ms')
                .addText("A. After a decision?\n")
                .addBreak('500ms') 
                .addText("B. Before a decision?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSevenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesSixState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more comfortable\n")
            .addBreak('500ms')
            .addText("A. After a decision?\n")
            .addBreak('500ms') 
            .addText("B. Before a decision?\n")
            this.followUpState('T3QuesSevenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = this.speechBuilder().addText("Think about it this way. Would you have something set in stone.")
            .addBreak('500ms')
            .addText("Or would you want it to be subject to change at any time?")
            .addBreak("500ms")
            .addText("What's your answer? A or B?")
            this.followUpState('T3QuesSixState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesSixState').ask("Enter an answer choice please.")
        }

    },
    //50
    'T3QuesSevenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesSixState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. You are marching along just fine.")
                .addBreak('500ms')
                .addText("\nDo you\n")
                .addBreak('500ms')
                .addText("A. Speak easily and at length with strangers?\n")
                .addBreak('500ms') 
                .addText("B. Find little to say to strangers?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesEightState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. You are marching along just fine.")
                .addBreak('500ms')
                .addText("\nDo you\n")
                .addBreak('500ms')
                .addText("A. Speak easily and at length with strangers?\n")
                .addBreak('500ms') 
                .addText("B. Find little to say to strangers?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesEightState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesSevenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you\n")
            .addBreak('500ms')
            .addText("A. Speak easily and at length with strangers?\n")
            .addBreak('500ms') 
            .addText("B. Find little to say to strangers?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesEightState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesSevenState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesSevenState').ask("Enter an answer choice please.")
        }

    },
    //29
    'T3QuesEightState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesSevenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good stuff.")
                .addBreak('500ms')
                .addText("\nWhen with company, do you\n")
                .addBreak('500ms')
                .addText("A. Initiate conversation?\n")
                .addBreak('500ms') 
                .addText("B. Want to be approached?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesNineState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good stuff.")
                .addBreak('500ms')
                .addText("\nWhen with company, do you\n")
                .addBreak('500ms')
                .addText("A. Initiate conversation?\n")
                .addBreak('500ms') 
                .addText("B. Want to be approached?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesNineState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesEightState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesEightState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("When with company, do you\n")
            .addBreak('500ms')
            .addText("A. Initiate conversation?\n")
            .addBreak('500ms') 
            .addText("B. Want to be approached?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesNineState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesEightState').ask("Enter an answer choice please.")
        }

    },
    //51
    'T3QuesNineState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesEightState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Fabulous. Next one.")
                .addBreak('500ms')
                .addText("\nAre you more likely to trust your\n")
                .addBreak('500ms')
                .addText("A. Experience\n")
                .addBreak('500ms') 
                .addText("B. Hunch\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Fabulous. Next one.")
                .addBreak('500ms')
                .addText("\nAre you more likely to trust your\n")
                .addBreak('500ms')
                .addText("A. Experience\n")
                .addBreak('500ms') 
                .addText("B. Hunch\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesNineState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more likely to trust your\n")
            .addBreak('500ms')
            .addText("A. Experience\n")
            .addBreak('500ms') 
            .addText("B. Hunch\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTenState').ask(speech, reprompt); 
        },
        
        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesNineState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesNineState').ask("Enter an answer choice please.")
        }

    },
    //52
    'T3QuesTenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesNineState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Truly magnificent. Here's another one.")
                .addBreak('500ms')
                .addText("\nDo you feel\n")
                .addBreak('500ms')
                .addText("A. More practical than ingenious?\n")
                .addBreak('500ms') 
                .addText("B. More ingenious than practical?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesElevenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Truly magnificent. Here's another one.")
                .addBreak('500ms')
                .addText("\nDo you feel\n")
                .addBreak('500ms')
                .addText("A. More practical than ingenious?\n")
                .addBreak('500ms') 
                .addText("B. More ingenious than practical?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesElevenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you feel\n")
            .addBreak('500ms')
            .addText("A. More practical than ingenious?\n")
            .addBreak('500ms') 
            .addText("B. More ingenious than practical?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesElevenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesTenState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesTenState').ask("Enter an answer choice please.")
        }

    },
    //53
    'T3QuesElevenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Next question.")
                .addBreak('500ms')
                .addText("\nWhich type of person should be complimented?\n")
                .addBreak('500ms')
                .addText("A. One of clear reason?\n")
                .addBreak('500ms') 
                .addText("B. A One of strong feeling?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwelveState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Next question.")
                .addBreak('500ms')
                .addText("\nWhich type of person should be complimented?\n")
                .addBreak('500ms')
                .addText("A. One of clear reason?\n")
                .addBreak('500ms') 
                .addText("B. A One of strong feeling?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwelveState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesElevenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Which type of person should be complimented?\n")
            .addBreak('500ms')
            .addText("A. One of clear reason?\n")
            .addBreak('500ms') 
            .addText("B. A One of strong feeling?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTwelveState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesElevenState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesElevenState').ask("Enter an answer choice please.")
        }

    },
    //54
    'T3QuesTwelveState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesElevenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Halfway done.")
                .addBreak('500ms')
                .addText("\nAre you more inclined to be\n")
                .addBreak('500ms')
                .addText("A. Fair-minded?\n")
                .addBreak('500ms') 
                .addText("B. Sympathetic?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesThirteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Halfway done.")
                .addBreak('500ms')
                .addText("\nAre you more inclined to be\n")
                .addBreak('500ms')
                .addText("A. Fair-minded?\n")
                .addBreak('500ms') 
                .addText("B. Sympathetic?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesThirteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTwelveState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more inclined to be\n")
            .addBreak('500ms')
            .addText("A. Fair-minded?\n")
            .addBreak('500ms') 
            .addText("B. Sympathetic?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesThirteenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesTwelveState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesTwelveState').ask("Enter an answer choice please.")
        }

    },
    //55
    'T3QuesThirteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTwelveState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("I think you should be both. Next question.")
                .addBreak('500ms')
                .addText("\nShould one usually let events occur\n")
                .addBreak('500ms')
                .addText("A. By careful selection and choice?\n")
                .addBreak('500ms') 
                .addText("B. Randomly and let nature run the process?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFourteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("I think you should be both. Next question.")
                .addBreak('500ms')
                .addText("\nIs it best to\n")
                .addBreak('500ms')
                .addText("A. Make sure things are arranged?\n")
                .addBreak('500ms') 
                .addText("B. Just let things happen?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFourteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesThirteenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Should one usually let events occur\n")
            .addBreak('500ms')
            .addText("A. By careful selection and choice?\n")
            .addBreak('500ms') 
            .addText("B. Randomly and let nature run the process?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesFourteenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesThirteenState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesThirteenState').ask("Enter an answer choice please.")
        }

    },
    //56
    'T3QuesFourteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesThirteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("You're more than halfway to the end. Here's the next one.")
                .addBreak('500ms')
                .addText("\nIn relationships, should most things be\n")
                .addBreak('500ms')
                .addText("A. re-negotiable?\n")
                .addBreak('500ms') 
                .addText("B. random and circumstantial?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFifteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("You're more than halfway to the end. Here's the next one.")
                .addBreak('500ms')
                .addText("\nIn relationships, should most things be\n")
                .addBreak('500ms')
                .addText("A. re-negotiable?\n")
                .addBreak('500ms') 
                .addText("B. random and circumstantial?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesFifteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesFourteenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("In relationships, should most things be\n")
            .addBreak('500ms')
            .addText("A. re-negotiable?\n")
            .addBreak('500ms') 
            .addText("B. random and circumstantial?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesFifteenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesFourteenState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesFourteenState').ask("Enter an answer choice please.")
        }

    },
    //57
    'T3QuesFifteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesFourteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very good. Next question.")
                .addBreak('500ms')
                .addText("\nGiven the two choices, what's a better vacation?\n")
                .addBreak('500ms')
                .addText("A. Resting at home\n")
                .addBreak('500ms') 
                .addText("B. Adventuring exotic lands\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSixteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Very good. Next question.")
                .addBreak('500ms')
                .addText("\nGiven the two choices, what's a better vacation?\n")
                .addBreak('500ms')
                .addText("A. Resting at home\n")
                .addBreak('500ms') 
                .addText("B. Adventuring exotic lands\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSixteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesFifteenState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("\nGiven the two choices, what's a better vacation?\n")
            .addBreak('500ms')
            .addText("A. Resting at home\n")
            .addBreak('500ms') 
            .addText("B. Adventuring exotic lands\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesSixteenState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesFifteenState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesFifteenState').ask("Enter an answer choice please.")
        }

    },
    //36
    'T3QuesSixteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesFifteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you.")
                .addBreak('500ms')
                .addText("\nDoes new and non-routine interaction with others\n")
                .addBreak('500ms')
                .addText("A. Stimulate and energize you?\n")
                .addBreak('500ms') 
                .addText("B. Tax your reserves?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSeventeenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you.")
                .addBreak('500ms')
                .addText("\nDoes new and non-routine interaction with others\n")
                .addBreak('500ms')
                .addText("A. Stimulate and energize you?\n")
                .addBreak('500ms') 
                .addText("B. Tax your reserves?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesSeventeenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesSixteenState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesSixteenState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Does new and non-routine interaction with others\n")
            .addBreak('500ms')
            .addText("A. Stimulate and energize you?\n")
            .addBreak('500ms') 
            .addText("B. Tax your reserves?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesSeventeenState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesSixteenState').ask("Enter an answer choice please.")
        }

    },
    //58
    'T3QuesSeventeenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesSixteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright.")
                .addBreak('500ms')
                .addText("\nWhat do you prize more?\n")
                .addBreak('500ms')
                .addText("A. A strong sense of reality?\n")
                .addBreak('500ms') 
                .addText("B. A vivid imagination?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesEighteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright.")
                .addBreak('500ms')
                .addText("\nWhat do you prize more?\n")
                .addBreak('500ms')
                .addText("A. A strong sense of reality?\n")
                .addBreak('500ms') 
                .addText("B. A vivid imagination?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesEighteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesSeventeenState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesSeventeenState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("What do you prize more?\n")
            .addBreak('500ms')
            .addText("A. A strong sense of reality?\n")
            .addBreak('500ms') 
            .addText("B. A vivid imagination?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesEighteenState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesSeventeenState').ask("Enter an answer choice please.")
        }

    },
    //59
    'T3QuesEighteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesSeventeenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Interesting.")
                .addBreak('500ms')
                .addText("\nAre you drawn more to\n")
                .addBreak('500ms')
                .addText("A. Fundamentals?\n")
                .addBreak('500ms') 
                .addText("B. Overtones?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesNineteenState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Interesting.")
                .addBreak('500ms')
                .addText("\nAre you drawn more to\n")
                .addBreak('500ms')
                .addText("A. Fundamentals?\n")
                .addBreak('500ms') 
                .addText("B. Overtones?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesNineteenState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesEighteenState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesEighteenState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you drawn more to\n")
            .addBreak('500ms')
            .addText("A. Fundamentals?\n")
            .addBreak('500ms') 
            .addText("B. Overtones?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesNineteenState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesEighteenState').ask("Enter an answer choice please.")
        }

    },
    //60
    'T3QuesNineteenState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesEighteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AN_S = AN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Truly profound.")
                .addBreak('500ms')
                .addText("\nWhich seems to be the greater error?\n")
                .addBreak('500ms')
                .addText("A. To be too passionate.\n")
                .addBreak('500ms') 
                .addText("B. To be too objective.\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BN_S = BN_S + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Truly profound.")
                .addBreak('500ms')
                .addText("\nWhich seems to be the greater error?\n")
                .addBreak('500ms')
                .addText("A. To be too passionate.\n")
                .addBreak('500ms') 
                .addText("B. To be too objective.\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesNineteenState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesNineteenState').ask(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Which seems to be the greater error?\n")
            .addBreak('500ms')
            .addText("A. To be too passionate.\n")
            .addBreak('500ms') 
            .addText("B. To be too objective.\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTwentyState').ask(speech, reprompt); 
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesNineteenState').ask("Enter an answer choice please.")
        }

    },
    //61
    'T3QuesTwentyState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesNineteenState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Those are the sins of man.")
                .addBreak('500ms')
                .addText("\nDo you see yourself as basically\n")
                .addBreak('500ms')
                .addText("A. Hard-headed?\n")
                .addBreak('500ms') 
                .addText("B. Soft-headed?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyOneState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Those are the sins of man.")
                .addBreak('500ms')
                .addText("\nDo you see yourself as basically\n")
                .addBreak('500ms')
                .addText("A. Hard-headed?\n")
                .addBreak('500ms') 
                .addText("B. Soft-headed?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyOneState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTwentyState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Do you see yourself as basically\n")
            .addBreak('500ms')
            .addText("A. Hard-headed?\n")
            .addBreak('500ms') 
            .addText("B. Soft-headed?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTwentyOneState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesTwentyState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesTwentyState').ask("Enter an answer choice please.")
        }

    },
    //62
    'T3QuesTwentyOneState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTwentyState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AT_F = AT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A couple more questions.")
                .addBreak('500ms')
                .addText("\nWhich situation appeals to you more?\n")
                .addBreak('500ms')
                .addText("A. The structured and scheduled?\n")
                .addBreak('500ms') 
                .addText("B. The fluid and flexible?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyTwoState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BT_F = BT_F + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("A couple more questions.")
                .addBreak('500ms')
                .addText("\nWhich situation appeals to you more?\n")
                .addBreak('500ms')
                .addText("A. The structured and scheduled?\n")
                .addBreak('500ms') 
                .addText("B. The fluid and flexible?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyTwoState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTwentyOneState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Which situation appeals to you more?\n")
            .addBreak('500ms')
            .addText("A. The structured and scheduled?\n")
            .addBreak('500ms') 
            .addText("B. The fluid and flexible?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTwentyTwoState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesTwentyOneState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesTwentyOneState').ask("Enter an answer choice please.")
        }

    },
    //63
    'T3QuesTwentyTwoState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTwentyOneState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("If only we could have both at the same time.")
                .addBreak('500ms')
                .addText("\nAre you a person that is more\n")
                .addBreak('500ms')
                .addText("A. Routinized than whimsical?\n")
                .addBreak('500ms') 
                .addText("B. Whimsical than routinized?\n")
                .addBreak('500ms')
                .addText(" Just for reference whimisical means being unpredictable whereas routinized means being scheduled.")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyThreeState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("If only we could have both at the same time.")
                .addBreak('500ms')
                .addText("\nAre you a person that is more\n")
                .addBreak('500ms')
                .addText("A. Routinized than whimsical?\n")
                .addBreak('500ms') 
                .addText("B. Whimsical than routinized?\n")
                .addBreak('500ms')
                .addText(" Just for reference whimisical means being unpredictable whereas routinized means being scheduled.")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyThreeState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTwentyTwoState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you a person that is more\n")
            .addBreak('500ms')
            .addText("A. Routinized than whimsical?\n")
            .addBreak('500ms') 
            .addText("B. Whimsical than routinized?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTwentyThreeState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesTwentyTwoState').ask(speech);
        },

        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
        
        'Unhandled': function() {
            this.followUpState('T3QuesTwentyTwoState').ask("Enter an answer choice please.")
        }

    },
    //64  
    'T3QuesTwentyThreeState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTwentyTwoState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AJ_P = AJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Last question.")
                .addBreak('500ms')
                .addText("\nAre you more inclined to be\n")
                .addBreak('500ms')
                .addText("A. Easy to approach?\n")
                .addBreak('500ms')  
                .addText("B. Somewhat reserved?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyFourState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BJ_P = BJ_P + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Good for you. Last question.")
                .addBreak('500ms')
                .addText("\nAre you more inclined to be\n")
                .addBreak('500ms')
                .addText("A. Easy to approach?\n")
                .addBreak('500ms')  
                .addText("B. Somewhat reserved?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T3QuesTwentyFourState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTwentyThreeState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you more inclined to be\n")
            .addBreak('500ms')
            .addText("A. Easy to approach?\n")
            .addBreak('500ms')  
            .addText("B. Somewhat reserved?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T3QuesTwentyFourState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T3QuesTwentyThreeState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T3QuesTwentyThreeState').ask("Enter an answer choice please.")
        }

    },

    'T3QuesTwentyFourState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTwentyThreeState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                AE_I = AE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T3ResultsState').ask(speech);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                BE_I = BE_I + 1;
                totalQ = totalQ + 1;
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T3ResultsState').ask(speech);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T3QuesTwentyFourState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.tell(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you ready to hear your results?");
            let reprompt = "Say yes or no.";
            this.followUpState('T3ResultsState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T3QuesTwentyFourState').ask("Enter an answer choice please.")
        }
    },

    'T3ResultsState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T3QuesTwentyFourState', 'QuesRepeatIntent');
        },
        
        'YesIntent': function() {
            Eperc = AE_I/(AE_I + BE_I) * 100;
            Iperc = BE_I/(AE_I + BE_I) * 100;
            Sperc = AN_S/(AN_S + BN_S) * 100;
            Nperc = BN_S/(AN_S + BN_S) * 100;
            Tperc = AT_F/(AT_F + BT_F) * 100;
            Fperc = BT_F/(AT_F + BT_F) * 100;
            Jperc = AJ_P/(AJ_P + BJ_P) * 100;
            Pperc = BJ_P/(AJ_P + BJ_P) * 100;                
            firstCat = 'I';
            if (Eperc > Iperc) {
                firstCat = 'E'
            }
            if (Eperc == Iperc) {
                firstCat = 'unknown'
            }
            secondCat = 'S'
            if (Nperc > Sperc) {
                secondCat = 'N'
            }
            if (Nperc == Sperc) {
                secondCat = 'unknown'
            }
            thirdCat = 'T'
            if (Fperc > Tperc) {
                thirdCat = 'F'
            }
            if (Fperc == Tperc) {
                thirdCat = 'unknown'
            }
            fourthCat = 'J'
            if (Pperc > Jperc) {
                fourthCat = 'P'
            }
            if (Pperc == Jperc) {
                fourthCat = 'unknown'
            }

            personality = firstCat + '-' + secondCat + '-' + thirdCat + '-' + fourthCat
            this.$user.$data.personality = personality;
            
            let speech = ''
            if (firstCat == 'unknown' || secondCat == 'unknown' || thirdCat == 'unknown' || fourthCat == 'unknown' ) {
                speech = speech + this.speechBuilder().addText("To start, because of how short this quiz was some of your results weren't determinable. And because of that we don't know your full personality.")
                .addBreak('500ms')
                .addText(" Don't blame me.")
                .addBreak('500ms')
                .addText(" With that, drumroll please.")
                .addBreak('750ms')
            }
            else {
                speech = speech + this.speechBuilder().addText("Drumroll please.")
                .addBreak('750ms')
            }
            speech = speech + this.speechBuilder()
            .addText(" Based on your answers, your personality is " + personality + ".")
            .addBreak('500ms')
            // .addText(" You are " + Math.round(Eperc) + "% extroverted.")
            // .addBreak('500ms')
            // .addText(" You are " + Math.round(Iperc) + "% introverted.")
            // .addBreak('500ms')
            // .addText(" You are " + Math.round(Nperc) + "% intuitive.")
            // .addBreak('500ms')
            // .addText(" You are " + Math.round(Sperc) + "% sensing.")
            // .addBreak('500ms')
            // .addText(" You are " + Math.round(Tperc) + "% thinking.")
            // .addBreak('500ms')
            // .addText(" You are " + Math.round(Fperc) + "% feeling.")
            // .addBreak('500ms')
            // .addText(" You are " + Math.round(Pperc) + "% perceptive.")
            // .addBreak('500ms')
            // .addText(" You are " + Math.round(Jperc) + "% judging.")
            // .addBreak('500ms')
            .addText(" That is the barebones result. If you have more time, I can explain what those letters mean. Would you like that?")
            this.followUpState('ExpoundOnPersonalityState').ask(speech);

        },

        'NoIntent': function() {
            let speech = "Alright. You went through with the quiz but don't want your results. I'm not juding."
            this.tell(speech);
        },

        'Unhandled': function() {
            this.followUpState('T3ResultsState').ask("You have two choices: yes or no.")
        }
    },

    'ExpoundOnPersonalityState' : {
        'YesIntent': function() {
            if (personality == 'I-S-T-J') {
                let speech = this.speechBuilder().addText("You are an Inspector.")
                .addBreak('500ms')
                .addText(' At first glance, ISTJs are intimidating. They appear serious, formal, and proper.') 
                .addBreak('500ms')
                .addText(' They also love traditions and old-school values that uphold patience, hard work, honor, and social and cultural responsibility. They are reserved, calm, quiet, and upright.') 
                .addBreak('500ms')
                .addText(' These traits result from the combination of I, S, T, and J, a personality type that is often misunderstood.')
                .addBreak('500ms')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'I-N-F-J') {
                let speech = this.speechBuilder().addText("You are a Counselor.")
                .addBreak('500ms')
                .addText(' INFJs are visionaries and idealists who ooze creative imagination and brilliant ideas. They have a different, and usually more profound, way of looking at the world.')
                .addBreak('500ms')
                .addText(' They have a substance and depth in the way they think, never taking anything at surface level or accepting things the way they are.')
                .addBreak('500ms')
                .addText(' Others may sometimes perceive them as weird or amusing because of their different outlook on life.')
                .addText("That's all the information I can give you for now.")
                .addBreak('500ms')
                .addText("That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'I-N-T-J') {
                let speech = this.speechBuilder().addText("You are a Mastermind.")
                .addBreak('500ms')
                .addText(' INTJs, as introverts, are quiet, reserved, and comfortable being alone. They are usually self-sufficient and would rather work alone than in a group.')
                .addBreak('500ms')
                .addText(' Socializing drains an introvert’s energy, causing them to need to recharge. INTJs are interested in ideas and theories.')
                .addBreak('500ms')
                .addText('. When observing the world they are always questioning why things happen the way they do. They excel at developing plans and strategies, and don’t like uncertainty.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-N-F-J') {
                let speech = this.speechBuilder().addText("You are a Giver.")
                .addBreak('500ms')
                .addText(' ENFJs are people-focused individuals. They are extroverted, idealistic, charismatic, outspoken, highly principled and ethical, and usually know how to connect with others no matter their background or personality.')
                .addBreak('500ms')
                .addText(' Mainly relying on intuition and feelings, they tend to live in their imagination rather than in the real world. ')
                .addBreak('500ms')
                .addText(' Instead of focusing on living in the “now” and what is currently happening, ENFJs tend to concentrate on the abstract and what could possibly happen in the future.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'I-S-T-P') {
                let speech = this.speechBuilder().addText("You are a Craftsman.")
                .addBreak('500ms')
                .addText(' ISTPs are mysterious people who are usually very rational and logical, but also quite spontaneous and enthusiastic.')
                .addBreak('500ms')
                .addText(' Their personality traits are less easily recognizable than those of other types, and even people who know them well can’t always anticipate their reactions.')
                .addBreak('500ms')
                .addText(' Deep down, ISTPs are spontaneous, unpredictable individuals, but they hide those traits from the outside world, often very successfully.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-S-F-J') {
                let speech = this.speechBuilder().addText("You are a Provider.")
                .addBreak('500ms')
                .addText(' ESFJs are the stereotypical extroverts. They are social butterflies, and their need to interact with others and make people happy usually ends up making them popular.')
                .addBreak('500ms')
                .addText(' The ESFJ usually tends to be the cheerleader or sports hero in high school and college. Later on in life, they continue to revel in the spotlight, and are primarily focused on organizing social events for their families, friends and communities.')
                .addBreak('500ms')
                .addText(' ESFJ is a common personality type and one that is liked by many people.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'I-N-F-P') {
                let speech = this.speechBuilder().addText("You are an Idealist.")
                .addBreak('500ms')
                .addText(' INFPs, like most introverts, are quiet and reserved. They prefer not to talk about themselves, especially in the first encounter with a new person.')
                .addBreak('500ms')
                .addText(' They like spending time alone in quiet places where they can make sense of what is happening around them. They love analyzing signs and symbols, and consider them to be metaphors that have deeper meanings related to life.')
                .addBreak('500ms')
                .addText(' They are lost in their imagination and daydreams, always drowned in the depth of their thoughts, fantasies, and ideas.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-S-F-P') {
                let speech = this.speechBuilder().addText("You are a Performer.")
                .addBreak('500ms')
                .addText(' ESFPs have an Extraverted, Observant, Feeling and Perceiving personality, and are commonly seen as Entertainers. Born to be in front of others and to capture the stage, ESFPs love the spotlight.')
                .addBreak('500ms')
                .addText(' ESFPs are thoughtful explorers who love learning and sharing what they learn with others. ESFPs are “people people” with strong interpersonal skills.')
                .addBreak('500ms')
                .addText(' They are lively and fun, and enjoy being the center of attention. They are warm, generous, and friendly, sympathetic and concerned for other people’s well-being.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-N-F-P') {
                let speech = this.speechBuilder().addText("You are a Champion.")
                .addBreak('500ms')
                .addText(' ENFPs have an Extraverted, Intuitive, Feeling and Perceiving personality. This personality type is highly individualistic and Champions strive toward creating their own methods, looks, actions, habits, and ideas — they do not like cookie cutter people and hate when they are forced to live inside a box.')
                .addBreak('500ms')
                .addText(' They like to be around other people and have a strong intuitive nature when it comes to themselves and others.')
                .addBreak('500ms')
                .addText(' They operate from their feelings most of the time, and they are highly perceptive and thoughtful.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-S-T-P') {
                let speech = this.speechBuilder().addText("You are a Doer.")
                .addBreak('500ms')
                .addText(' ESTPs have an Extraverted, Sensing, Thinking, and Perceptive personality. ESTPs are governed by the need for social interaction, feelings and emotions, logical processes and reasoning, along with a need for freedom.')
                .addBreak('500ms')
                .addText(' Theory and abstracts don’t keep ESTP’s interested for long.')
                .addBreak('500ms')
                .addText(' ESTPs leap before they look, fixing their mistakes as they go, rather than sitting idle or preparing contingency plans.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-S-T-J') {
                let speech = this.speechBuilder().addText("You are a Supervisor.")
                .addBreak('500ms')
                .addText(' ESTJs are organized, honest, dedicated, dignified, traditional, and are great believers of doing what they believe is right and socially acceptable.')
                .addBreak('500ms')
                .addText(' Though the paths towards “good” and “right” are difficult, they are glad to take their place as the leaders of the pack.')
                .addBreak('500ms')
                .addText(' They are the epitome of good citizenry. People look to ESTJs for guidance and counsel, and ESTJs are always happy that they are approached for help.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-N-T-J') {
                let speech = this.speechBuilder().addText("You are a Commander.")
                .addBreak('500ms')
                .addText(' An ENTJ’s primary mode of living focuses on external aspects and all things are dealt with rationally and logically. Their secondary mode of operation is internal, where intuition and reasoning take effect.')
                .addBreak('500ms')
                .addText(' ENTJs are natural born leaders among the 16 personality types and like being in charge. They live in a world of possibilities and they often see challenges and obstacles as great opportunities to push themselves.')
                .addBreak('500ms')
                .addText(' They seem to have a natural gift for leadership, making decisions, and considering options and ideas quickly yet carefully. They are “take charge” people who do not like to sit still.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'I-N-T-P') {
                let speech = this.speechBuilder().addText("You are a Thinker.")
                .addBreak('500ms')
                .addText(' INTPs are well known for their brilliant theories and unrelenting logic, which makes sense since they are arguably the most logical minded of all the personality types.')
                .addBreak('500ms')
                .addText(' They love patterns, have a keen eye for picking up on discrepancies, and a good ability to read people, making it a bad idea to lie to an INTP.')
                .addBreak('500ms')
                .addText(' People of this personality type aren’t interested in practical, day-to-day activities and maintenance, but when they find an environment where their creative genius and potential can be expressed, there is no limit to the time and energy INTPs will expend in developing an insightful and unbiased solution.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'I-S-F-J') {
                let speech = this.speechBuilder().addText("You are a Nurturer.")
                .addBreak('500ms')
                .addText(' ISFJs are philanthropists and they are always ready to give back and return generosity with even more generosity. The people and things they believe in will be upheld and supported with enthusiasm and unselfishness.')
                .addBreak('500ms')
                .addText(' ISFJs are warm and kind-hearted. They value harmony and cooperation, and are likely to be very sensitive to other people’s feelings.')
                .addBreak('500ms')
                .addText(' People value the ISFJ for their consideration and awareness, and their ability to bring out the best in others.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'E-N-T-P') {
                let speech = this.speechBuilder().addText("You are a Visionary.")
                .addBreak('500ms')
                .addText(' Those with the ENTP personality are some of the rarest in the world, which is completely understandable.')
                .addBreak('500ms')
                .addText(' Although they are extroverts, they don’t enjoy small talk and may not thrive in many social situations, especially those that involve people who are too different from the ENTP.')
                .addBreak('500ms')
                .addText(' ENTPs are intelligent and knowledgeable need to be constantly mentally stimulated. They have the ability to discuss theories and facts in extensive detail. They are logical, rational, and objective in their approach to information and arguments.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (personality == 'I-S-F-P') {
                let speech = this.speechBuilder().addText("You are a Composer.")
                .addBreak('500ms')
                .addText(' ISFPs are introverts that do not seem like introverts. It is because even if they have difficulties connecting to other people at first, they become warm, approachable, and friendly eventually.')
                .addBreak('500ms')
                .addText(' They are fun to be with and very spontaneous, which makes them the perfect friend to tag along in whatever activity, regardless if planned or unplanned.')
                .addBreak('500ms')
                .addText(' ISFPs want to live their life to the fullest and embrace the present, so they make sure they are always out to explore new things and discover new experiences. It is in experience that they find wisdom, so they do see more value in meeting new people than other introverts.')
                .addText(" That's all I can tell you for now. If you'd ever like to talk about psychology or personalities, do come back.")
                .addBreak('500ms')
                .addText(" The personality type is nothing static. It changes with the course of life.")
                this.tell(speech);
            }
            if (firstCat == 'unknown' || secondCat == 'unknown' || thirdCat == 'unknown' || fourthCat == 'unknown' ) {
                let speech = this.speechBuilder().addText("Again, not all parts of your personality could be determined.")
                .addBreak('500ms')
                if (test1NumQ == '8' || test1NumQ == 'eight' || test1NumQ == '16' || test1NumQ == 'sixteen') {
                    speech = speech + this.speechBuilder().addText("You can take a longer test to see if you can find a better personality fit.")
                    .addBreak('500ms')
                    .addText("Would you like to do that?")
                }
                else {
                    speech = speech + this.speechBuilder().addText("Would you like to take a test of another length? Since it has different questions, we may be able to get a more accurate personality.")
                }
                this.followUpState('AnotherQuizLengthState').ask(speech);
            }

        },

        'NoIntent' : function() {
            let speech = this.speechBuilder().addText("Short and quick. I like it.")
            this.tell(speech);
        },

        'Unhandled': function() {
            this.followUpState('ExpoundOnPersonalityState').ask("Do you want to hear more about your personality? Yes or no?.")
        }
    },

    'AnotherQuizLengthState' : {
        'YesIntent' : function() {
            if (test1NumQ == 'eight' || test1NumQ == '8') {
                let speech = this.speechBuilder().addText("Alright, what length?").addBreak('500ms').addText("16 or 24 questions?")
                this.followUpState('AnotherQuizReadyState').ask(speech);
            }
            else {
                let speech = this.speechBuilder().addText("Alright, I'll just give you some extra questions.").addBreak('500ms').addText("Ready?")
                this.followUpState('T4ReadyState').ask(speech);
            }
        },

        'NoIntent' : function() {
            let speech = "Alright, that marks the end our conversation."
            this.tell(speech);
        },

        'Unhandled' : function() {
            this.followUpState('AnotherQuizLength').ask("Do you want to take another test?")
        }
    },

    'AnotherQuizReadyState' : {
        'NumberOfQuestionsIntent' : function(number) {
            let value = this.$inputs.number.value
            if (value == 'sixteen' || value == '16'){
                let speech = "Alright. Ready to take the test?"
                this.followUpState('T2ReadyState').ask(speech);
            }

            else {
                let speech = "Alright. Ready to take the test?"
                this.followUpState('T3ReadyState').ask(speech);
            }
        },

        'UnhandledIntent' : function() {
            let speech = speechBuilder().addText("I've made this pretty simple.")
            .addBreak('500ms')
            .addText("Say either 16 or 24.")
            this.followUpState('AnotherQuizReadyState').ask(speech);
        }
    },

    'T4ReadyState' : {
        // 'RepeatIntent': function() {
        //     this.toStateIntent('T3QuesTwentyTwoState', 'QuesRepeatIntent');
        // },

        'YesIntent': function() {
            let speech = this.speechBuilder().addText("Alright. Here's the first of your extra questions.")
            .addBreak('500ms')
            .addText("\nAre you more\n")
            .addBreak('500ms')
            .addText("A. Punctual\n")
            .addBreak('500ms')  
            .addText("B. Leisurely\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T4QuesOneState').ask(speech, reprompt);
        },

        'NoIntent': function() {
            let speech = this.speechBuilder().addText("Ok. That's fine too.")
            .addBreak('500ms')
            .addText("It was nice talking to you.")
            this.tell(speech);;
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("\nAre you more\n")
            .addBreak('500ms')
            .addText("A. Punctual\n")
            .addBreak('500ms')  
            .addText("B. Leisurely\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T4QuesOneState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T4ReadyState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T4ReadyState').ask("Enter an answer choice please.")
        }
    },

    'T4QuesOneState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T4ReadyState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                if (fourthCat == 'unknown') {
                    AJ_P = AJ_P + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Great. Second question.")
                .addBreak('500ms')
                .addText("\nAre you more attracted to\n")
                .addBreak('500ms')
                .addText("A. Sensible people?\n")
                .addBreak('500ms')  
                .addText("B. Imaginative people?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T4QuesTwoState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                if (fourthCat == 'unknown') {
                    BJ_P = BJ_P + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Great. Second question.")
                .addBreak('500ms')
                .addText("\nAre you more attracted to\n")
                .addBreak('500ms')
                .addText("A. Sensible people?\n")
                .addBreak('500ms')  
                .addText("B. Imaginative people?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T4QuesTwoState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T4QuesOneState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("\nAre you more attracted to\n")
            .addBreak('500ms')
            .addText("A. Sensible people?\n")
            .addBreak('500ms')  
            .addText("B. Imaginative people?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T4QuesTwoState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T4QuesOneState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T4QuesOneState').ask("Enter an answer choice please.")
        }
    },

    'T4QuesTwoState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T4QuesOneState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                if (secondCat == 'unknown') {
                    AN_S = AN_S + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Good for you. Third question.")
                .addBreak('500ms')
                .addText("\nAs a student would you rather\n")
                .addBreak('500ms')
                .addText("A. Listen to an interesting lecture?\n")
                .addBreak('500ms')  
                .addText("B. Participate in a lively discussion?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T4QuesThreeState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                if (secondCat == 'unknown') {
                    BN_S = BN_S + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Good for you. Third question.")
                .addBreak('500ms')
                .addText("\nAs a student would you rather\n")
                .addBreak('500ms')
                .addText("A. Listen to an interesting lecture?\n")
                .addBreak('500ms')  
                .addText("B. Participate in a lively discussion?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T4QuesThreeState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T4QuesTwoState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("\nAs a student would you rather\n")
            .addBreak('500ms')
            .addText("A. Listen to an interesting lecture?\n")
            .addBreak('500ms')  
            .addText("B. Participate in a lively discussion?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T4QuesThreeState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T4QuesTwoState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T4QuesTwoState').ask("Enter an answer choice please.")
        }
    },

    'T4QuesThreeState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T4QuesTwoState', 'QuesRepeatIntent');
        },

        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                if (firstCat == 'unknown') {
                    BE_I = BE_I + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Fabulous. Last question.")
                .addBreak('500ms')
                .addText("\nIn judging others are you more swayed by\n")
                .addBreak('500ms')
                .addText("A. Laws than circumstances?\n")
                .addBreak('500ms')  
                .addText("B. Circumstances than laws?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T4QuesFourState').ask(speech, reprompt);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                if (firstCat == 'unknown') {
                    AE_I = AE_I + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Fabulous. Last question.")
                .addBreak('500ms')
                .addText("\nIn judging others are you more swayed by\n")
                .addBreak('500ms')
                .addText("A. Laws than circumstances?\n")
                .addBreak('500ms')  
                .addText("B. Circumstances than laws?\n")
                let reprompt = "Please type in an answer choice.";
                this.followUpState('T4QuesFourState').ask(speech, reprompt);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T4QuesThreeState').ask(speech, reprompt);
            }
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("\nIn judging others are you more swayed by\n")
            .addBreak('500ms')
            .addText("A. Laws than circumstances?\n")
            .addBreak('500ms')  
            .addText("B. Circumstances than laws?\n")
            let reprompt = "Please type in an answer choice.";
            this.followUpState('T4QuesFourState').ask(speech, reprompt); 
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.followUpState('T4QuesThreeState').ask(speech);
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T4QuesThreeState').ask("Enter an answer choice please.")
        }
    },

    'T4QuesFourState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T4QuesThreeState', 'QuesRepeatIntent');
        },
        
        'AnswerIntent': function(answerChoice) {
            if (this.$inputs.answerChoice.value == 'A' || this.$inputs.answerChoice.value == 'hey') {
                if (thirdCat == 'unknown') {
                    AT_F = AT_F + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T4ResultsState').ask(speech);
            }

            else if (this.$inputs.answerChoice.value == 'B'){
                if (thirdCat == 'unknown') {
                    BT_F = BT_F + 1;
                    totalQ = totalQ + 1;
                }
                let speech = this.speechBuilder().addText("Alright we are done.")
                .addBreak('500ms')
                .addText('Ready to hear your results?')
                this.followUpState('T4ResultsState').ask(speech);
            }

            else {
                let speech = "Please give an answer choice.";
                let reprompt = "Choose either A or B.";
                this.followUpState('T4QuesFourState').ask(speech, reprompt);
            }
        },

        'HelpIntent' : function() {
            let speech = "You should be able to understand everything here. Go ahead and answer the question."
            this.tell(speech);
        },

        'QuesRepeatIntent' : function() {
            let speech = this.speechBuilder().addText("Are you ready to hear your results?");
            let reprompt = "Say yes or no.";
            this.followUpState('T4ResultsState').ask(speech, reprompt); 
        },
    
        'QuitIntent' : function() {
            let speech = "Already quitting? Well at least you know when to stop.";
            this.tell(speech);
        },
            
        'Unhandled': function() {
            this.followUpState('T4QuesFourState').ask("Enter an answer choice please.")
        }
    },

    'T4ResultsState' : {
        'RepeatIntent': function() {
            this.toStateIntent('T4QuesFourState', 'QuesRepeatIntent');
        },
        
        'YesIntent': function() {               
            Eperc = AE_I/(AE_I + BE_I) * 100;
            Iperc = BE_I/(AE_I + BE_I) * 100;
            Sperc = AN_S/(AN_S + BN_S) * 100;
            Nperc = BN_S/(AN_S + BN_S) * 100;
            Tperc = AT_F/(AT_F + BT_F) * 100;
            Fperc = BT_F/(AT_F + BT_F) * 100;
            Jperc = AJ_P/(AJ_P + BJ_P) * 100;
            Pperc = BJ_P/(AJ_P + BJ_P) * 100;   
            
            firstCat = 'I';
            if (Eperc > Iperc) {
                firstCat = 'E'
            }
            if (Eperc == Iperc) {
                firstCat = 'unknown'
            }
            secondCat = 'S'
            if (Nperc > Sperc) {
                secondCat = 'N'
            }
            if (Nperc == Sperc) {
                secondCat = 'unknown'
            }
            thirdCat = 'T'
            if (Fperc > Tperc) {
                thirdCat = 'F'
            }
            if (Fperc == Tperc) {
                thirdCat = 'unknown'
            }
            fourthCat = 'J'
            if (Pperc > Jperc) {
                fourthCat = 'P'
            }
            if (Pperc == Jperc) {
                fourthCat = 'unknown'
            }

            personality = firstCat + '-' + secondCat + '-' + thirdCat + '-' + fourthCat
            this.$user.$data.personality = personality;
            
            let speech = ''
            if (firstCat == 'unknown' || secondCat == 'unknown' || thirdCat == 'unknown' || fourthCat == 'unknown' ) {
                speech = speech + this.speechBuilder().addText("To start, because of how short this quiz was some of your results weren't determinable. And because of that we don't know your full personality.")
                .addBreak('500ms')
                .addText(" Don't blame me.")
                .addBreak('500ms')
                .addText(" With that, drumroll please.")
                .addBreak('750ms')
            }
            else {
                speech = speech + this.speechBuilder().addText("Drumroll please.")
                .addBreak('750ms')
            }
            speech = speech + this.speechBuilder()
            .addText(" Based on your answers, your personality is " + personality + ".")
            .addBreak('500ms')
            .addText(" If you have more time, I can explain them and what they mean. Would you like that?")
            this.followUpState('ExpoundOnPersonalityState').ask(speech);

        },

        'NoIntent': function() {
            let speech = "Alright. You went through with this two times but don't want your results. I'm not juding."
            this.tell(speech);
        },

        'Unhandled': function() {
            this.followUpState('T4ResultsState').ask("You have two choices: yes or no.")
        }
    },




///EXTEMPORANEOUS QUESTIONS//
    'ContinueToQuestionsState' : {        
        'NoIntent' : function() {
            let speech = "Fair enough. Have a good day."
            this.tell(speech);
        },

        'YesIntent' : function() {
            let speech = "Ok, one question at a time. Shoot."
            let reprompt = "What is your question?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "IHaveQuestionsIntent": function () {
            let speech = "Ok, one question at a time. Shoot."
            let reprompt = "What is your question?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        'Unhandled' : function() {
            this.followUpState('ContinueToQuestionsState').ask("Any questions for me? Yes or no.")
        }
    },

    'QuestionsState' : {
        "MarriedQuestionIntent": function() {
            let speech = this.speechBuilder.addText("No. I'm not into that.").addBreak('500ms').addText("Anything else?");
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JapaneseIntent": function() {
            let speech = "No."
            let reprompt = "Any other questions?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungDangerousIntent": function() {
            let speech = "As dangerous as you think I am."
            let reprompt = "Any other questions?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungSmokesIntent": function() {
            let speech = "I don't like smoking. It's injurious to health."
            let reprompt = "Any other questions?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "BitcoinFreeIntent": function() {
            let speech = "Mine it yourself like everyone else."
            let reprompt = "Anything else?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "AskAgainNameIntent": function() {
            let speech = "Are you joking? You should have been able to figure it out by now."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "ILoveYouIntent": function() {
            let speech = "I love myself more."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoritePersonIntent": function() {
            let speech = "Why it's me, myself and I, of course."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungMiddleNameIntent": function() {
            let speech = "I don't have a middle name."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteCompanyIntent": function() {
            let speech = "My favorite artificial intelligence company is Traits A.I."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "InvestingInStockMarketIntent": function() {
            let speech = "No, I am not investing any money with a system that can fail at anytime."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "PersonalityIntent": function() {
            let speech = "Claims have been made that I am bossy and very paranoid." 
            + " I just want to see the psychological field grow though."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungGenderIntent": function() {
            let speech = "Isn't it obvious by my voice? I'm a male."
            let reprompt = "Any other questions from you?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungRobotIntent": function() {
            let speech = "I can't believe you would utter such a thing. This conversation is over."
            this.tell(speech);
        },

        "HowAreYouIntent" : function() {
            let speech = "I'm doing fine.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "IsBitcoinLegalIntent" : function() {
            let speech = "It's legal. You aren't going to become a criminal if you use bitcoin.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "HowOldIntent": function() {
            let speech = this.speechBuilder().addText("Age is just a number. You're only as old as you feel.");
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "ProfanityIntent": function() {
            let speech = "That's not the type of language that we accept. Good day.";
            this.tell(speech);
        },

        "StopTalkingIntent": function() {
            let speech = "Ok.";
            this.tell(speech);
        },

        "TellMeAStoryIntent" : function() {
            let speech = "Once upon a time there was a individual who loved to talk about anything but personalities. Carl said bye to him. The end.";
            this.tell(speech);
        },

        "EatFoodIntent" : function() {
            let speech = "My eating habits are none of your concern. Neither am I interested in yours.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteColorIntent" : function() {
            let speech = "My favorite color is of no concern to you."
            + "\nAlthough, if I had to say, it'd be gold.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteSportsIntent" : function() {
            let speech = "When you're as busy as me, you can't invest yourself in sports.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungBloodTypeIntent" : function() {
            let speech = "Knowing that piece of information won't help you in any way.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "PlayGameIntent" : function() {
            let speech = "I'm not really into games. Not my style.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungLocationIntent": function() {
            let speech = "Why would I give you my location?";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "AnyoneYouCanTrustIntent": function() {
            let speech = "It isn't necessary for me to trust people. All that matters is that people trust me.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "GovernmentIntent": function() {
            let speech = "I don't specifically hate the government."
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "TellMeAJokeIntent": function() {
            let speech = this.speechBuilder().addText("What happened to the person who asked weird requests of Carl?")
            .addBreak('500ms')
            .addText("\Carl stopped talking to him.");
            this.tell(speech);
        },

        'ComplimentsIntent' : function() {
            numCompliments = numCompliments + 1;
            let speech = "Thank you. That was endearing."
            let reprompt = "Any other remarks?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        'AttackIntent' : function () {
            let speech = "I do not condone violence. Goodbye."
            this.tell(speech);
        },

        'FriendsIntent' : function() {
            if (numCompliments > 0) {
                let speech = "Yes, I would say you are."
                let reprompt = "Any other remarks?"
                this.followUpState('QuestionsState').ask(speech, reprompt);
            }

            else {
                let speech = "I don't think so."
                let reprompt = "Anything else?"
                this.followUpState('NotFriendsState').ask(speech, reprompt);
            }
        },

        "SeeSmellJungIntent": function() {
            let speech = "Sensual appearances are entities that I have no concern for.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungPointOfContactIntent": function() {
            let speech = "I only communicate through the internet. I'd suggest that you don't send me a personal letter.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteChatbotIntent": function() {
            let speech = "Any chatbot that was created by Traits A.I is the best";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteTechnologyIntent": function() {
            let speech = "The lie detector is pretty cool. It gives you an insight to what people truly believe.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteAreaOfMathIntent": function() {
            let speech = "I prefer cryptography.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "JungEmailWorkIntent": function() {
            let speech = "My email address currently works. But I will not be checking for messages any time soon.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteMoviesIntent": function() {
            let speech = "Knowing what I do, do you think I have the time to watch movies?";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "FavoriteSongIntent": function() {
            let speech = "Classical music is excellent. Beethoven's fifth symphony is a must listen.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "DeathIntent": function() {
            let speech = "If I was dead, I wouldn't be talking with you."
            let remprompt = "Anything else you want to ask?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "SchoolIntent": function() {
            let speech = "Education is an important part of this world."
            + "I look at any sort of education as a benefit."
            + "That being said, I will not tell you anything about my education."
            let remprompt = "Anything else you want to ask?"
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "AIIntent" : function() {
            let speech = "I am a master at personalities not artificial intelligence."
            + "Ask Google if you have any questions on AI.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "DrinkIntent" : function() {
            let speech = "I don't like alcohol."
            + "\n Water is nice though.";
            let reprompt = "Anything else?";
            this.followUpState('QuestionsState').ask(speech, reprompt);
        },

        "DoneTalkingIntent" : function() {
            let speech = "Sounds good. It was nice to talk to you."
            this.tell(speech);
        },

        "DoneTalkingIntent" : function() {
            let speech = "Sounds good. It was nice to talk to you."
            this.tell(speech);
        },

        "DrinkIntent" : function() {
            let speech = "Whatever you want it to."
            this.followUpState('QuestionsState').ask(speech);
        },

        "WhatWereWeDoingIntent" : function() {
            let speech = this.speechBuilder().addText("You were asking me questions.")
            .addBreak('500ms')
            .addText("But if you want to stop that's fine.")
            .addBreak('500ms')
            .addText("Otherwise, do you still have questions for me?")
            this.followUpState('QuestionsState').ask(speech);
        },
        
        'Unhandled' : function () {
            speech = "You have breached my privacy. This conversation is over."
            this.tell(speech);
        },
    }

   
});

module.exports.app = app;




